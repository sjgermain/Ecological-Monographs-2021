## Wind River Stability - Survival Analysis ##
## Sensitivity Analysis FIVE ##
## Sara Germain ##
## March 2021 ##


setwd("WFDP_Demography_20200303")

RUN.SA5=F

##############################################################################################################################################-
##############################################              LIBRARIES AND FUNCTIONS              #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

library('ggplot2')
library('survival')
library('grid')
library('gridExtra')
library('cowplot')
library('reshape2')
library('dplyr')


theme_prefs<-theme_classic() + theme(axis.title.x = element_text(size=12),
                                     axis.title.y = element_text(size=12),
                                     axis.text.x = element_text(size=12, colour='black'),
                                     axis.text.y = element_text(size=12, colour='black'),
                                     axis.ticks = element_line(colour='black'),
                                     legend.text = element_text(size=12),
                                     legend.title = element_text(size=12),
                                     plot.title=element_text(size=12,hjust=0.5, vjust=-3))

#functions
mround<-function(x,base){
  base*round((x-(base/2-0.1))/base)
}

stand = function(focal.influence,mean.influence,sd.influence){
  (focal.influence-mean.influence)/sd.influence
}

basal_area = function(tree.DBH){
  return(0.0001*(pi*((0.5*tree.DBH)^2)))
}

coef.tbl <- function(fm){
  cc <- fm$coefficients
  nvar <- length(cc)
  nfrail<- nrow(fm$var) - nvar
  se <- sqrt(diag(fm$var)[nfrail+1:nvar])
  high = exp(cc+2*se)
  low=exp(cc-2*se)
  z=cc/se
  sig <- signif(1 - pchisq((cc/ se)^2, 1), 2)
  m.names<-names(fm$coefficients)
  signif <- ifelse(sig <=0.05, 19, 1)
  df<-data.frame(m.names,Estimate = cc, hazard=exp(cc),Std.Err = se, z = z, high, low,sig, signif,row.names = m.names)
}


##############################################################################################################################################

##############################################################################################################################################-
################################################              CREATE BASELINE DATA            ################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

#common species analyzed
spplist1<-c('ABAM','PSME','TABR','TSHE', 'ACCI')

#baseline data
trees<-read.csv("./DATA/WFDP_Tree_20200305.csv",na.strings='NULL') #SQL code = SELECT STEM_TAG, TREE_TAG, CENSUS, DATE, DBH_DATE, IN_YR, QUADRAT, SPECIES, DBH, GROWTH_DBH, BIOMASS_DBH, STATUS, MORT_DATE, VIGOR, DA, SC, SNAG_HEIGHT, SNAG_TD, PLOT_X, PLOT_Y, UTM_X, UTM_Y, RELATIVE_PLOT_X, RELATIVE_PLOT_Y, COMMENT, NURSE_LOG, ES, MT, LEANER_ANGLE FROM `Tree` WHERE QUADRAT not like 'Q%'
trees<-trees[(trees$MORT_DATE>0 & is.na(trees$MORT_DATE)==F)|is.na(trees$MORT_DATE)==T,]
trees[trees$CENSUS>17,"BIOMASS_DBH"] <- trees[trees$CENSUS>17,"DBH"]
trees<-trees[is.na(trees$BIOMASS_DBH)==F&is.na(trees$SPECIES)==F&is.na(trees$PLOT_X)==F&is.na(trees$PLOT_Y)==F,]
trees$STEM_TAG <- as.character(trees$STEM_TAG)

neighbors<-read.csv("./OUTPUT/Neighborhood/WFDP_Tree_with_neighbors_20200306.csv",na.strings='NA')
neighbors<-neighbors[(neighbors$MORT_DATE>0 & is.na(neighbors$MORT_DATE)==F)|is.na(neighbors$MORT_DATE)==T,]
neighbors$STEM_TAG <- as.character(neighbors$STEM_TAG)
nrow(neighbors[duplicated(neighbors$STEM_TAG),]) # double check!

morts<-read.csv("./DATA/WFDP_Mortality_20200311.csv",na.strings='NULL')
morts$STEM_TAG <- as.character(morts$STEM_TAG)
mechanical<-morts[(is.na(morts$FAD1)==F & morts$FAD1 >=80) | 
                    (is.na(morts$FAD2)==F & morts$FAD2 >=80) |
                    (is.na(morts$FAD3)==F & morts$FAD3 >=80) |
                    (is.na(morts$FAD4)==F & morts$FAD4 >=80) |
                    (is.na(morts$FAD5)==F & morts$FAD5 >=80),]
fungus<-mechanical[(is.na(mechanical$FAD1)==F & mechanical$FAD1 %in% 60:65) | 
                     (is.na(mechanical$FAD2)==F & mechanical$FAD2 %in% 60:65) |
                     (is.na(mechanical$FAD3)==F & mechanical$FAD3 %in% 60:65) |
                     (is.na(mechanical$FAD4)==F & mechanical$FAD4 %in% 60:65) |
                     (is.na(mechanical$FAD5)==F & mechanical$FAD5 %in% 60:65),]

mechanical<-mechanical[!mechanical$STEM_TAG %in% fungus$STEM_TAG,]  

# restrict dataset to common species
live.tree<-trees[trees$CENSUS>=17,]
live.tree<-live.tree[live.tree$CENSUS<20,] # no ingrowth from most recent year; consider only trees that COULD die
nrow(live.tree[duplicated(live.tree$STEM_TAG),]) # double check!

live.tree<-merge(live.tree,neighbors[c(1,31:82)],by='STEM_TAG')
live.tree[live.tree$STEM_TAG=='23-0378','BIOMASS_DBH']<-14.9
live.tree$DA<-NA
live.tree$DA<-ifelse(live.tree$STATUS%in%c(1,2),0,1)

live.tree$SPECIES<-as.character(live.tree$SPECIES)
live.tree <- live.tree[live.tree$SPECIES %in% spplist1,]

live.tree<-live.tree[!live.tree$STEM_TAG %in% mechanical$STEM_TAG,] #omit trees that died from mechanical damage

#### standardize and center
live.tree <- live.tree[abs(live.tree$zscore.Hegyi.het)<4 & abs(live.tree$zscore.Hegyi.con)<4,] #truncate dataset at +/- 4 SD
live.tree['elev.diff']<-apply(live.tree['elev.diff'],2,FUN= function(x){x-mean(x)}) #center elevation
live.tree['BIOMASS_DBH']<-apply(live.tree['BIOMASS_DBH'],1,FUN= function(x){log(x)}) #transform DBH 

live.tree$conifer<-ifelse(live.tree$SPECIES%in%c("TSHE","TABR","ABAM","PSME","THPL","ABGR","ABPR","PIMO"),1,0)
neighbor.predictors<-c("zscore.Hegyi.con","zscore.Hegyi.het","elev.diff")


#historical climate
load("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_20200310")
load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_HISTORICAL_PRISM_method_20200310')


colnames(def.snow)[1]<-'CENSUS'
def.snow$deflag1<-def.snow[c(nrow(def.snow),1:(nrow(def.snow)-1)),'deficit']
def.snow<-def.snow[def.snow$CENSUS>2011,]
def.snow[2:4]<-apply(def.snow[2:4],2,FUN= function(x){x-mean(x)}) #center variables

##############################################################################################################################################

##############################################################################################################################################-
#############################################              RUN SENSITIVITY SIMULATIONS           #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

### Make 1000 simulations of mortality if mortality had been random, where random is proportional to observed total mortality



if(RUN.SA5==T){
  new.tree <- live.tree
  new.tree$MORT_DATE<-NA
  new.tree$DA<-NA
  
  nmorts <- aggregate(live.tree$STEM_TAG, by=list(live.tree$SPECIES, live.tree$DA), FUN = NROW)
  
  for(s in 1:999){
    print(paste("Trial Number: ",s,sep = ''))
    
    #remove and rewrite
    rm(fake.tree)
    rm(subset)
    rm(ABAM.hetcon)
    rm(TSHE.hetcon)
    rm(TABR.hetcon)
    rm(PSME.hetcon)
    rm(ACCI.hetcon)
    rm(ABAM.gen)
    rm(PSME.gen)
    rm(TABR.gen)
    rm(TSHE.gen)
    rm(ACCI.gen)
    rm(tree.cox)
    rm(table.6)
    rm(table.6b)
    
    # randomize mortality
    fake.tree <- NA
    for(j in spplist1){
      subset <- new.tree[new.tree$SPECIES == j,]
      
      subset$DA <- c(rep(1,length=nmorts[nmorts$Group.2==1 & nmorts$Group.1==j, 'x']), 
                     rep(0,length=nmorts[nmorts$Group.2==0 & nmorts$Group.1==j, 'x']))
      
      subset$DA <- sample(subset$DA)
      
      subset[subset$DA == 1, 'MORT_DATE'] <- sample(rep(2012:2019, length=nrow(subset[subset$DA == 1,])))
      
      fake.tree <- rbind(fake.tree, subset)
    }      
    fake.tree <- fake.tree[-1,]
    
    ##############################################################################################################################################
    
    ##############################################################################################################################################-
    #########################################              COX REGRESSION - AGENT GENERIC              ###########################################-
    {
      ##################################################             MAKE DATAFRAMES              #############################################-
      {
        #create data
        
        timeframe<-2020-2012
        tree.cox<-fake.tree[,c('STEM_TAG','SPECIES','CENSUS','MORT_DATE','IN_YR','BIOMASS_DBH','DBH_BIN','DA','conifer',neighbor.predictors)]
        tree.cox<-do.call("rbind", replicate(timeframe, tree.cox, simplify = FALSE))
        tree.cox<-tree.cox[order(tree.cox$STEM_TAG),]
        nrows<-nrow(tree.cox)
        tree.cox$CENSUS<-rep(paste(2012:2019),(nrows/timeframe))
        tree.cox<-merge(tree.cox,def.snow,by='CENSUS')
        tree.cox<-tree.cox[order(tree.cox$STEM_TAG),]
        
        #remove trees from earlier censuses that were ingrowth later on
        tree.cox<-tree.cox[(is.na(tree.cox$IN_YR)==F&tree.cox$CENSUS>=tree.cox$IN_YR)|is.na(tree.cox$IN_YR)==T,]
        
        #set DA to change to dead in year that tree died, then remove subsequent years for dead trees
        tree.cox$DA<-0
        tree.cox[is.na(tree.cox$MORT_DATE)==F&tree.cox$CENSUS>=tree.cox$MORT_DATE,'DA']<-1
        tree.cox<-tree.cox[(is.na(tree.cox$MORT_DATE)==F&tree.cox$CENSUS<=tree.cox$MORT_DATE)|is.na(tree.cox$MORT_DATE)==T,]
        # test<-fake.tree[fake.tree$MORT_DATE==2015&is.na(fake.tree$MORT_DATE)==F,'STEM_TAG'] #trees that died in 2015
        # tree.cox[tree.cox$STEM_TAG%in%test,] #make sure DA changes on appropriate date and subsequent entries are deleted (once it's dead, it's out of dataset)
        
        tree.cox[is.na(tree.cox$MORT_DATE)==T,'MORT_DATE']<-90
        tree.cox[tree.cox$MORT_DATE==2011&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-0
        tree.cox[tree.cox$MORT_DATE==2012&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-1
        tree.cox[tree.cox$MORT_DATE==2013&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-2
        tree.cox[tree.cox$MORT_DATE==2014&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-3
        tree.cox[tree.cox$MORT_DATE==2015&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-4
        tree.cox[tree.cox$MORT_DATE==2016&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-5
        tree.cox[tree.cox$MORT_DATE==2017&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-6
        tree.cox[tree.cox$MORT_DATE==2018&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-7
        tree.cox[tree.cox$MORT_DATE==2019&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-8
        
        tree.cox[tree.cox$CENSUS==2011&is.na(tree.cox$CENSUS)==F,'CENSUS']<-0
        tree.cox[tree.cox$CENSUS==2012&is.na(tree.cox$CENSUS)==F,'CENSUS']<-1
        tree.cox[tree.cox$CENSUS==2013&is.na(tree.cox$CENSUS)==F,'CENSUS']<-2
        tree.cox[tree.cox$CENSUS==2014&is.na(tree.cox$CENSUS)==F,'CENSUS']<-3
        tree.cox[tree.cox$CENSUS==2015&is.na(tree.cox$CENSUS)==F,'CENSUS']<-4
        tree.cox[tree.cox$CENSUS==2016&is.na(tree.cox$CENSUS)==F,'CENSUS']<-5
        tree.cox[tree.cox$CENSUS==2017&is.na(tree.cox$CENSUS)==F,'CENSUS']<-6
        tree.cox[tree.cox$CENSUS==2018&is.na(tree.cox$CENSUS)==F,'CENSUS']<-7
        tree.cox[tree.cox$CENSUS==2019&is.na(tree.cox$CENSUS)==F,'CENSUS']<-8
        
        tree.cox$CENSUS<-as.numeric(tree.cox$CENSUS)
        
        tree.cox[is.na(tree.cox)==T]<-0
        tree.cox[which(tree.cox==Inf)]<-0
        
        #get data per spp
        for(i in spplist1){
          species<-tree.cox[tree.cox$SPECIES==i,]
          assign(paste(i,'gen',sep='.'),species)
        }
        rm(species)
        
      }
      
      ##################################################                RUN MODELS              #############################################-
      for(i in spplist1){
        print(paste("Species Model: ",i,sep=''))
        
        datt<-paste(i,'gen',sep='.')
        
        temp<-coxph(Surv(time=CENSUS,event=DA)~BIOMASS_DBH+cluster(STEM_TAG)+(deflag1+zscore.Hegyi.het+snowppack+elev.diff)^4+
                      (deflag1+zscore.Hegyi.con+snowppack+elev.diff)^4, data=eval(parse(text=datt)))
        
        assign(paste(i,'hetcon',sep='.'),temp)
        
        rm(temp,datt)
      }
      
      
      save(ABAM.hetcon, PSME.hetcon, TABR.hetcon,TSHE.hetcon, 
           file=paste('./OUTPUT/Cox/SENSITIVITY_5/all_models_hetcon','num',s,format(Sys.time(),'%Y%m%d'),'Rdata',sep='.'))
      
      
      ########### make master table - HR ###########-
      {
        table.6<-data.frame()
        for(i in spplist1){
          model<-eval(parse(text=paste(i,'hetcon',sep='.')))
          
          for(j in names(model$coefficients)){
            table.6[j,i]<-(exp(model$coefficients[j])-1)*100
          }
          t<-ifelse(summary(model)$coefficients[,6]<0.001,'***',
                    ifelse(summary(model)$coefficients[,6]<0.01,'**',
                           ifelse(summary(model)$coefficients[,6]<0.05,'*','')))
          t2<-ifelse(table.6[is.na(table.6[,i])==F,i]<0,"'- ","'+ ")
          t3<-as.character(abs(round(table.6[is.na(table.6[,i])==F,i],2)))
          t3[t3==0]<-'< 0.01'
          table.6[is.na(table.6[,i])==F,i]<-as.character(paste(t2,t3,'% ',t,sep=''))
        }
        table.6$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',rownames(table.6))
        table.6$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',rownames(table.6))
        table.6$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',table.6$`Pretty Names`)
        table.6$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',table.6$`Pretty Names`)
        table.6$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',table.6$`Pretty Names`)
        table.6[order(table.6$`Pretty Names`),]
        
        save(table.6,file=paste('./OUTPUT/Cox/SENSITIVITY_5/HetCon.table.HR','num',s,format(Sys.time(),'%Y%m%d'),'Rdata',sep='.'))
      }
      
      ########### make master table - BETAS ###########-
      {
        table.6b<-data.frame()
        for(i in spplist1){
          model<-eval(parse(text=paste(i,'hetcon',sep='.')))
          for(j in names(model$coefficients)){
            table.6b[j,i]<-as.numeric(model$coefficients[j])
          } # remove following section to make BETA table for climate_projections usage, keep for MS table
          # t<-ifelse(summary(model)$coefficients[,6]<0.001,'***',
          #           ifelse(summary(model)$coefficients[,6]<0.01,'**',
          #                  ifelse(summary(model)$coefficients[,6]<0.05,'*','')))
          # t2<-ifelse(table.6b[is.na(table.6b[,i])==F,i]<0,"'- ","'+ ")
          # t3<-as.character(abs(round(table.6b[is.na(table.6b[,i])==F,i],3)))
          # t3[t3==0]<-paste('t')
          # table.6b[is.na(table.6b[,i])==F,i]<-as.character(paste(t2,t3,t,sep=''))
          
        }
        table.6b$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',rownames(table.6b))
        table.6b$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',table.6b$`Pretty Names`)
        table.6b$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',table.6b$`Pretty Names`)
        table.6b$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',table.6b$`Pretty Names`)
        table.6b$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',table.6b$`Pretty Names`)
        table.6b[order(table.6b$`Pretty Names`),]
        
        
        save(table.6b,file=paste('./OUTPUT/Cox/SENSITIVITY_5/HetCon.table.BETAS','num',s,format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
      }
      
      
    }
    
    
  }
  
} ## USED


##############################################################################################################################################

##############################################################################################################################################-
##################################################         MAKE SUMMARIES FOR FIGURES         ################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

## data used
load('./OUTPUT/Cox/SENSITIVITY_4/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH_20200711_heg10b.Rdata') # OBSERVED / REAL MODEL
MY.MODEL <- table.6b
rm(table.6b)


### baseline data
mass.ABAM <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=999)); rownames(mass.ABAM) <- rownames(MY.MODEL)
mass.PSME <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=999)); rownames(mass.PSME) <- rownames(MY.MODEL)
mass.TABR <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=999)); rownames(mass.TABR) <- rownames(MY.MODEL)
mass.TSHE <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=999)); rownames(mass.TSHE) <- rownames(MY.MODEL)
mass.ACCI <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=999)); rownames(mass.ACCI) <- rownames(MY.MODEL)

for(s in 1:999){
 load(paste('./OUTPUT/Cox/SENSITIVITY_5/', grep(pattern = paste('HetCon.table.BETAS.num.',s,'.',sep=''),
      x = dir("./OUTPUT/Cox/SENSITIVITY_5/"), fixed = T, value = T), sep=''))
    
  # assign(paste("betas",s,sep='.'),table.6b)
  mass.ABAM[,s] <- table.6b[,1]
  mass.PSME[,s] <- table.6b[,2]
  mass.TABR[,s] <- table.6b[,3]
  mass.TSHE[,s] <- table.6b[,4]
  mass.ACCI[,s] <- table.6b[,5]
  }
rm(table.6b)


### make summary tables 
quant.probs <- c(0.025,0.5,0.975)

summary.ABAM <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=7)); rownames(summary.ABAM) <- rownames(MY.MODEL); colnames(summary.ABAM) <- c('upper','lower','min','med','max','point.est','envelope')
summary.PSME <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=7)); rownames(summary.PSME) <- rownames(MY.MODEL); colnames(summary.PSME) <- c('upper','lower','min','med','max','point.est','envelope')
summary.TABR <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=7)); rownames(summary.TABR) <- rownames(MY.MODEL); colnames(summary.TABR) <- c('upper','lower','min','med','max','point.est','envelope')
summary.TSHE <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=7)); rownames(summary.TSHE) <- rownames(MY.MODEL); colnames(summary.TSHE) <- c('upper','lower','min','med','max','point.est','envelope')
summary.ACCI <- as.data.frame(matrix(nrow=nrow(MY.MODEL),ncol=7)); rownames(summary.ACCI) <- rownames(MY.MODEL); colnames(summary.ACCI) <- c('upper','lower','min','med','max','point.est','envelope')

### find the minimum and maximum estimates to create null envelope
for(i in 1:nrow(MY.MODEL)){
  quant.ABAM <- quantile(mass.ABAM[i,],probs=quant.probs, na.rm = TRUE)
  summary.ABAM[i,'upper'] <- quant.ABAM[3] + (1.5*(quant.ABAM[3] - quant.ABAM[1]))
  summary.ABAM[i,'lower'] <- quant.ABAM[1] - (1.5*(quant.ABAM[3] - quant.ABAM[1]))
  summary.ABAM[i,'min'] <- quant.ABAM[1]
  summary.ABAM[i,'med'] <- quant.ABAM[2]
  summary.ABAM[i,'max'] <- quant.ABAM[3]
  summary.ABAM[i,'point.est'] <- MY.MODEL[i,1]
  summary.ABAM[i,'envelope'] <- ifelse((summary.ABAM[i,'point.est']<summary.ABAM[i,'max'] & summary.ABAM[i,'point.est']>summary.ABAM[i,'min']),'in','out')
  
  quant.PSME <- quantile(mass.PSME[i,],probs=quant.probs, na.rm = TRUE)
  summary.PSME[i,'upper'] <- quant.PSME[3] + (1.5*(quant.PSME[3] - quant.PSME[1]))
  summary.PSME[i,'lower'] <- quant.PSME[1] - (1.5*(quant.PSME[3] - quant.PSME[1]))
  summary.PSME[i,'min'] <- quant.PSME[1]
  summary.PSME[i,'med'] <- quant.PSME[2]
  summary.PSME[i,'max'] <- quant.PSME[3]
  summary.PSME[i,'point.est'] <- MY.MODEL[i,1]
  summary.PSME[i,'envelope'] <- ifelse((summary.PSME[i,'point.est']<summary.PSME[i,'max'] & summary.PSME[i,'point.est']>summary.PSME[i,'min']),'in','out')
  
  quant.TABR <- quantile(mass.TABR[i,],probs=quant.probs, na.rm = TRUE)
  summary.TABR[i,'upper'] <- quant.TABR[3] + (1.5*(quant.TABR[3] - quant.TABR[1]))
  summary.TABR[i,'lower'] <- quant.TABR[1] - (1.5*(quant.TABR[3] - quant.TABR[1]))
  summary.TABR[i,'min'] <- quant.TABR[1]
  summary.TABR[i,'med'] <- quant.TABR[2]
  summary.TABR[i,'max'] <- quant.TABR[3]
  summary.TABR[i,'point.est'] <- MY.MODEL[i,1]
  summary.TABR[i,'envelope'] <- ifelse((summary.TABR[i,'point.est']<summary.TABR[i,'max'] & summary.TABR[i,'point.est']>summary.TABR[i,'min']),'in','out')
  
  quant.TSHE <- quantile(mass.TSHE[i,],probs=quant.probs, na.rm = TRUE)
  summary.TSHE[i,'upper'] <- quant.TSHE[3] + (1.5*(quant.TSHE[3] - quant.TSHE[1]))
  summary.TSHE[i,'lower'] <- quant.TSHE[1] - (1.5*(quant.TSHE[3] - quant.TSHE[1]))
  summary.TSHE[i,'min'] <- quant.TSHE[1]
  summary.TSHE[i,'med'] <- quant.TSHE[2]
  summary.TSHE[i,'max'] <- quant.TSHE[3]
  summary.TSHE[i,'point.est'] <- MY.MODEL[i,1]
  summary.TSHE[i,'envelope'] <- ifelse((summary.TSHE[i,'point.est']<summary.TSHE[i,'max'] & summary.TSHE[i,'point.est']>summary.TSHE[i,'min']),'in','out')
  
  quant.ACCI <- quantile(mass.ACCI[i,],probs=quant.probs, na.rm = TRUE)
  summary.ACCI[i,'upper'] <- quant.ACCI[3] + (1.5*(quant.ACCI[3] - quant.ACCI[1]))
  summary.ACCI[i,'lower'] <- quant.ACCI[1] - (1.5*(quant.ACCI[3] - quant.ACCI[1]))
  summary.ACCI[i,'min'] <- quant.ACCI[1]
  summary.ACCI[i,'med'] <- quant.ACCI[2]
  summary.ACCI[i,'max'] <- quant.ACCI[3]
  summary.ACCI[i,'point.est'] <- MY.MODEL[i,1]
  summary.ACCI[i,'envelope'] <- ifelse((summary.ACCI[i,'point.est']<summary.ACCI[i,'max'] & summary.ACCI[i,'point.est']>summary.ACCI[i,'min']),'in','out')

  }

### convert betas to hazard ratios
summary.ABAM[1:6]<- exp(summary.ABAM[1:6])
summary.PSME[1:6]<- exp(summary.PSME[1:6])
summary.TABR[1:6]<- exp(summary.TABR[1:6])
summary.TSHE[1:6]<- exp(summary.TSHE[1:6])
summary.ACCI[1:6]<- exp(summary.ACCI[1:6])

### make rownames a column so you can use facet_wrap
summary.ABAM$predictor<- rownames(summary.ABAM)
summary.PSME$predictor<- rownames(summary.ABAM)
summary.TABR$predictor<- rownames(summary.ABAM)
summary.TSHE$predictor<- rownames(summary.ABAM)
summary.ACCI$predictor<- rownames(summary.ABAM)

mass.ABAM<-melt(t(mass.ABAM))
mass.PSME<-melt(t(mass.PSME))
mass.TABR<-melt(t(mass.TABR))
mass.TSHE<-melt(t(mass.TSHE))
mass.ACCI<-melt(t(mass.ACCI))

##############################################################################################################################################

##############################################################################################################################################-
##############################################                COMPARISON PLOT S13                #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

## data used
load('./OUTPUT/Cox/SENSITIVITY_4/all_models_hetcon_w2019_wo2011_scaledHegyis_noMECH_20200710_heg10b.Rdata')
namesX=MY.MODEL$`Pretty Names`


### plot stuff - boxplots 

lims <- c(0,2.5)

cm_ABAM <- coef.tbl(ABAM.hetcon)
cm_ABAM$m.names=factor(namesX, levels=rev(namesX))
mass.ABAM$value <- exp(mass.ABAM$value)

mass.ABAM$raw_names<-gsub(pattern='deflag1',replacement='Deficit',mass.ABAM$Var2)
mass.ABAM$raw_names<-gsub(pattern='snowppack',replacement='snow',mass.ABAM$raw_names)
mass.ABAM$raw_names<-gsub(pattern='elev.diff',replacement='watertable',mass.ABAM$raw_names)
mass.ABAM$raw_names<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',mass.ABAM$raw_names)
mass.ABAM$raw_names<-gsub(pattern='HEGYI',replacement='Hegyi',mass.ABAM$raw_names)
mass.ABAM$raw_names<-gsub(pattern='Neighbors.richness',replacement='richness',mass.ABAM$raw_names)
mass.ABAM$raw_names<-gsub(pattern='BIOMASS_DBH',replacement='DBH',mass.ABAM$raw_names)
mass.ABAM$m.names <- factor(mass.ABAM$raw_names, levels=rev(unique(mass.ABAM$raw_names)))

ABAM <- ggplot(data=mass.ABAM, aes(x=m.names, y=value, fill = 'grey')) + 
  geom_boxplot(outlier.shape = NA, position = 'dodge') + 
  theme_classic()  + coord_flip(ylim = lims) +
  geom_point(data=cm_ABAM, aes(y = hazard, fill='', 
                               shape = as.factor(signif), color = 'red'), size = 2) +
  geom_hline(linetype='dashed', aes(yintercept=1))+
  theme(legend.position="none") +xlab('')+  ylab('') +
  theme(axis.text.y=element_blank())+ 
  scale_fill_brewer(palette="BuPu")


########### PSME ################-
cm_PSME <- coef.tbl(PSME.hetcon)
cm_PSME$m.names=factor(namesX, levels=rev(namesX))

mass.PSME$value <- exp(mass.PSME$value)

mass.PSME$raw_names<-gsub(pattern='deflag1',replacement='Deficit',mass.PSME$Var2)
mass.PSME$raw_names<-gsub(pattern='snowppack',replacement='snow',mass.PSME$raw_names)
mass.PSME$raw_names<-gsub(pattern='elev.diff',replacement='watertable',mass.PSME$raw_names)
mass.PSME$raw_names<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',mass.PSME$raw_names)
mass.PSME$raw_names<-gsub(pattern='HEGYI',replacement='Hegyi',mass.PSME$raw_names)
mass.PSME$raw_names<-gsub(pattern='Neighbors.richness',replacement='richness',mass.PSME$raw_names)
mass.PSME$raw_names<-gsub(pattern='BIOMASS_DBH',replacement='DBH',mass.PSME$raw_names)
mass.PSME$m.names <- factor(mass.PSME$raw_names, levels=rev(unique(mass.PSME$raw_names)))

PSME <- ggplot(data=mass.PSME, aes(x=m.names, y=value, fill = 'grey')) + 
  geom_boxplot(outlier.shape = NA, position = 'dodge') + 
  theme_classic()  + coord_flip(ylim = lims) +
  geom_point(data=cm_PSME, aes(y = hazard, fill='', 
                               shape = as.factor(signif), color = 'red'), size = 2) +
  geom_hline(linetype='dashed', aes(yintercept=1))+
  theme(legend.position="none") +xlab('')+  ylab('')+theme(axis.text.y=element_blank())+ 
  scale_fill_brewer(palette="BuPu")


########### TABR ################-
cm_TABR <- coef.tbl(TABR.hetcon)
cm_TABR$m.names=factor(namesX, levels=rev(namesX))

mass.TABR$value <- exp(mass.TABR$value)

mass.TABR$raw_names<-gsub(pattern='deflag1',replacement='Deficit',mass.TABR$Var2)
mass.TABR$raw_names<-gsub(pattern='snowppack',replacement='snow',mass.TABR$raw_names)
mass.TABR$raw_names<-gsub(pattern='elev.diff',replacement='watertable',mass.TABR$raw_names)
mass.TABR$raw_names<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',mass.TABR$raw_names)
mass.TABR$raw_names<-gsub(pattern='HEGYI',replacement='Hegyi',mass.TABR$raw_names)
mass.TABR$raw_names<-gsub(pattern='Neighbors.richness',replacement='richness',mass.TABR$raw_names)
mass.TABR$raw_names<-gsub(pattern='BIOMASS_DBH',replacement='DBH',mass.TABR$raw_names)
mass.TABR$m.names <- factor(mass.TABR$raw_names, levels=rev(unique(mass.TABR$raw_names)))

TABR <- ggplot(data=mass.TABR, aes(x=m.names, y=value, fill = 'grey')) + 
  geom_boxplot(outlier.shape = NA, position = 'dodge') + 
  theme_classic()  + coord_flip(ylim = lims) +
  geom_point(data=cm_TABR, aes(y = hazard, fill='', 
                               shape = as.factor(signif), color = 'red'), size = 2) +
  geom_hline(linetype='dashed', aes(yintercept=1))+
  theme(legend.position="none") +xlab('')+  ylab('')+theme(axis.text.y=element_blank())+ 
  scale_fill_brewer(palette="BuPu")


########### TSHE ################-
cm_TSHE <- coef.tbl(TSHE.hetcon)
cm_TSHE$m.names=factor(namesX, levels=rev(namesX))

mass.TSHE$value <- exp(mass.TSHE$value)

mass.TSHE$raw_names<-gsub(pattern='deflag1',replacement='Deficit',mass.TSHE$Var2)
mass.TSHE$raw_names<-gsub(pattern='snowppack',replacement='snow',mass.TSHE$raw_names)
mass.TSHE$raw_names<-gsub(pattern='elev.diff',replacement='watertable',mass.TSHE$raw_names)
mass.TSHE$raw_names<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',mass.TSHE$raw_names)
mass.TSHE$raw_names<-gsub(pattern='HEGYI',replacement='Hegyi',mass.TSHE$raw_names)
mass.TSHE$raw_names<-gsub(pattern='Neighbors.richness',replacement='richness',mass.TSHE$raw_names)
mass.TSHE$raw_names<-gsub(pattern='BIOMASS_DBH',replacement='DBH',mass.TSHE$raw_names)
mass.TSHE$m.names <- factor(mass.TSHE$raw_names, levels=rev(unique(mass.TSHE$raw_names)))

TSHE <- ggplot(data=mass.TSHE, aes(x=m.names, y=value, fill = 'grey')) + 
  geom_boxplot(outlier.shape = NA, position = 'dodge') + 
  theme_classic()  + coord_flip(ylim = lims) +
  geom_point(data=cm_TSHE, aes(y = hazard, fill='', 
                               shape = as.factor(signif), color = 'red'), size = 2) +
  geom_hline(linetype='dashed', aes(yintercept=1))+
  theme(legend.position="none") +xlab('')+  ylab('')+theme(axis.text.y=element_blank())+ 
  scale_fill_brewer(palette="BuPu")


########### ACCI ################-
cm_ACCI <- coef.tbl(ACCI.hetcon)
cm_ACCI$m.names=factor(namesX, levels=rev(namesX))

mass.ACCI$value <- exp(mass.ACCI$value)

mass.ACCI$raw_names<-gsub(pattern='deflag1',replacement='Deficit',mass.ACCI$Var2)
mass.ACCI$raw_names<-gsub(pattern='snowppack',replacement='snow',mass.ACCI$raw_names)
mass.ACCI$raw_names<-gsub(pattern='elev.diff',replacement='watertable',mass.ACCI$raw_names)
mass.ACCI$raw_names<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',mass.ACCI$raw_names)
mass.ACCI$raw_names<-gsub(pattern='HEGYI',replacement='Hegyi',mass.ACCI$raw_names)
mass.ACCI$raw_names<-gsub(pattern='Neighbors.richness',replacement='richness',mass.ACCI$raw_names)
mass.ACCI$raw_names<-gsub(pattern='BIOMASS_DBH',replacement='DBH',mass.ACCI$raw_names)
mass.ACCI$m.names <- factor(mass.ACCI$raw_names, levels=rev(unique(mass.ACCI$raw_names)))

ACCI <- ggplot(data=mass.ACCI, aes(x=m.names, y=value, fill = 'grey')) + 
  geom_boxplot(outlier.shape = NA, position = 'dodge') + 
  theme_classic()  + coord_flip(ylim = lims) +
  geom_point(data=cm_ACCI, aes(y = hazard, fill='', 
                               shape = as.factor(signif), color = 'red'), size = 2) +
  geom_hline(linetype='dashed', aes(yintercept=1))+
  theme(legend.position="none") +xlab('')+  ylab('')+theme(axis.text.y=element_blank())+ 
  scale_fill_brewer(palette="BuPu")


##############################################-

plot<-plot_grid(ABAM,PSME,TABR,TSHE,ACCI, nrow=2, ncol=3, align='v')
x.grob<-textGrob("Hazard Ratio", gp=gpar(col="black", fontsize=10))

dev.new()

tiff(file=paste('./Papers/Final Manuscript Documents/Review_1/','Sensitivity_5_Box_Fig_heg10b','.tif',sep=''),width=14,height=10,res=600,units='in',compression='lzw')
gridExtra::grid.arrange(arrangeGrob(plot, bottom = x.grob))
dev.off()




blank <- ggplot(data=mass.VAPA, aes(x=m.names, y=value, fill=Var1_fact)) + 
  geom_boxplot(outlier.shape = NA, position = 'dodge') + 
  coord_flip(ylim = lims) +
  geom_point(data=cm_VAPA, aes(y = hazard, fill='', 
                               shape = as.factor(signif), color = 'red'), size = 2) +
  geom_hline(linetype='dashed', aes(yintercept=1)) + xlab('')+ ylab('')+
  # theme(legend.position="none") + 
  scale_fill_brewer(palette="BuPu") + theme_prefs

tiff(file=paste('./Papers/Final Manuscript Documents/Review 2/','Sensitivity_5_Box_Fig_Blank','.tif',sep=''),tiff,width=4,height=4.95,res=600,units='in',compression='lzw')
blank
dev.off()

##############################################################################################################################################

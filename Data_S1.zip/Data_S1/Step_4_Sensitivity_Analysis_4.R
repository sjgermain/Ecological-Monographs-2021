## Wind River Stability - Survival Analysis ##
## Sensitivity Analysis FOUR ##
## Sara Germain ##
## March 2021 ##

### before running, search and replace all to shift between _exp, _invsq, _heg50,  _heg50b, _heg50. Combine results in photoshop for figure S11
### _heg50b chosen for publication

setwd("WFDP_Demography_20200303")



RUN.WATERBALANCE=F
RUN.PRISM.SUMMARY=F

LOAD.CLIMATE=T
RUN.PRISM.SUMMARY=F

RUN.BETAS=F
RUN.VAR.SUMMARY=F
RUN.FUNC.CALC=F
RUN.PERMUTATIONS=F


##############################################################################################################################################-
##############################################              LIBRARIES AND FUNCTIONS              #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

library("survival")
library('dplyr')
library('ggplot2')
library('nlme')
library('grid')
library('gridExtra')
library('cowplot')

distance = function(focal.x,focal.y,other.x,other.y){
  return(sqrt((focal.x-other.x)^2+(focal.y-other.y)^2))
}
BA.function = function(tree.DBH){
  return(0.0001*(pi*((0.5*tree.DBH)^2)))
}
mround<-function(x,base){
  base*round((x-(base/2-0.1))/base)
}
right <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

left <- function(x, n){
  substr(x, 1, n)
}

#calculate neighborhood influence values for each stem
kern.heg <- function(focal.DBH, neighbor.DBH, distance){
  return(neighbor.DBH/(focal.DBH*(1+distance)))
}

kern.exp <- function(focal.DBH, neighbor.DBH, distance){
  return(neighbor.DBH/(focal.DBH*(exp(1+distance))))
}

kern.invsq <- function(focal.DBH, neighbor.DBH, distance){
  return(neighbor.DBH/(focal.DBH*(1+distance)^2))
}

#standardizing function for species-specific influences
stand = function(focal.influence,mean.influence,sd.influence){
  (focal.influence-mean.influence)/sd.influence
}

#centering function
center = function(focal.influence,mean.influence){
  focal.influence-mean.influence
}


theme_prefs<-theme_classic() + theme(axis.title.x = element_text(size=8),
                                     axis.title.y = element_text(size=8),
                                     axis.text.x = element_text(size=8, colour='black'),
                                     axis.text.y = element_text(size=8, colour='black'),
                                     axis.ticks = element_line(colour='black'),
                                     legend.text = element_text(size=8),
                                     legend.title = element_text(size=8),
                                     plot.title=element_text(size=10,hjust=0.5, vjust=-3))

##############################################################################################################################################

##############################################################################################################################################-
##################################################      RUN SENSITIVITY - Neighborhoods       ################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

### Set up
kernals <- c('kern.exp','kern.heg','kern.invsq')

tree<-read.csv("./DATA/WFDP_Tree_20200305.csv", na.strings='NULL') #SQL code = SELECT STEM_TAG, TREE_TAG, CENSUS, DATE, DBH_DATE, IN_YR, QUADRAT, SPECIES, DBH, GROWTH_DBH, BIOMASS_DBH, STATUS, MORT_DATE, VIGOR, DA, SC, SNAG_HEIGHT, SNAG_TD, PLOT_X, PLOT_Y, UTM_X, UTM_Y, RELATIVE_PLOT_X, RELATIVE_PLOT_Y, COMMENT, NURSE_LOG, ES, MT, LEANER_ANGLE FROM `Tree` WHERE QUADRAT not like 'Q%'
tree[tree$CENSUS>17,"BIOMASS_DBH"] <- tree[tree$CENSUS>17,"DBH"]
tree<-tree[is.na(tree$BIOMASS_DBH)==F&is.na(tree$SPECIES)==F&is.na(tree$PLOT_X)==F&is.na(tree$PLOT_Y)==F,]

tree<-tree[tree$CENSUS>=17,]

n.tree<-nrow(tree)

dist.threshold.fixed<-50


### Mirror trees near edge of plot to correct for edge effects
tree.mirror<-tree[tree$PLOT_X<(0+dist.threshold.fixed),]
tree.mirror$PLOT_X<-tree.mirror$PLOT_X*-1
tree<-rbind(tree,tree.mirror)

tree.mirror<-tree[tree$PLOT_Y<(0+dist.threshold.fixed),]
tree.mirror$PLOT_Y<-tree.mirror$PLOT_Y*-1
tree<-rbind(tree,tree.mirror)

tree.mirror<-tree[tree$PLOT_X>(800-dist.threshold.fixed),]
tree.mirror$PLOT_X<-(800-tree.mirror$PLOT_X)+800
tree<-rbind(tree,tree.mirror)

tree.mirror<-tree[tree$PLOT_Y>(320-dist.threshold.fixed),]
tree.mirror$PLOT_Y<-(320-tree.mirror$PLOT_Y)+320
tree<-rbind(tree,tree.mirror)

plot(tree[tree$PLOT_X<=(0+dist.threshold.fixed)|tree$PLOT_X>(800-dist.threshold.fixed)|
            tree$PLOT_Y<=(0+dist.threshold.fixed)|tree$PLOT_Y>(320-dist.threshold.fixed),c('PLOT_X','PLOT_Y')])
plot(tree$PLOT_X,tree$PLOT_Y)

plot(x=0,y=0,type='n',xlim=c(-20,820),ylim=c(-20,340),ann=F)



### Run the thing 
start.row<-1
for(k in kernals){
  rm(new.tree)
  
  print(paste('now on',k,sep = ' '))
  hegyi <- eval(parse(text=k))
  
  #---------------------------------------------------------------------#
  
  for(h in c((1:(n.tree/200))*200,n.tree)){
    print(paste('identifying neighbors for',k,sep=' '))
    
    end.row<-h
    print(paste("start =",start.row))
    print(paste("end =",end.row))
    
    neighbors<-data.frame('FOCAL.STEM'=NA,'NEIGHBOR.STEM'=NA,'BIOMASS_DBH'=NA,'SPECIES'=NA,'STATUS'=NA,'MORT_DATE'=NA,'PITH.DISTANCE'=NA,'FACE.DISTANCE'=NA)
    neighbors<-neighbors[is.na(neighbors$FOCAL.STEM)==F,]
    neighbors$SPECIES<-factor(neighbors$SPECIES,levels=levels(tree$SPECIES))
    neighbors[,'FOCAL.STEM']<-factor(neighbors[,'FOCAL.STEM'],levels=levels(tree$STEM_TAG))
    neighbors[,'NEIGHBOR.STEM']<-factor(neighbors[,'NEIGHBOR.STEM'],levels=levels(tree$STEM_TAG))
    
    for(i in start.row:end.row){
      start<-Sys.time()
      #SUBSET TREE LIST TO SELECT TREES WITHIN DISTANCE OF +- dist.threshold OF FOCAL TREE PLOT_X AND PLOT_Y
      zone<-c(tree[i,c('PLOT_X','PLOT_Y')]+dist.threshold.fixed,tree[i,c('PLOT_X','PLOT_Y')]-dist.threshold.fixed)
      zone.trees<-tree[tree$PLOT_X<zone[1]&tree$PLOT_X>zone[3]&tree$PLOT_Y<zone[2]&tree$PLOT_Y>zone[4],]
      #CALCULATE EUCLIDIAN DISTANCE BETWEEN FOCAL TREE AND NEIGHBORS
      #GENERATE TREE LIST OF TREES WITHIN RADIUS OF dist.threshold AROUND FOCAL TREE
      focal.neighbors<-data.frame()
      
      neighbor.distances<-distance(tree[i,'PLOT_X'],tree[i,'PLOT_Y'],zone.trees[,'PLOT_X'],zone.trees[,'PLOT_Y'])
      
      focal.neighbors<-data.frame(zone.trees[,c('STEM_TAG','BIOMASS_DBH','SPECIES','STATUS','MORT_DATE')],"PITH.DISTANCE"=neighbor.distances,
                                  "FACE.DISTANCE"=neighbor.distances-tree[i,'BIOMASS_DBH']/200-zone.trees[,'BIOMASS_DBH']/200)
      
      focal.neighbors<-focal.neighbors[focal.neighbors$FACE.DISTANCE>0&focal.neighbors$PITH.DISTANCE<=dist.threshold.fixed&
                                         focal.neighbors$STEM_TAG!=tree[i,'STEM_TAG'],]
      
      #INSERT THIS TREE LIST INTO A MASTER NEIGHBOR DATA FRAME THAT WILL INCLUDE ALL NEIGHBORS FOR ALL TREES
      first.row<-nrow(neighbors)+1
      last.row<-first.row+nrow(focal.neighbors)-1
      neighbors[first.row:last.row,'FOCAL.STEM']<-tree[i,'STEM_TAG']
      neighbors[first.row:last.row,2:(ncol(focal.neighbors)+1)]<-focal.neighbors
      focal.dbh<-tree[tree$STEM_TAG==neighbors[first.row,'FOCAL.STEM'],'BIOMASS_DBH'][1]
      neighbors[first.row:last.row,'HEGYI']<-hegyi(focal.dbh,focal.neighbors$BIOMASS_DBH,focal.neighbors$FACE.DISTANCE)
      
      #PRINT STEM_TAG BEING PROCESSED AND REMAINING TIME
      elapse<-as.numeric(Sys.time()-start)
      print(paste('Calculating distances for ',tree[i,'STEM_TAG'],sep=''))
      print(paste("Time remaining: ",round(elapse*(n.tree-h),0)," minutes. Nice work!",sep=''))
      if(nrow(neighbors)>1000000) stop("error: nrow neighbors is over 1000000")
    }
    #---------------------------------------------------------------------#
    write.csv(x=neighbors,file=paste('./OUTPUT/Neighborhood/SENSITIVITY_4/',k,'/neighbors_',h,'_',format(Sys.time(),'%Y%m%d'),'.csv',sep=''))
    #---------------------------------------------------------------------#
    points(tree[start.row:end.row,c('PLOT_X','PLOT_Y')],pch=19)
    # Clear RAM:
    rm(neighbors)
    gc()
    memory.size()
    start.row<-h+1
  }
  
  #---------------------------------------------------------------------#
  
  neighbors<-data.frame()
  first<-1
  for(j in c(seq(50,length(dir(paste('./OUTPUT/Neighborhood/SENSITIVITY_4/',k,'/',sep=''))),20),
             length(dir(paste('./OUTPUT/Neighborhood/SENSITIVITY_4/',k,'/',sep=''))))){
    
    print(paste('compiling neighbors for',k,sep=' '))
    
    last<-j
    for (i in dir(paste('./OUTPUT/Neighborhood/SENSITIVITY_4/',k,'/',sep=''))[first:last]){
      temp<-read.csv(paste('./OUTPUT/Neighborhood/SENSITIVITY_4/',k,'/',i,sep=''))
      if(nrow(temp[as.character(temp$FOCAL.STEM)%in%as.character(neighbors$FOCAL.STEM)==T,])>=1) stop('error: repeated stem tags')
      temp$FOCAL.STEM<-as.character(temp$FOCAL.STEM)
      temp$NEIGHBOR.STEM<-as.character(temp$NEIGHBOR.STEM)
      neighbors<-rbind(neighbors,temp)
      print(i)
    }
    gc()
    memory.size()
    first<-j+1
  }
  
  write.csv(x=neighbors,file=paste('./OUTPUT/Neighborhood/SENSITIVITY_4/',k,'/neighbors_full_',format(Sys.time(),'%Y%m%d'),'.csv',sep=''))
  
  #---------------------------------------------------------------------#
  
  new.tree<-read.csv("./DATA/WFDP_tree_20200305.csv", na.strings='NULL') #SQL code = SELECT STEM_TAG, new.tree_TAG, CENSUS, DATE, DBH_DATE, IN_YR, QUADRAT, SPECIES, DBH, GROWTH_DBH, BIOMASS_DBH, STATUS, MORT_DATE, VIGOR, DA, SC, SNAG_HEIGHT, SNAG_TD, PLOT_X, PLOT_Y, UTM_X, UTM_Y, RELATIVE_PLOT_X, RELATIVE_PLOT_Y, COMMENT, NURSE_LOG, ES, MT, LEANER_ANGLE FROM `new.tree` WHERE QUADRAT not like 'Q%'
  new.tree[new.tree$CENSUS>17,"BIOMASS_DBH"] <- new.tree[new.tree$CENSUS>17,"DBH"]
  new.tree<-new.tree[is.na(new.tree$BIOMASS_DBH)==F&is.na(new.tree$SPECIES)==F&is.na(new.tree$PLOT_X)==F&is.na(new.tree$PLOT_Y)==F,]
  new.tree<-new.tree[new.tree$CENSUS>=17,]
  new.tree$BA<- BA.function(new.tree$BIOMASS_DBH)
  new.tree<-new.tree[!duplicated(new.tree$STEM_TAG),]
  
  for(i in 1:nrow(new.tree)){  
    print(paste('calculating metrics for',k,': now on ',as.character(new.tree[i,'STEM_TAG']),sep=' '))
    
    focal.new.tree.mort.date<-ifelse(is.na(new.tree[i,'MORT_DATE'])==T,3000,new.tree[i,'MORT_DATE'])
    
    
    if(new.tree[i,'MORT_DATE']==0&is.na(new.tree[i,'MORT_DATE'])==F) focal.new.tree.mort.date<-2010
    live.neighborhood<-neighbors[neighbors$FOCAL.STEM==as.character(new.tree[i,'STEM_TAG'])&(neighbors$MORT_DATE>=focal.new.tree.mort.date|is.na(neighbors$MORT_DATE)==T),2:ncol(neighbors)]
    
    new.tree[i,'live.HEGYI']<-sum(live.neighborhood$HEGYI)
    new.tree[i,'HEGYI.con']<-sum(live.neighborhood[live.neighborhood$SPECIES==new.tree[i,'SPECIES'],'HEGYI'])
    new.tree[i,'HEGYI.het']<-sum(live.neighborhood[live.neighborhood$SPECIES!=new.tree[i,'SPECIES'],'HEGYI'])
    
  }
  
  #---------------------------------------------------------------------#
  new.tree$SPECIES <- as.character(new.tree$SPECIES)
  new.tree$DBH_BIN <- NA
  new.tree$DBH_BIN<-mround(new.tree$BIOMASS_DBH,2)
  new.tree[new.tree$BIOMASS_DBH>=10,'DBH_BIN']<-mround(new.tree[new.tree$BIOMASS_DBH>=10,'DBH_BIN'],10)
  new.tree[new.tree$BIOMASS_DBH>=40,'DBH_BIN']<-mround(new.tree[new.tree$BIOMASS_DBH>=40,'DBH_BIN'],20)
  new.tree[new.tree$BIOMASS_DBH>=100,'DBH_BIN']<-100
  
  new.tree[is.na(new.tree$live.HEGYI)==T,'live.HEGYI']<-0
  new.tree[is.na(new.tree$HEGYI.con)==T,'HEGYI.con']<-0
  new.tree[is.na(new.tree$HEGYI.het)==T,'HEGYI.het']<-0
  
  #get hegyi mean / sd for standardizing hegyi by spp / size class
  tree.gr.summary1<-aggregate(new.tree$live.HEGYI,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=sd)
  tree.gr.summary1$count<-aggregate(new.tree$live.HEGYI,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=NROW)$x
  tree.gr.summary2<-aggregate(new.tree$live.HEGYI,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=mean)
  tree.gr.summary<-merge(tree.gr.summary1,tree.gr.summary2, by=c('Group.1','Group.2'))
  
  for(j in 1:nrow(new.tree)){
    new.tree[j,'sd.Hegyi'] <- tree.gr.summary[tree.gr.summary$Group.1==new.tree[j,'SPECIES']&tree.gr.summary$Group.2==new.tree[j,'DBH_BIN'],'x.x']
    new.tree[j,'mean.Hegyi'] <- tree.gr.summary[tree.gr.summary$Group.1==new.tree[j,'SPECIES']&tree.gr.summary$Group.2==new.tree[j,'DBH_BIN'],'x.y']
    new.tree[j,'zscore.Hegyi'] <-  stand(new.tree[j,'live.HEGYI'],new.tree[j,'mean.Hegyi'],new.tree[j,'sd.Hegyi'])
  }
  
  #get hegyi.con mean / sd for standardizing hegyi by spp / size class
  tree.gr.summary1<-aggregate(new.tree$HEGYI.con,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=sd)
  tree.gr.summary1$count<-aggregate(new.tree$HEGYI.con,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=NROW)$x
  tree.gr.summary2<-aggregate(new.tree$HEGYI.con,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=mean)
  tree.gr.summary<-merge(tree.gr.summary1,tree.gr.summary2, by=c('Group.1','Group.2')) 
  
  for(j in 1:nrow(new.tree)){  
    new.tree[j,'mean.Hegyi.con'] <- tree.gr.summary[tree.gr.summary$Group.1==new.tree[j,'SPECIES']&tree.gr.summary$Group.2==new.tree[j,'DBH_BIN'],'x.y']
    new.tree[j,'zscore.Hegyi.con'] <-  stand(new.tree[j,'HEGYI.con'],new.tree[j,'mean.Hegyi.con'],new.tree[j,'sd.Hegyi'])
    
  }  
  
  #get hegyi.het mean / sd for standardizing hegyi by spp / size class
  tree.gr.summary1<-aggregate(new.tree$HEGYI.het,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=sd)
  tree.gr.summary1$count<-aggregate(new.tree$HEGYI.het,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=NROW)$x
  tree.gr.summary2<-aggregate(new.tree$HEGYI.het,by=list(new.tree$SPECIES,new.tree$DBH_BIN),FUN=mean)
  tree.gr.summary<-merge(tree.gr.summary1,tree.gr.summary2, by=c('Group.1','Group.2')) 
  
  for(j in 1:nrow(new.tree)){  
    new.tree[j,'mean.Hegyi.het'] <- tree.gr.summary[tree.gr.summary$Group.1==new.tree[j,'SPECIES']&tree.gr.summary$Group.2==new.tree[j,'DBH_BIN'],'x.y']
    new.tree[j,'zscore.Hegyi.het'] <-  stand(new.tree[j,'HEGYI.het'],new.tree[j,'mean.Hegyi.het'],new.tree[j,'sd.Hegyi'])
    print(paste('FINAL STEPS for',k,':  ',as.character(new.tree[i,'STEM_TAG']),sep=' '))
  }  
  
  new.tree[is.na(new.tree$zscore.Hegyi)==T,'zscore.Hegyi']<-0
  new.tree[is.na(new.tree$zscore.Hegyi.con)==T,'zscore.Hegyi.con']<-0
  new.tree[is.na(new.tree$zscore.Hegyi.het)==T,'zscore.Hegyi.het']<-0
  
  #---------------------------------------------------------------------#
  write.csv(x=new.tree,file=paste('./OUTPUT/Neighborhood/SENSITIVITY_4/',k,'/WFDP_Tree_with_neighbors_',format(Sys.time(),'%Y%m%d'),'.csv',sep=''),row.names=F)
  #---------------------------------------------------------------------#
  
}


##############################################################################################################################################

##############################################################################################################################################-
################################################          ORGANIZE DATA FOR MODELS            ################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

#DATASET CHOICE
neighbors<-read.csv("./OUTPUT/Neighborhood/SENSITIVITY_4/WFDP_Tree_with_neighbors_20200710_heg50.csv",na.strings='NA')
neighbors<-neighbors[(neighbors$MORT_DATE>0 & is.na(neighbors$MORT_DATE)==F)|is.na(neighbors$MORT_DATE)==T,]
neighbors$STEM_TAG <- as.character(neighbors$STEM_TAG)
nrow(neighbors[duplicated(neighbors$STEM_TAG),]) # double check!

###------------###

#common species analyzed
spplist1<-c('ABAM','PSME','TABR','TSHE','ACCI')

#baseline data
trees<-read.csv("./DATA/WFDP_Tree_20200305.csv",na.strings='NULL') #SQL code = SELECT STEM_TAG, TREE_TAG, CENSUS, DATE, DBH_DATE, IN_YR, QUADRAT, SPECIES, DBH, GROWTH_DBH, BIOMASS_DBH, STATUS, MORT_DATE, VIGOR, DA, SC, SNAG_HEIGHT, SNAG_TD, PLOT_X, PLOT_Y, UTM_X, UTM_Y, RELATIVE_PLOT_X, RELATIVE_PLOT_Y, COMMENT, NURSE_LOG, ES, MT, LEANER_ANGLE FROM `Tree` WHERE QUADRAT not like 'Q%'
trees<-trees[(trees$MORT_DATE>0 & is.na(trees$MORT_DATE)==F)|is.na(trees$MORT_DATE)==T,]
trees[trees$CENSUS>17,"BIOMASS_DBH"] <- trees[trees$CENSUS>17,"DBH"]
trees<-trees[is.na(trees$BIOMASS_DBH)==F&is.na(trees$SPECIES)==F&is.na(trees$PLOT_X)==F&is.na(trees$PLOT_Y)==F,]
trees$STEM_TAG <- as.character(trees$STEM_TAG)

water<-read.csv("./OUTPUT/Neighborhood/WFDP_Tree_with_neighbors_20200306.csv",na.strings='NA')
water$STEM_TAG<-as.character(water$STEM_TAG)
trees<-merge(trees,water[,c('STEM_TAG','elev.diff')], by='STEM_TAG', all.x = T)

morts<-read.csv("./DATA/WFDP_Mortality_20200311.csv",na.strings='NULL')
morts$STEM_TAG <- as.character(morts$STEM_TAG)
mechanical<-morts[(is.na(morts$FAD1)==F & morts$FAD1 >=80) | 
                    (is.na(morts$FAD2)==F & morts$FAD2 >=80) |
                    (is.na(morts$FAD3)==F & morts$FAD3 >=80) |
                    (is.na(morts$FAD4)==F & morts$FAD4 >=80) |
                    (is.na(morts$FAD5)==F & morts$FAD5 >=80),]
fungus<-mechanical[(is.na(mechanical$FAD1)==F & mechanical$FAD1 %in% 60:65) | 
                     (is.na(mechanical$FAD2)==F & mechanical$FAD2 %in% 60:65) |
                     (is.na(mechanical$FAD3)==F & mechanical$FAD3 %in% 60:65) |
                     (is.na(mechanical$FAD4)==F & mechanical$FAD4 %in% 60:65) |
                     (is.na(mechanical$FAD5)==F & mechanical$FAD5 %in% 60:65),]

mechanical<-mechanical[!mechanical$STEM_TAG %in% fungus$STEM_TAG,]  

# restrict dataset to common species
live.tree<-trees[trees$CENSUS>=17,]
live.tree<-live.tree[live.tree$CENSUS<20,] # no ingrowth from most recent year; consider only trees that COULD die
nrow(live.tree[duplicated(live.tree$STEM_TAG),]) # double check!

live.tree<-merge(live.tree,neighbors[c(1,31:41)],by='STEM_TAG')
live.tree[live.tree$STEM_TAG=='23-0378','BIOMASS_DBH']<-14.9
live.tree$DA<-NA
live.tree$DA<-ifelse(live.tree$STATUS%in%c(1,2),0,1)

live.tree$SPECIES<-as.character(live.tree$SPECIES)
live.tree <- live.tree[live.tree$SPECIES %in% spplist1,]

live.tree<-live.tree[!live.tree$STEM_TAG %in% mechanical$STEM_TAG,] #omit trees that died from mechanical damage

#### examine structure of new data
summary(live.tree$zscore.Hegyi.con)
summary(live.tree$zscore.Hegyi.het)
nrow(live.tree[abs(live.tree$zscore.Hegyi.con>=4),])
nrow(live.tree[abs(live.tree$zscore.Hegyi.het>=4),])

#### standardize and center
# live.tree <- live.tree[abs(live.tree$zscore.Hegyi.het)<4 & abs(live.tree$zscore.Hegyi.con)<4,] #truncate dataset at +/- 4 SD
live.tree['elev.diff']<-apply(live.tree['elev.diff'],2,FUN= function(x){x-mean(x)}) #center elevation
live.tree['BIOMASS_DBH']<-apply(live.tree['BIOMASS_DBH'],1,FUN= function(x){log(x)}) #transform DBH 

live.tree$conifer<-ifelse(live.tree$SPECIES%in%c("TSHE","TABR","ABAM","PSME","THPL","ABGR","ABPR","PIMO"),1,0)
neighbor.predictors<-c("zscore.Hegyi.con","zscore.Hegyi.het","elev.diff")

#historical climate
if (RUN.WATERBALANCE==T) {
  
  ##############################################              LIBRARIES AND FUNCTIONS              #############################################-
  thornthwaite<-function (series, latitude, clim_norm = NULL, first.yr = NULL,last.yr = NULL, quant = c(0, 0.1, 0.25, 0.5, 0.75, 0.9, 1),
                          snow.init = 75, Tsnow = -1, TAW = 100, fr.sn.acc = 0.95,snow_melt_coeff = 1){
    
    ExAtRa<-function (DOY, latitude, Gsc = 0.082, unit = "mm", T = 12){
      phi <- latitude * pi/180
      delta <- 0.4093 * sin(2 * pi * (284 + DOY)/365)
      dr <- 1 + 0.033 * cos(2 * pi * DOY/365)
      omegaS <- acos(-tan(phi) * tan(delta))
      R_MJ <- (24 * (60)/pi) * Gsc * dr * ((omegaS) * sin(phi) * 
                                             sin(delta) + cos(phi) * cos(delta) * sin(omegaS))
      if (unit == "mm") {
        lambda <- 2.501 - 0.002361 * T
        R_H2O <- R_MJ/lambda
        return(R_H2O)
      }
      else if (unit == "MJ") 
        return(R_MJ)
      else print("Incorrect unit!", quote = FALSE)
    }
    
    daylength<-function (lat, doy){
      if (class(doy) == "Date" | class(doy) == "character") {
        doy <- as.character(doy)
        doy <- as.numeric(format(as.Date(doy), "%j"))
      }
      else {
        doy <- (doy - 1)%%365 + 1
      }
      lat[lat > 90 | lat < -90] <- NA
      P <- asin(0.39795 * cos(0.2163108 + 2 * atan(0.9671396 * 
                                                     tan(0.0086 * (doy - 186)))))
      a <- (sin(0.8333 * pi/180) + sin(lat * pi/180) * sin(P))/(cos(lat * 
                                                                      pi/180) * cos(P))
      a <- pmin(pmax(a, -1), 1)
      DL <- 24 - (24/pi) * acos(a)
      return(DL)
    }
    
    month_names <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    month_lengths <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 
                       30, 31)
    m <- c("min", paste(quant[-c(1, length(quant))] * 100, "%", 
                        sep = ""), "max")
    yDay <- strptime(paste(15, "/", 1:12, "/", 2014, sep = ""), 
                     format = "%d/%m/%Y")$yday + 1
    rel_daylength <- daylength(latitude, yDay)/12
    chg <- ExAtRa(DOY = yDay, latitude = latitude, unit = "mm")
    fTAW <- (-1.05e-07 * TAW^2 + 5.4225e-05 * TAW - 0.00878)
    ultStorPrA <- TAW
    if (is.null(first.yr)) 
      first.yr <- min(series$year)
    else first.yr <- max(first.yr, min(series$year))
    if (is.null(last.yr)) 
      last.yr <- max(series$year)
    else last.yr <- min(last.yr, max(series$year))
    years <- first.yr:last.yr
    tPrec <- seq(1:12)
    tET0 <- seq(1:12)
    tStor <- seq(1:12)
    tPmE <- seq(1:12)
    tDef <- seq(1:12)
    tSur <- seq(1:12)
    tPack <- seq(1:12)
    snowpack_jan <- snow.init
    for (ii in 1:length(years)) {
      zzz <- data.frame(series[series$year == years[ii], ])
      zzz <- data.frame(zzz$P, (zzz$Tn + zzz$Tx)/2, zzz$Tn, zzz$Tx)
      names(zzz) <- c("Prec1", "Tmean1", "Tn1", "Tx1")
      if (!is.null(clim_norm)) {
        zzz$Prec1[is.na(zzz$Prec1)] <- clim_norm$P[is.na(zzz$Prec1)]
        zzz$Tmean1[is.na(zzz$Tmean1)] <- clim_norm$Tm[is.na(zzz$Tmean1)]
        zzz$Tn1[is.na(zzz$Tn1)] <- clim_norm$Tn[is.na(zzz$Tn1)]
        zzz$Tx1[is.na(zzz$Tx1)] <- clim_norm$Tx[is.na(zzz$Tx1)]
      }
      if (sum(is.na(zzz$Prec1)) != 0 | sum(is.na(zzz$Tmean1)) != 
          0) 
        print(paste("Monthly values missing in year", first.yr + 
                      ii - 1), quote = FALSE)
      else {
        Prec <- zzz[, 1]
        Tmean <- zzz[, 2]
        Tn <- zzz[, 3]
        Tx <- zzz[, 4]
        Storage <- rep(TAW, length(Tmean))
        Percola <- rep(0, length(Tmean))
        TmeanCor <- Tmean
        TmeanCor[TmeanCor < 0] <- 0
        ITM <- ((TmeanCor/5)^1.514)
        ITA <- sum(ITM)
        exp <- 6.75e-07 * ITA^3 - 7.71e-05 * ITA^2 + 0.01792 * 
          ITA + 0.492
        PET <- (16 * (10 * TmeanCor/ITA)^exp) * rel_daylength
        SnowAcc <- rep(0, 12)
        SnowPrec <- Prec
        SnowPrec[Tmean >= Tsnow] <- 0
        month_max <- max(min(which(Tmean >= Tsnow) - 1), 
                         1)
        SnowAcc_wint <- NULL
        for (i in 1:month_max) {
          if (i == 1) 
            SnowAcc_wint[i] <- snowpack_jan + SnowPrec[i] * 
              fr.sn.acc
          else SnowAcc_wint[i] <- SnowAcc_wint[i - 1] + 
              SnowPrec[i] * fr.sn.acc
        }
        snowpack_ref <- SnowAcc_wint[month_max]
        snow_depl <- NULL
        SnowAcc[1] <- SnowAcc_wint[1]
        snow_depl[1] <- SnowPrec[1] * (1 - fr.sn.acc)
        if (Tmean[1] >= Tsnow) {
          snow_depl[1] <- snow_melt_coeff[1] * SnowAcc[1]
          SnowAcc[1] <- SnowAcc[1] - snow_depl[1]
        }
        count_thaw <- 0
        for (i in 2:12) {
          snow_depl[i] <- SnowPrec[i] * (1 - fr.sn.acc)
          SnowAcc[i] <- SnowAcc[i - 1] + SnowPrec[i] * 
            fr.sn.acc
          if (Tmean[i] >= Tsnow) {
            count_thaw <- count_thaw + 1
            if (count_thaw > length(snow_melt_coeff)) {
              snow_depl[i] <- SnowAcc[i]
            }
            else snow_depl[i] <- snow_depl[i] + SnowAcc[i] * 
                snow_melt_coeff[count_thaw]
          }
          SnowAcc[i] <- SnowAcc[i] - snow_depl[i]
        } 
        
        snowpack_jan <- SnowAcc[12]
        Liq_Prec <- Prec
        Liq_Prec[Tmean < Tsnow] <- Prec[Tmean < Tsnow] * 
          (1 - fr.sn.acc)
        P.minus.ET <- Liq_Prec + snow_depl - PET
        if (ii == 1) 
          last_Storage <- TAW
        if (!is.na(P.minus.ET[1]) & P.minus.ET[1] > 0) {
          Storage[1] <- last_Storage + P.minus.ET[1]
          if (Storage[1] > TAW) {
            Percola[1] <- Storage[1] - TAW
            Storage[1] <- TAW
          }
        }
        else {
          PETvir <- (log10(TAW) - log10(last_Storage))/fTAW
          Storage[1] <- TAW * 10^(-(PETvir + P.minus.ET[1]) * 
                                    fTAW)
        }
        for (i in 2:length(Storage)) {
          if (!is.na(P.minus.ET[i]) & P.minus.ET[i] > 0) {
            Storage[i] <- Storage[i - 1] + P.minus.ET[i]
            if (Storage[i] > TAW) {
              Percola[i] <- Storage[i] - TAW
              Storage[i] <- TAW
            }
          }
          else {
            PETvir <- (log10(TAW) - log10(Storage[i - 1]))/fTAW
            Storage[i] <- TAW * 10^(-(PETvir + P.minus.ET[i]) * 
                                      fTAW)
          }
        }
        last_Storage <- Storage[12]
        delta.sto <- c(0, diff(Storage))
        ETr <- (Liq_Prec + snow_depl - delta.sto)
        for (i in 1:length(ETr)) {
          if (P.minus.ET[i] > 0) 
            ETr[i] <- PET[i]
        }
        Def <- PET - ETr
        Def[Def < 0] <- 0
        Sur <- Liq_Prec + snow_depl - ETr - (TAW - Storage)
        Sur[Sur < 0] <- 0
        tPrec <- data.frame(tPrec, Prec)
        tET0 <- data.frame(tET0, PET)
        tStor <- data.frame(tStor, Storage)
        tPmE <- data.frame(tPmE, P.minus.ET)
        tDef <- data.frame(tDef, Def)
        tSur <- data.frame(tSur, Sur)
        tPack<- data.frame(tPack, SnowAcc)
        
      }
    }
    names(tPrec) <- c("Month", years)
    row.names(tPrec) <- month_names
    names(tET0) <- c("Month", years)
    row.names(tET0) <- month_names
    names(tStor) <- c("Month", years)
    row.names(tStor) <- month_names
    names(tPmE) <- c("Month", years)
    row.names(tPmE) <- month_names
    names(tDef) <- c("Month", years)
    row.names(tDef) <- month_names
    names(tSur) <- c("Month", years)
    row.names(tSur) <- month_names
    names(tPack) <- c("Month", years)
    row.names(tPack) <- month_names
    list_thornt <- list(round(tPrec[-1], 1), round(tET0[-1], 
                                                   1), round(tStor[-1], 1), round(tPmE[-1], 1), round(tDef[-1], 
                                                                                                      1), round(tSur[-1], 1),round(tPack[-1],1))
    names(list_thornt) <- c("Precipitation", "Et0", "Storage", 
                            "Prec. - Evap.", "Deficit", "Surplus","Pack")
    qPrec <- data.frame(quant)
    qET0 <- data.frame(quant)
    qStor <- data.frame(quant)
    qPmE <- data.frame(quant)
    qDef <- data.frame(quant)
    qSur <- data.frame(quant)
    ttPrec <- t(tPrec)
    ttET0 <- t(tET0)
    ttStor <- t(tStor)
    ttPmE <- t(tPmE)
    ttDef <- t(tDef)
    ttSur <- t(tSur)
    qPrec <- as.data.frame(apply(ttPrec[-1, ], FUN = quantile, 
                                 probs = quant, na.rm = T, MARGIN = 2))
    names(qPrec) <- month_names
    qET0 <- as.data.frame(apply(ttET0[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qET0) <- month_names
    qStor <- as.data.frame(apply(ttStor[-1, ], FUN = quantile, 
                                 probs = quant, na.rm = T, MARGIN = 2))
    names(qStor) <- month_names
    qPmE <- as.data.frame(apply(ttPmE[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qPmE) <- month_names
    qDef <- as.data.frame(apply(ttDef[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qDef) <- month_names
    qSur <- as.data.frame(apply(ttSur[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qSur) <- month_names
    list_quant <- list(round(qPrec, 1), round(qET0, 1), round(qStor, 
                                                              1), round(qPmE, 1), round(qDef, 1), round(qSur, 1),tPack)
    names(list_quant) <- names(list_thornt)
    list_2.lists <- list(W_balance = list_thornt, quantiles = list_quant)
    class(list_2.lists) <- "thornthwaite"
    return(list_2.lists)
  }
  
  ##################################################             MAKE DATAFRAMES              #############################################-
  {
    WFDP_clim_norm<-read.csv(file='./DATA/Climate/NEX PRISM 800-m/PRISM_800m_1981-2010normals.csv'); 
    WFDP_clim_norm<-cbind(x=c(1:13),WFDP_clim_norm)
    WFDP_clim_norm<-WFDP_clim_norm[1:12,];
    WFDP_norms<-cbind(WFDP_clim_norm[,3:6]);colnames(WFDP_norms)[1:4]<-c("P","Tn","Tx","Tm")
    WFDP_monthly<-read.csv(file='./DATA/Climate/NEX PRISM 800-m/PRISM_800m_2010-2019_monthly_forThornthwaite.csv')
  }
  
  ##################################################                RUN MODELS              #############################################-
  {
    WFDP_WB<-thornthwaite(series=WFDP_monthly,latitude=45.8197,clim_norm=WFDP_norms,TAW=120,Tsnow=0,snow_melt_coeff=c(0.8,0.8))
    
    WFDP_yearly_deficit<-data.frame("year"=c(2010:2019),"deficit"=NA)
    for(i in 2010:2019){
      WFDP_yearly_deficit[WFDP_yearly_deficit$year==i,2]<-sum(WFDP_WB$W_balance$Deficit[,colnames(WFDP_WB$W_balance$Deficit)==i])}
    
    WFDP_yearly_snowppack<-data.frame("year"=c(2010:2019),"snowppack"=NA)
    for(i in 2010:2019){
      WFDP_yearly_snowppack[WFDP_yearly_snowppack$year==i,2]<-max(WFDP_WB$W_balance$Pack[,colnames(WFDP_WB$W_balance$Pack)==i])}
    
    def.snow<-merge(WFDP_yearly_deficit,WFDP_yearly_snowppack,by='year')
    
    save(def.snow,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr",format(Sys.time(),'%Y%m%d'),sep=''))
  }  
} else 
  if (RUN.PRISM.SUMMARY==T) {
    
    PRISM<-read.csv("./DATA/Climate/NEX PRISM 800-m/PRISM_800m_2010-2019_monthly.csv",na.strings='NULL')
    
    WFDP_yearly_deficit<-data.frame("year"=c(2010:2019),"deficit"=NA)
    for(i in 2010:2019){WFDP_yearly_deficit[WFDP_yearly_deficit$year==i,2]<-sum(PRISM[PRISM$year==i,'deficit'])}
    
    WFDP_yearly_snowppack<-data.frame("year"=c(2010:2019),"snowppack"=NA)
    for(i in 2010:2019){WFDP_yearly_snowppack[WFDP_yearly_snowppack$year==i,2]<-max(PRISM[(PRISM$year==i&PRISM$month<=7)|(PRISM$year==(i-1)&PRISM$month>7),'snow'])}
    
    def.snow<-merge(WFDP_yearly_deficit,WFDP_yearly_snowppack,by='year')
    
    save(def.snow,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
  } else load("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_20200310")


colnames(def.snow)[1]<-'CENSUS'
def.snow$deflag1<-def.snow[c(nrow(def.snow),1:(nrow(def.snow)-1)),'deficit']
def.snow<-def.snow[def.snow$CENSUS>2011,]

def.snow[2:4]<-apply(def.snow[2:4],2,FUN= function(x){x-mean(x)}) #center variables


##############################################################################################################################################

##############################################################################################################################################-
#########################################               RUN COX MODELS PER SENSITIVITY             ###########################################-
#---------------------------------------------------------------------------------------------------------------------------------------------


##################################################             MAKE DATAFRAMES              #############################################-
{#create data
  
  timeframe<-2020-2012
  tree.cox<-live.tree[,c('STEM_TAG','SPECIES','CENSUS','MORT_DATE','IN_YR','BIOMASS_DBH','DBH_BIN','DA','conifer',neighbor.predictors)]
  tree.cox<-do.call("rbind", replicate(timeframe, tree.cox, simplify = FALSE))
  tree.cox<-tree.cox[order(tree.cox$STEM_TAG),]
  nrows<-nrow(tree.cox)
  tree.cox$CENSUS<-rep(paste(2012:2019),(nrows/timeframe))
  tree.cox<-merge(tree.cox,def.snow,by='CENSUS')
  tree.cox<-tree.cox[order(tree.cox$STEM_TAG),]
  
  #remove trees from earlier censuses that were ingrowth later on
  tree.cox<-tree.cox[(is.na(tree.cox$IN_YR)==F&tree.cox$CENSUS>=tree.cox$IN_YR)|is.na(tree.cox$IN_YR)==T,]
  
  #set DA to change to dead in year that tree died, then remove subsequent years for dead trees
  tree.cox$DA<-0
  tree.cox[is.na(tree.cox$MORT_DATE)==F&tree.cox$CENSUS>=tree.cox$MORT_DATE,'DA']<-1
  tree.cox<-tree.cox[(is.na(tree.cox$MORT_DATE)==F&tree.cox$CENSUS<=tree.cox$MORT_DATE)|is.na(tree.cox$MORT_DATE)==T,]
  # test<-live.tree[live.tree$MORT_DATE==2015&is.na(live.tree$MORT_DATE)==F,'STEM_TAG'] #trees that died in 2015
  # tree.cox[tree.cox$STEM_TAG%in%test,] #make sure DA changes on appropriate date and subsequent entries are deleted (once it's dead, it's out of dataset)
  
  tree.cox[is.na(tree.cox$MORT_DATE)==T,'MORT_DATE']<-90
  tree.cox[tree.cox$MORT_DATE==2011&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-0
  tree.cox[tree.cox$MORT_DATE==2012&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-1
  tree.cox[tree.cox$MORT_DATE==2013&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-2
  tree.cox[tree.cox$MORT_DATE==2014&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-3
  tree.cox[tree.cox$MORT_DATE==2015&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-4
  tree.cox[tree.cox$MORT_DATE==2016&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-5
  tree.cox[tree.cox$MORT_DATE==2017&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-6
  tree.cox[tree.cox$MORT_DATE==2018&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-7
  tree.cox[tree.cox$MORT_DATE==2019&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-8
  
  tree.cox[tree.cox$CENSUS==2011&is.na(tree.cox$CENSUS)==F,'CENSUS']<-0
  tree.cox[tree.cox$CENSUS==2012&is.na(tree.cox$CENSUS)==F,'CENSUS']<-1
  tree.cox[tree.cox$CENSUS==2013&is.na(tree.cox$CENSUS)==F,'CENSUS']<-2
  tree.cox[tree.cox$CENSUS==2014&is.na(tree.cox$CENSUS)==F,'CENSUS']<-3
  tree.cox[tree.cox$CENSUS==2015&is.na(tree.cox$CENSUS)==F,'CENSUS']<-4
  tree.cox[tree.cox$CENSUS==2016&is.na(tree.cox$CENSUS)==F,'CENSUS']<-5
  tree.cox[tree.cox$CENSUS==2017&is.na(tree.cox$CENSUS)==F,'CENSUS']<-6
  tree.cox[tree.cox$CENSUS==2018&is.na(tree.cox$CENSUS)==F,'CENSUS']<-7
  tree.cox[tree.cox$CENSUS==2019&is.na(tree.cox$CENSUS)==F,'CENSUS']<-8
  
  tree.cox$CENSUS<-as.numeric(tree.cox$CENSUS)
  
  tree.cox[is.na(tree.cox)==T]<-0
  tree.cox[which(tree.cox==Inf)]<-0
  
  Angiosperm<-tree.cox[tree.cox$conifer!=1,]
  Gymnosperm<-tree.cox[tree.cox$conifer==1,]
  
  # tree.cox <- tree.cox[tree.cox$CENSUS<8,]
  #get data per spp
  for(i in spplist1){
    species<-tree.cox[tree.cox$SPECIES==i,]
    assign(paste(i,'gen',sep='.'),species)
  }
  rm(species)
  
  save(ABAM.gen,ACCI.gen,PSME.gen,TABR.gen,TSHE.gen,file='./OUTPUT/Cox/SENSITIVITY_4/Species_dataframes_agentGeneric_noMECH_20200710_heg50b.Rdata')
  
  
}

##################################################                RUN MODELS              #############################################-

for(i in spplist1){
  datt<-paste(i,'gen',sep='.')
  
  temp<-coxph(Surv(time=CENSUS,event=DA)~BIOMASS_DBH+cluster(STEM_TAG)+(deflag1+zscore.Hegyi.het+snowppack+elev.diff)^4+
                (deflag1+zscore.Hegyi.con+snowppack+elev.diff)^4, data=eval(parse(text=datt)))
  
  assign(paste(i,'hetcon',sep='.'),temp)
  
  rm(temp,datt)
}

save(ABAM.hetcon, PSME.hetcon, TABR.hetcon,TSHE.hetcon, ACCI.hetcon, 
     file='./OUTPUT/Cox/SENSITIVITY_4/all_models_hetcon_w2019_wo2011_scaledHegyis_noMECH_20200710_heg50b.Rdata')

########### make master table - HR ###########-
{
  table.6<-data.frame()
  for(i in spplist1){
    model<-eval(parse(text=paste(i,'hetcon',sep='.')))
    
    for(j in names(model$coefficients)){
      table.6[j,i]<-(exp(model$coefficients[j])-1)*100
    }
    t<-ifelse(summary(model)$coefficients[,6]<0.001,'***',
              ifelse(summary(model)$coefficients[,6]<0.01,'**',
                     ifelse(summary(model)$coefficients[,6]<0.05,'*','')))
    t2<-ifelse(table.6[is.na(table.6[,i])==F,i]<0,"'- ","'+ ")
    t3<-as.character(abs(round(table.6[is.na(table.6[,i])==F,i],2)))
    t3[t3==0]<-'< 0.01'
    table.6[is.na(table.6[,i])==F,i]<-as.character(paste(t2,t3,'% ',t,sep=''))
  }
  table.6$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',rownames(table.6))
  table.6$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',rownames(table.6))
  table.6$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',table.6$`Pretty Names`)
  table.6$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',table.6$`Pretty Names`)
  table.6$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',table.6$`Pretty Names`)
  table.6[order(table.6$`Pretty Names`),]
  
  save(table.6,file=paste('./OUTPUT/Cox/SENSITIVITY_4/HetCon.table.HR_w2019_w02011_scaledHegyis_noMECH_',format(Sys.time(),'%Y%m%d'),'_heg50b.Rdata',sep=''))
  # write.csv(x=table.6,file=paste('./OUTPUT/Cox/HetCon.table.HR_w2019_w02011_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),'.csv',sep='.'))
}

########### make master table - BETAS ###########-
{
  table.6b<-data.frame()
  for(i in spplist1){
    model<-eval(parse(text=paste(i,'hetcon',sep='.')))
    for(j in names(model$coefficients)){
      table.6b[j,i]<-as.numeric(model$coefficients[j])
    } # remove following section to make BETA table for climate_projections usage, keep for MS table
    t<-ifelse(summary(model)$coefficients[,6]<0.001,'***',
              ifelse(summary(model)$coefficients[,6]<0.01,'**',
                     ifelse(summary(model)$coefficients[,6]<0.05,'*','')))
    t2<-ifelse(table.6b[is.na(table.6b[,i])==F,i]<0,"'- ","'+ ")
    t3<-as.character(abs(round(table.6b[is.na(table.6b[,i])==F,i],3)))
    t3[t3==0]<-paste('t')
    table.6b[is.na(table.6b[,i])==F,i]<-as.character(paste(t2,t3,t,sep=''))
    
  }
  table.6b$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',rownames(table.6b))
  table.6b$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',table.6b$`Pretty Names`)
  table.6b$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',table.6b$`Pretty Names`)
  table.6b$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',table.6b$`Pretty Names`)
  table.6b$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',table.6b$`Pretty Names`)
  table.6b[order(table.6b$`Pretty Names`),]
  
  # save(table.6b,file=paste('./OUTPUT/Cox/SENSITIVITY_4/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH_',format(Sys.time(),'%Y%m%d'),'_heg50b.Rdata',sep=''))
  # write.csv(x=table.6b,file=paste('./OUTPUT/Cox/SENSITIVITY_4/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH_',format(Sys.time(),'%Y%m%d'),'_heg50b.csv',sep=''))
}

########### get event and non-event N  ###########-
{
  nrow(live.tree[live.tree$SPECIES=='ABAM'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
  nrow(live.tree[live.tree$SPECIES=='ABAM'&is.na(live.tree$MORT_DATE)==T,])
  
  nrow(live.tree[live.tree$SPECIES=='PSME'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
  nrow(live.tree[live.tree$SPECIES=='PSME'&is.na(live.tree$MORT_DATE)==T,])
  
  nrow(live.tree[live.tree$SPECIES=='TABR'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
  nrow(live.tree[live.tree$SPECIES=='TABR'&is.na(live.tree$MORT_DATE)==T,])
  
  nrow(live.tree[live.tree$SPECIES=='TSHE'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
  nrow(live.tree[live.tree$SPECIES=='TSHE'&is.na(live.tree$MORT_DATE)==T,])
  
  nrow(live.tree[live.tree$SPECIES=='ACCI'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
  nrow(live.tree[live.tree$SPECIES=='ACCI'&is.na(live.tree$MORT_DATE)==T,])
  
  nrow(live.tree[live.tree$SPECIES=='COCOC'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
  nrow(live.tree[live.tree$SPECIES=='COCOC'&is.na(live.tree$MORT_DATE)==T,])
  
  nrow(live.tree[live.tree$SPECIES=='VAPA'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
  nrow(live.tree[live.tree$SPECIES=='VAPA'&is.na(live.tree$MORT_DATE)==T,])
  
  #concordances
  species=c('ABAM','PSME','TABR','TSHE','ACCI')
  concordances<-data.frame('C'=NA)
  for(k in species){
    mod<-eval(parse(text=paste(k,'hetcon',sep='.')))
    concordances[k,'C'] <- mod$concordance['concordant'] / (mod$concordance['concordant'] + mod$concordance['discordant'])
  }
  
  concordances$spp<-rownames(concordances);concordances<-concordances[-1,]
  
  save(concordances,file='./OUTPUT/Cox/SENSITIVITY_4/Cox.Models.Concordances.noMECH.20200710_heg50b.Rdata')
  
}

##############################################################################################################################################

##############################################################################################################################################-
##############################################                COMPARISON PLOT S11                #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------


{
  
  ###############################################################################################################################################################-
  ########################################################################### CLIMATE PROJECTIONS ###############################################################'
  #--------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  if(LOAD.CLIMATE==T){
    if (RUN.PRISM.SUMMARY==T){
      
      ## DATA ## 
      {
        historical<-datt<-read.csv("./DATA/Climate/NEX PRISM 800-m/prism_historical_195001-201912.csv",na.strings='NULL')
        datt<-read.csv("./DATA/Climate/NEX PRISM 800-m/HadGEM2-ES_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
        datt1<-read.csv("./DATA/Climate/NEX PRISM 800-m/HadGEM2-CC_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
        datt2<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-CM3_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
        datt3<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-ESM2G_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
        datt4<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-ESM2M_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
        datt5<-read.csv("./DATA/Climate/NEX PRISM 800-m/CCSM4_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
        
        historical$year<-as.character(historical$year)
        datt$year<-as.character(datt$year)
        datt1$year<-as.character(datt1$year)
        datt2$year<-as.character(datt2$year)
        datt3$year<-as.character(datt3$year)
        datt4$year<-as.character(datt4$year)
        datt5$year<-as.character(datt5$year)
        
        historical$year<-as.numeric(right(historical$year,4))
        datt$year<-as.numeric(right(datt$year,4))
        datt1$year<-as.numeric(right(datt1$year,4))
        datt2$year<-as.numeric(right(datt2$year,4))
        datt3$year<-as.numeric(right(datt3$year,4))
        datt4$year<-as.numeric(right(datt4$year,4))
        datt5$year<-as.numeric(right(datt5$year,4))
        
        mean.time<-seq(1950,2099,1)
        mean.model.all<- datt1
        mean.model.all[1:nrow(mean.model.all),3:ncol(mean.model.all)]<-NA
        for(i in mean.time){
          for(k in 1:12){
            for(j in colnames(mean.model.all)[3:ncol(mean.model.all)]){
              mean.model.all[mean.model.all$year==i&mean.model.all$month==k,j] <- mean(c(datt[datt$year==i&datt$month==k,colnames(datt)==j],
                                                                                         datt1[datt1$year==i&datt1$month==k,colnames(datt1)==j],
                                                                                         datt2[datt2$year==i&datt2$month==k,colnames(datt2)==j],
                                                                                         datt3[datt3$year==i&datt3$month==k,colnames(datt3)==j],
                                                                                         datt4[datt4$year==i&datt4$month==k,colnames(datt4)==j],
                                                                                         datt5[datt5$year==i&datt5$month==k,colnames(datt5)==j]))
            }
          }
        }
        
        # write.csv(datt[datt$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/hadgem2.es.alldata.csv')
        # write.csv(datt1[datt1$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/hadgem2.cc.alldata.csv')
        # write.csv(datt2[datt2$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/gfdl.cm3.alldata.csv')
        # write.csv(datt3[datt3$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/gfdl.esm2g.alldata.csv')
        # write.csv(datt4[datt4$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/gfdl.esm2m.cc.alldata.csv')
        # write.csv(datt5[datt5$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/ccsm4.alldata.csv')
        # write.csv(mean.model.all,file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/mean.model.alldata.csv')
        # write.csv(historical,file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/historical.alldata.csv')
        
      }
      
      ##########################################################################################################################################################################'
      ################################################################## GET DEFICIT and SNOWPACK PROJECTIONS ##################################################################'
      #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      
      WFDP_yearly_deficit0<-data.frame("year"=c(1950:2019),"deficit"=NA)
      for(i in 1950:2019){WFDP_yearly_deficit0[WFDP_yearly_deficit0$year==i,2]<-sum(historical[historical$year==i,'deficit'])}
      WFDP_yearly_snowppack0<-data.frame("year"=c(1950:2019),"snowppack"=NA)
      for(i in 1950:2019){WFDP_yearly_snowppack0[WFDP_yearly_snowppack0$year==i,2]<-max(historical[(historical$year==i&historical$month<=7)|(historical$year==(i-1)&historical$month>7),'snow'])}
      hist.defsnow<-merge(WFDP_yearly_deficit0,WFDP_yearly_snowppack0,by='year')
      save(hist.defsnow,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_HISTORICAL_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      WFDP_yearly_deficit<-data.frame("year"=c(2019:2099),"deficit"=NA)
      for(i in 2019:2099){WFDP_yearly_deficit[WFDP_yearly_deficit$year==i,2]<-sum(datt[datt$year==i,'deficit'])}
      WFDP_yearly_snowppack<-data.frame("year"=c(2019:2099),"snowppack"=NA)
      for(i in 2019:2099){WFDP_yearly_snowppack[WFDP_yearly_snowppack$year==i,2]<-max(datt[(datt$year==i&datt$month<=7)|(datt$year==(i-1)&datt$month>7),'snow'])}
      hadgem2.es<-merge(WFDP_yearly_deficit,WFDP_yearly_snowppack,by='year')
      hadgem2.es<-hadgem2.es[hadgem2.es$year>2019,]
      save(hadgem2.es,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-ES_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      WFDP_yearly_deficit1<-data.frame("year"=c(2019:2099),"deficit"=NA)
      for(i in 2019:2099){WFDP_yearly_deficit1[WFDP_yearly_deficit1$year==i,2]<-sum(datt1[datt1$year==i,'deficit'])}
      WFDP_yearly_snowppack1<-data.frame("year"=c(2019:2099),"snowppack"=NA)
      for(i in 2019:2099){WFDP_yearly_snowppack1[WFDP_yearly_snowppack1$year==i,2]<-max(datt1[(datt1$year==i&datt1$month<=7)|(datt1$year==(i-1)&datt1$month>7),'snow'])}
      hadgem2.cc<-merge(WFDP_yearly_deficit1,WFDP_yearly_snowppack1,by='year')
      hadgem2.cc<-hadgem2.cc[hadgem2.cc$year>2019,]
      save(hadgem2.cc,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-CC_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      WFDP_yearly_deficit2<-data.frame("year"=c(2019:2099),"deficit"=NA)
      for(i in 2019:2099){WFDP_yearly_deficit2[WFDP_yearly_deficit2$year==i,2]<-sum(datt2[datt2$year==i,'deficit'])}
      WFDP_yearly_snowppack2<-data.frame("year"=c(2019:2099),"snowppack"=NA)
      for(i in 2019:2099){WFDP_yearly_snowppack2[WFDP_yearly_snowppack2$year==i,2]<-max(datt2[(datt2$year==i&datt2$month<=7)|(datt2$year==(i-1)&datt2$month>7),'snow'])}
      gfdl.cm3<-merge(WFDP_yearly_deficit2,WFDP_yearly_snowppack2,by='year')
      gfdl.cm3<-gfdl.cm3[gfdl.cm3$year>2019,]
      save(gfdl.cm3,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-CM3_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      WFDP_yearly_deficit3<-data.frame("year"=c(2019:2099),"deficit"=NA)
      for(i in 2019:2099){WFDP_yearly_deficit3[WFDP_yearly_deficit3$year==i,2]<-sum(datt3[datt3$year==i,'deficit'])}
      WFDP_yearly_snowppack3<-data.frame("year"=c(2019:2099),"snowppack"=NA)
      for(i in 2019:2099){WFDP_yearly_snowppack3[WFDP_yearly_snowppack3$year==i,2]<-max(datt3[(datt3$year==i&datt3$month<=7)|(datt3$year==(i-1)&datt3$month>7),'snow'])}
      gfdl.esm2g<-merge(WFDP_yearly_deficit3,WFDP_yearly_snowppack3,by='year')
      gfdl.esm2g<-gfdl.esm2g[gfdl.esm2g$year>2019,]
      save(gfdl.esm2g,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2G_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      WFDP_yearly_deficit4<-data.frame("year"=c(2019:2099),"deficit"=NA)
      for(i in 2019:2099){WFDP_yearly_deficit4[WFDP_yearly_deficit4$year==i,2]<-sum(datt4[datt4$year==i,'deficit'])}
      WFDP_yearly_snowppack4<-data.frame("year"=c(2019:2099),"snowppack"=NA)
      for(i in 2019:2099){WFDP_yearly_snowppack4[WFDP_yearly_snowppack4$year==i,2]<-max(datt4[(datt4$year==i&datt4$month<=7)|(datt4$year==(i-1)&datt4$month>7),'snow'])}
      gfdl.esm2m<-merge(WFDP_yearly_deficit4,WFDP_yearly_snowppack4,by='year')
      gfdl.esm2m<-gfdl.esm2m[gfdl.esm2m$year>2019,]
      save(gfdl.esm2m,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2M_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      WFDP_yearly_deficit5<-data.frame("year"=c(2019:2099),"deficit"=NA)
      for(i in 2019:2099){WFDP_yearly_deficit5[WFDP_yearly_deficit5$year==i,2]<-sum(datt5[datt5$year==i,'deficit'])}
      WFDP_yearly_snowppack5<-data.frame("year"=c(2019:2099),"snowppack"=NA)
      for(i in 2019:2099){WFDP_yearly_snowppack5[WFDP_yearly_snowppack5$year==i,2]<-max(datt5[(datt5$year==i&datt5$month<=7)|(datt5$year==(i-1)&datt5$month>7),'snow'])}
      ccsm4<-merge(WFDP_yearly_deficit5,WFDP_yearly_snowppack5,by='year')
      ccsm4<-ccsm4[ccsm4$year>2019,]
      save(ccsm4,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_CCSM4_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      mean.time<-seq(2020,2099,1)
      mean.model<- data.frame('year'=seq(2020,2099,1),'deficit'=NA,'snowppack'=NA)
      for(i in mean.time){
        mean.model[mean.model$year==i,'deficit'] <- mean(c(hadgem2.cc[hadgem2.cc$year==i,'deficit'],
                                                           hadgem2.es[hadgem2.es$year==i,'deficit'],
                                                           gfdl.cm3[gfdl.cm3$year==i,'deficit'],
                                                           gfdl.esm2g[gfdl.esm2g$year==i,'deficit'],
                                                           gfdl.esm2m[gfdl.esm2m$year==i,'deficit'],
                                                           ccsm4[ccsm4$year==i,'deficit']))
        mean.model[mean.model$year==i,'snowppack'] <- mean(c(hadgem2.cc[hadgem2.cc$year==i,'snowppack'],
                                                             hadgem2.es[hadgem2.es$year==i,'snowppack'],
                                                             gfdl.cm3[gfdl.cm3$year==i,'snowppack'],
                                                             gfdl.esm2g[gfdl.esm2g$year==i,'snowppack'],
                                                             gfdl.esm2m[gfdl.esm2m$year==i,'snowppack'],
                                                             ccsm4[ccsm4$year==i,'snowppack']))
      }
      
      save(mean.model,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_MEANMODEL_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      
      mean.full.model <- rbind(hist.defsnow,mean.model)
      save(mean.full.model,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      #create lagged deficit -------------------------------------------------------------
      models<-c('ccsm4','gfdl.cm3','gfdl.esm2g','gfdl.esm2m','hadgem2.cc','hadgem2.es','mean.model')
      
      for (i in models){
        model<-eval(parse(text=i))
        combined<-rbind(hist.defsnow,model)
        for (j in 2:nrow(combined)){
          combined[j,'deflag1'] <- combined[j-1,'deficit']
          assign(paste(i,'lag',sep='.'),combined)
        }
      }
      
      colnames(mean.model.lag)[3]<-'snow'
      colnames(mean.model.lag)[4]<-'Deficit'
      colnames(ccsm4.lag)[3]<-'snow'
      colnames(ccsm4.lag)[4]<-'Deficit'
      colnames(gfdl.cm3.lag)[3]<-'snow'
      colnames(gfdl.cm3.lag)[4]<-'Deficit'
      colnames(gfdl.esm2g.lag)[3]<-'snow'
      colnames(gfdl.esm2g.lag)[4]<-'Deficit'
      colnames(gfdl.esm2m.lag)[3]<-'snow'
      colnames(gfdl.esm2m.lag)[4]<-'Deficit'
      colnames(hadgem2.cc.lag)[3]<-'snow'
      colnames(hadgem2.cc.lag)[4]<-'Deficit'
      colnames(hadgem2.es.lag)[3]<-'snow'
      colnames(hadgem2.es.lag)[4]<-'Deficit'
      
      save(mean.model.lag,ccsm4.lag,gfdl.cm3.lag,gfdl.esm2g.lag,gfdl.esm2m.lag,hadgem2.cc.lag,hadgem2.es.lag,
           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_lagged.def_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
      
      #########################################################################################################################################################################
      #################################################################### SUMMARIZE DEFICIT AND SNOWPACK #####################################################################'
      #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      
      future.def<-summary(mean.model[mean.model$year>2060&mean.model$year<2070,'deficit'])
      
      future.snow<-summary(mean.model[mean.model$year>2060&mean.model$year<2070,'snowppack'])
      
      past.def<-summary(hist.defsnow[hist.defsnow$year>2010&hist.defsnow$year<2020,'deficit'])
      
      past.snow<-summary(hist.defsnow[hist.defsnow$year>2010&hist.defsnow$year<2020,'snowppack'])
      
      #####################################################################################################################################################################
      
      
    } else c(load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_CCSM4_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-CM3_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2G_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2M_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-CC_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-ES_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_HISTORICAL_PRISM_method_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_MEANMODEL_PRISM_method_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_PRISM_method_20200310'),
             load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_lagged.def_PRISM_method_20200310'))
  }
  
  ##############################################################################################################################################################
  
  ###############################################################################################################################################################-
  #################################################################### 6 STEPS - PROJECT HAZARD FORWARD ########################################################'
  #--------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  #STEP 1 - GET ALL SIGNIFICANT BETAS
  if (RUN.BETAS==T){
    
    load('./OUTPUT/Cox/SENSITIVITY_4/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH_20200711_heg50b.Rdata')
    load('./OUTPUT/Cox/SENSITIVITY_4/HetCon.table.HR_w2019_w02011_scaledHegyis_noMECH_20200711_heg50b.Rdata')
    
    
    tables = c('table.6')
    species=c('ABAM','PSME','TABR','TSHE','ACCI')
    speciesb=c('ABAMb','PSMEb','TABRb','TSHEb','ACCIb')
    predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con')
    
    for(i in tables){
      #make data
      hr<-eval(parse(text=i))
      beta<-eval(parse(text=paste(i,'b',sep='')))
      colnames(beta)[1:length(beta)]<-paste(colnames(beta),'b',sep='')
      merged<-cbind(hr,beta)
      
      for(j in 1:nrow(merged)){
        for (k in colnames(hr)){  
          #get all significant betas
          sig.hr<-grep(pattern="*", merged[,k], value=TRUE, fixed=TRUE) 
          sig.betas<-as.numeric(merged[merged[,k]%in%sig.hr,paste(k,'b',sep='')]) 
          name<-merged[merged[,k]%in%sig.hr,ncol(merged)]
          fin<-data.frame('predictor' = name, 'beta' = sig.betas, 'hr' = sig.hr)
          
          for(m in predictors){
            #get significant betas per predictor of interest
            pred<-grep(pattern=parse(text=m), fin$predictor, value=TRUE) 
            pred.beta<-as.numeric(fin[fin$predictor%in%pred,'beta']) 
            finale<-data.frame('predictor' = pred, 'beta' = pred.beta)
            finale$predictor<-as.character(finale$predictor)
            
            #get non-significant betas for lower-order interaction terms of significant higher-order interactions
            add.cum<-c()
            for(p in finale$predictor){
              pieces <- unlist(strsplit(p,':',fixed=TRUE)) #all components of interaction
              
              if (length(pieces) >= 3) {
                bivar<-as.vector(outer(pieces, pieces, paste, sep=":")) #all possible combos of components
                trivar<-as.vector(outer(bivar, pieces, paste, sep=":"))
                add<-c(bivar, trivar) 
                add.cum<-c(add.cum,add)
              }
              
              addition<-grep(pattern=parse(text=m), add.cum, value=TRUE)
              addition<-c(addition,m)
              newname<-beta[(!beta$`Pretty Names`%in%finale$predictor)&beta$`Pretty Names`%in%addition,ncol(beta)]
              newbeta<-beta[(!beta$`Pretty Names`%in%finale$predictor)&beta$`Pretty Names`%in%addition,paste(k,'b',sep='')]
              newfin<-data.frame('predictor' = newname, 'beta' = newbeta)
              
              total.finale<-rbind(finale,newfin)
              assign(paste(i,k,m,sep='.'),total.finale)
              print(paste(i,k,m))
              
            }
          }
        }
      }
    }
    
    rm(beta)
    rm(fin)
    rm(finale)
    rm(hr)
    rm(merged)
    rm(newfin)
    rm(total.finale)
    
    save.image(file=paste('./OUTPUT/Cox/SENSITIVITY_4/Project.HR.model.BetaTables_w2019_wo2011_scaledHegyis_noMECH_',format(Sys.time(),'%Y%m%d'),"_heg50b.Rdata",sep=''))
    
    
    
  } else {load('./OUTPUT/Cox/SENSITIVITY_4/Project.HR.model.BetaTables_w2019_wo2011_scaledHegyis_noMECH_20200711_heg50b.Rdata')}
  
  #STEP 2 - DEFINE MIN and MAX for PREDICTORS
  if (RUN.VAR.SUMMARY==T){
    
    
    load('./OUTPUT/Cox/SENSITIVITY_4/Species_dataframes_agentGeneric_noMECH_20200710_heg50b.Rdata')
    load("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_20200310")
    colnames(def.snow)[1]<-'CENSUS'
    def.snow$deflag1<-def.snow[c(nrow(def.snow),1:(nrow(def.snow)-1)),'deficit']
    def.snow<-def.snow[def.snow$CENSUS>2011,]
    def.snow[2:4]<-apply(def.snow[2:4],2,FUN= function(x){x-mean(x)}) #center variables
    
    variables<-c('elev.diff','zscore.Hegyi.con','zscore.Hegyi.het')
    Variable.Summaries<-c()
    species=c('ABAM','PSME','TABR','TSHE','ACCI')
    
    for (i in paste(species,'gen',sep='.')){
      for (j in variables){
        model<-eval(parse(text=i))
        datt<-data.frame('Species'=paste(i),'Variable'=paste(j),'min'= ifelse(min(model[,j])<=(mean(model[,j])-(2*sd(model[,j]))),(mean(model[,j])-(2*sd(model[,j]))),min(model[,j])),
                         'mean'=mean(model[,j]),'max'=ifelse(max(model[,j])>=(mean(model[,j])+(2*sd(model[,j]))),(mean(model[,j])+(2*sd(model[,j]))),min(model[,j])))
        Variable.Summaries<-rbind(Variable.Summaries,datt)
      }
    }
    for (i in paste(species,'gen',sep='.')){
      blat<-data.frame('Species'=paste(i),'Variable'=c('snowppack','deflag1'),'min'=c(min(def.snow$snowppack),min(def.snow$deflag1)),
                       'mean'=c(0,0),'max'=c(max(def.snow$snowppack),max(def.snow$deflag1)))
      Variable.Summaries<-rbind(Variable.Summaries,blat)
    }
    Variable.Summaries<-Variable.Summaries[order(Variable.Summaries$Species,Variable.Summaries$Variable),]
    
    Variable.Summaries$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',Variable.Summaries$Variable)
    Variable.Summaries$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',Variable.Summaries$`Pretty Names`)
    Variable.Summaries$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',Variable.Summaries$`Pretty Names`)
    Variable.Summaries$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',Variable.Summaries$`Pretty Names`)
    Variable.Summaries$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',Variable.Summaries$`Pretty Names`)
    
    save(Variable.Summaries,file=paste('./OUTPUT/Cox/SENSITIVITY_4/Project.HR.model.VariableSummaries_scaledHegyis_noMECH_',format(Sys.time(),'%Y%m%d'),"_heg50b.Rdata",sep=''))
    
  } else {load('./OUTPUT/Cox/SENSITIVITY_4/Project.HR.model.VariableSummaries_scaledHegyis_noMECH_20200711_heg50b.Rdata')}
  
  #STEP 3 - CREATE HAZARD RATIO FUNCTIONS
  if (RUN.FUNC.CALC==T){
    
    hazard.calc<-function(units=1,snow.value='mean',watertable.value='mean',richness.value='mean',Deficit.value='mean',Hegyi.het.value='mean',
                          Hegyi.con.value='mean',N.value='mean',P.value='mean',TEB.value='mean',
                          species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                          predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                          tables=c('table.6')){
      HR<-data.frame()
      
      for(k in species){
        for(j in predictors){ 
          if (exists(paste(tables,k,j,sep='.'))){
            mod<-eval(parse(text=paste(tables,k,j,sep='.')))
            rownames(mod)<-mod$predictor
            
            all.pred<-unlist(strsplit(mod$predictor,':',fixed=TRUE))
            all.pred<-unique(all.pred[all.pred!=j])
            
            beta.i<-mod[mod$predictor==j,'beta']
            
            #separate all interactions into component pieces
            if (nrow(mod)>1){
              for(m in mod$predictor){
                bn<-unlist(strsplit(m,':',fixed=TRUE))
                bn<-bn[bn!=j]
                for(o in bn){
                  vn<-Variable.Summaries[Variable.Summaries$Species==paste(k,'gen',sep='.')&
                                           Variable.Summaries$`Pretty Names`==o,eval(parse(text=paste(o,'value',sep='.')))] #get min, mean, or max value
                  mod[m,paste(o,eval(parse(text=paste(o,'value',sep='.'))),'vn',sep='.')]<-vn
                }
              }
              #multiply interaction beta by value of components
              for(m in mod$predictor){
                mod[m,'multiplier']<-apply(mod[m,!colnames(mod)%in%c('multiplier','predictor')],1,prod,na.rm=T) 
                mod[mod$predictor==j,'multiplier']<-0
              }
              sum.multiplier<-sum(mod$multiplier,na.rm=T)
            } else sum.multiplier=0
            
            HR[paste(k,j,sep='.'),'HR']<-exp(units*(beta.i+sum.multiplier))
          }
        }
      }
      return(HR)
    }
    
    hazard.calc.continuous<-function(units=1,watertable.value='mean',richness.value='mean',Hegyi.het.value='mean',
                                     Hegyi.con.value='mean',N.value='mean',P.value='mean',TEB.value='mean',
                                     species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                                     predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                                     tables=c('table.6'),climate.model=mean.model.lag){
      
      #center in same way as parameterized variables
      centered<-climate.model[-1,]
      defx <- mean(centered[centered$year<2020&centered$year>2011,'Deficit'])
      snowx <- mean(centered[centered$year<2020&centered$year>2011,'snow'])
      centered[4]<-apply(centered[4],2,function(x) x-defx)
      centered[3]<-apply(centered[3],2,function(x) x-snowx)
      
      HR.continuous<-data.frame()
      sum.multiplier.continuous<-data.frame('year'=1951:2099,'sum'=NA)
      years<-c(1951:2099)
      
      for(k in species){
        for(j in predictors){ 
          if (exists(paste(tables,k,j,sep='.'))){
            for (a in years){
              mod.continuous<-eval(parse(text=paste(tables,k,j,sep='.')))
              rownames(mod.continuous)<-mod.continuous$predictor
              
              all.pred.continuous<-unlist(strsplit(mod.continuous$predictor,':',fixed=TRUE))
              all.pred.continuous<-unique(all.pred.continuous[all.pred.continuous!=j])
              
              beta.i.continuous<-mod.continuous[mod.continuous$predictor==j,'beta']
              
              #separate all interactions into component pieces
              if(length(grep('Deficit',all.pred.continuous,value=TRUE,fixed=TRUE)>0)|length(grep('snow',all.pred.continuous,value=TRUE,fixed=TRUE)>0)){
                if (nrow(mod.continuous)>1){
                  
                  for(m in mod.continuous$predictor){
                    if(m != j){
                      bn.continuous<-unlist(strsplit(m,':',fixed=TRUE))
                      bn.continuous<-bn.continuous[bn.continuous!=j]
                      
                      for(o in bn.continuous){
                        if(o %in% c('Deficit','snow')){
                          vn.continuous<-as.numeric(centered[centered$year==a,o])
                          mod.continuous[m,paste(o,a,'vn',sep='.')]<-vn.continuous
                        } else {
                          vn.continuous<-Variable.Summaries[Variable.Summaries$Species==paste(k,'gen',sep='.')&Variable.Summaries$`Pretty Names`==o,eval(parse(text=paste(o,'value',sep='.')))]
                          mod.continuous[m,paste(o,eval(parse(text=paste(o,'value',sep='.'))),'vn',sep='.')]<-vn.continuous
                          print(paste(a," - ",k,".",o,sep = ''))
                        }
                      }
                      
                      #multiply interaction beta by value of components
                      mod.continuous[m,'multiplier']<-apply(mod.continuous[m,!colnames(mod.continuous)%in%c('multiplier','predictor')],1,prod,na.rm=T) 
                    }
                    
                    mod.continuous[mod.continuous$predictor==j,'multiplier']<-0
                  }
                  
                  sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-sum(mod.continuous$multiplier,na.rm=T)
                } else sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0
                
                if(j == 'Deficit'){
                  units = as.numeric(centered[centered$year==a,'Deficit'])
                } else if (j == 'snow'){
                  units = as.numeric(centered[centered$year==a,'snow'])
                } else '' 
                
                HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']))
                HR.continuous[paste(k,j,a,sep='.'),'year']<-a
                
              } else {sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0; # 3 new lines here deal with non-climate-interacting predictors
              HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']));
              HR.continuous[paste(k,j,a,sep='.'),'year']<-a}
            }
          }
        }
      }
      return(HR.continuous)
    }
    
    hazard.combos<-function(units=1,possibilities=c('min','mean','max'),
                            species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                            predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                            tables=c('table.6')){
      
      HR<-data.frame('mean.values'=hazard.calc())
      
      for(k in species){
        for(j in predictors){
          args<-list()
          
          if (exists(paste(tables,k,j,sep='.'))){
            mod.combo<-eval(parse(text=paste(tables,k,j,sep='.')))
            rownames(mod.combo)<-mod.combo$predictor
            
            if(nrow(mod.combo)>1){
              pred<-unlist(strsplit(mod.combo$predictor,':',fixed=TRUE))
              pred<-unique(pred[pred!=j])
              names(pred)<-rep(paste(k,j,sep='.'),length(pred))
              
              #run function through all possible combinations of predictors
              if(length(pred)==1){
                for(b in pred[1]){
                  for(c in possibilities){
                    args[[paste(b,'.value',sep='')]]<-c
                    args[[paste('species')]]<-k
                    args[[paste('predictors')]]<-j
                    args[[paste('units')]]<-units
                    
                    HR[rownames(HR)==paste(k,j,sep='.'),paste(b,c,sep='.')]<-do.call(hazard.calc,args)$HR
                  }
                }
                
              } else if(length(pred)==2){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        if(b != d){
                          print(paste(d,e,sep = '.'))
                          args[[paste(b,'.value',sep='')]]<-c
                          args[[paste(d,'.value',sep='')]]<-e
                          args[[paste('species')]]<-k
                          args[[paste('predictors')]]<-j
                          args[[paste('units')]]<-units
                          
                          HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==3){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            if(b != d & d != f){
                              print(paste(f,g,sep = '.'))
                              args[[paste(b,'.value',sep='')]]<-c
                              args[[paste(d,'.value',sep='')]]<-e
                              args[[paste(f,'.value',sep='')]]<-g
                              args[[paste('species')]]<-k
                              args[[paste('predictors')]]<-j
                              args[[paste('units')]]<-units
                              
                              HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                            }
                          }
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==4){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            for(h in pred[4]){
                              for(i in possibilities){
                                if(b != d & d != f & f != h){
                                  print(paste(h,i,sep = '.'))
                                  args[[paste(b,'.value',sep='')]]<-c
                                  args[[paste(d,'.value',sep='')]]<-e
                                  args[[paste(f,'.value',sep='')]]<-g
                                  args[[paste(h,'.value',sep='')]]<-i
                                  args[[paste('species')]]<-k
                                  args[[paste('predictors')]]<-j
                                  args[[paste('units')]]<-units
                                  
                                  HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==5){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            for(h in pred[4]){
                              for(i in possibilities){
                                for(l in pred[5]){
                                  for(m in possibilities){
                                    if(b != d & d != f & f != h & h != l){
                                      print(paste(l,m,sep = '.'))
                                      args[[paste(b,'.value',sep='')]]<-c
                                      args[[paste(d,'.value',sep='')]]<-e
                                      args[[paste(f,'.value',sep='')]]<-g
                                      args[[paste(h,'.value',sep='')]]<-i
                                      args[[paste(l,'.value',sep='')]]<-m
                                      args[[paste('species')]]<-k
                                      args[[paste('predictors')]]<-j
                                      args[[paste('units')]]<-units
                                      
                                      HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==6){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            for(h in pred[4]){
                              for(i in possibilities){
                                for(l in pred[5]){
                                  for(m in possibilities){
                                    for(n in pred[6]){
                                      for(o in possibilities){
                                        if(b != d & d != f & f != h & h != l & l != n){
                                          print(paste(n,o,sep = '.'))
                                          args[[paste(b,'.value',sep='')]]<-c
                                          args[[paste(d,'.value',sep='')]]<-e
                                          args[[paste(f,'.value',sep='')]]<-g
                                          args[[paste(h,'.value',sep='')]]<-i
                                          args[[paste(l,'.value',sep='')]]<-m
                                          args[[paste(n,'.value',sep='')]]<-o
                                          args[[paste('species')]]<-k
                                          args[[paste('predictors')]]<-j
                                          args[[paste('units')]]<-units
                                          
                                          HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),paste(n,o,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } 
              } else print(paste('ERROR - number interacting variables > 6'))
            }
          }
        }
      } 
      return(HR)
    }
    
    hazard.combos.timestable<-function(units=1,possibilities=c('min','mean','max'),
                                       species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                                       predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                                       tables=c('table.6')){
      
      HR<-data.frame('mean.values'=hazard.calc())
      
      for(k in species){
        for(j in predictors){
          args<-list()
          
          if (exists(paste(tables,k,j,sep='.'))){
            mod.combo<-eval(parse(text=paste(tables,k,j,sep='.')))
            rownames(mod.combo)<-mod.combo$predictor
            
            if(nrow(mod.combo)>1){
              pred<-unlist(strsplit(mod.combo$predictor,':',fixed=TRUE))
              pred<-unique(pred[pred!=j])
              names(pred)<-rep(paste(k,j,sep='.'),length(pred))
              
              #run function through all possible combinations of predictors
              if(length(pred)==1){
                for(b in pred[1]){
                  for(c in possibilities){
                    args[[paste(b,'.value',sep='')]]<-c
                    args[[paste('species')]]<-k
                    args[[paste('predictors')]]<-j
                    args[[paste('units')]]<-units
                    
                    if(is.null(args$snow.value)==F){
                      args$snow.value<-'min'}
                    
                    if(is.null(args$Deficit.value)==F){
                      args$Deficit.value<-'max'}
                    
                    HR[rownames(HR)==paste(k,j,sep='.'),paste(b,c,sep='.')]<-do.call(hazard.calc,args)$HR
                  }
                }
                
              } else if(length(pred)==2){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        if(b != d){
                          print(paste(d,e,sep = '.'))
                          args[[paste(b,'.value',sep='')]]<-c
                          args[[paste(d,'.value',sep='')]]<-e
                          args[[paste('species')]]<-k
                          args[[paste('predictors')]]<-j
                          args[[paste('units')]]<-units
                          
                          if(is.null(args$snow.value)==F){
                            args$snow.value<-'min'}
                          
                          if(is.null(args$Deficit.value)==F){
                            args$Deficit.value<-'max'}
                          
                          HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==3){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            if(b != d & d != f){
                              print(paste(f,g,sep = '.'))
                              args[[paste(b,'.value',sep='')]]<-c
                              args[[paste(d,'.value',sep='')]]<-e
                              args[[paste(f,'.value',sep='')]]<-g
                              args[[paste('species')]]<-k
                              args[[paste('predictors')]]<-j
                              args[[paste('units')]]<-units
                              
                              if(is.null(args$snow.value)==F){
                                args$snow.value<-'min'}
                              
                              if(is.null(args$Deficit.value)==F){
                                args$Deficit.value<-'max'}
                              
                              HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                            }
                          }
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==4){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            for(h in pred[4]){
                              for(i in possibilities){
                                if(b != d & d != f & f != h){
                                  print(paste(h,i,sep = '.'))
                                  args[[paste(b,'.value',sep='')]]<-c
                                  args[[paste(d,'.value',sep='')]]<-e
                                  args[[paste(f,'.value',sep='')]]<-g
                                  args[[paste(h,'.value',sep='')]]<-i
                                  args[[paste('species')]]<-k
                                  args[[paste('predictors')]]<-j
                                  args[[paste('units')]]<-units
                                  
                                  if(is.null(args$snow.value)==F){
                                    args$snow.value<-'min'}
                                  
                                  if(is.null(args$Deficit.value)==F){
                                    args$Deficit.value<-'max'}
                                  
                                  HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==5){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            for(h in pred[4]){
                              for(i in possibilities){
                                for(l in pred[5]){
                                  for(m in possibilities){
                                    if(b != d & d != f & f != h & h != l){
                                      print(paste(l,m,sep = '.'))
                                      args[[paste(b,'.value',sep='')]]<-c
                                      args[[paste(d,'.value',sep='')]]<-e
                                      args[[paste(f,'.value',sep='')]]<-g
                                      args[[paste(h,'.value',sep='')]]<-i
                                      args[[paste(l,'.value',sep='')]]<-m
                                      args[[paste('species')]]<-k
                                      args[[paste('predictors')]]<-j
                                      args[[paste('units')]]<-units
                                      
                                      if(is.null(args$snow.value)==F){
                                        args$snow.value<-'min'}
                                      
                                      if(is.null(args$Deficit.value)==F){
                                        args$Deficit.value<-'max'}
                                      
                                      HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                
              } else if(length(pred)==6){
                for(b in pred[1]){
                  for(c in possibilities){
                    for(d in pred[2]){
                      for(e in possibilities){
                        for(f in pred[3]){
                          for(g in possibilities){
                            for(h in pred[4]){
                              for(i in possibilities){
                                for(l in pred[5]){
                                  for(m in possibilities){
                                    for(n in pred[6]){
                                      for(o in possibilities){
                                        if(b != d & d != f & f != h & h != l & l != n){
                                          print(paste(n,o,sep = '.'))
                                          args[[paste(b,'.value',sep='')]]<-c
                                          args[[paste(d,'.value',sep='')]]<-e
                                          args[[paste(f,'.value',sep='')]]<-g
                                          args[[paste(h,'.value',sep='')]]<-i
                                          args[[paste(l,'.value',sep='')]]<-m
                                          args[[paste(n,'.value',sep='')]]<-o
                                          args[[paste('species')]]<-k
                                          args[[paste('predictors')]]<-j
                                          args[[paste('units')]]<-units
                                          
                                          if(is.null(args$snow.value)==F){
                                            args$snow.value<-'min'}
                                          
                                          if(is.null(args$Deficit.value)==F){
                                            args$Deficit.value<-'max'}
                                          
                                          HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),paste(n,o,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } 
              } else print(paste('ERROR - number interacting variables > 6'))
            }
          }
        }
      } 
      return(HR)
    }
    
    save.image(file=paste('./OUTPUT/Cox/Cox.model.HRfunctions',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
    
  } else load('./OUTPUT/Cox/Cox.model.HRfunctions.20200312.Rdata')
  
  #STEP 4 - RUN HAZARD RATIO FUNCTIONS
  if (RUN.HR.FUNCS==T){
    
    HR.means<-hazard.calc() 
    HR.means$interpedHR<-paste(round((HR.means$HR-1)*100,3),'%')
    
    save(HR.means,file='./OUTPUT/Cox/SENSITIVITY_4/HR.means.20200711_heg50.Rdata')
    write.csv(HR.means,file='./OUTPUT/Cox/SENSITIVITY_4/HR.means.20200711_heg50.csv')
    
    
    #over time
    HR.continuous<-hazard.calc.continuous()
    
    save(HR.continuous,file='./OUTPUT/Cox/SENSITIVITY_4/HR.continuous.20200711_heg50.Rdata')
    
    #summarize combos per species and determine range of HR values
    HR.combos<-hazard.combos()
    HR.combos.TS<-hazard.combos.timestable()
    
    save(HR.combos,HR.combos.TS,file='./OUTPUT/Cox//SENSITIVITY_4/HR.combos.20200711_heg50.Rdata')
    
  } else {load('./OUTPUT/Cox/SENSITIVITY_4/HR.means.20200711_heg50.Rdata');
    load('./OUTPUT/Cox/SENSITIVITY_4/HR.combos.20200711_heg50.Rdata');
    load('./OUTPUT/Cox/SENSITIVITY_4/HR.continuous.20200711_heg50.Rdata')}
  
  #STEP 5 - GET SUMMARIES OF BEST / WORST MICROSITES
  ###
  
  #STEP 6 - PLUG IN MIN/MEAN/MAX RATIOS TO CLIMATE PROJECTIONS
  if(RUN.PERMUTATIONS==T){
    
    # #USING MEANS
    {
      
      
      ## AGENT GENERIC
      {
        ABAM.Hegyi.con.means<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ABAM.Hegyi.het.means<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ABAM.Hegyi.con.means1<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ABAM.Hegyi.het.means1<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ABAM.Hegyi.con.means2<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.het.means2<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ABAM.Hegyi.con.means3<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.het.means3<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ABAM.Hegyi.con.means4<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.het.means4<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ABAM.Hegyi.con.means5<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.het.means5<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ABAM.Hegyi.con.means6<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.het.means6<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        TSHE.Hegyi.con.means<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TSHE.Hegyi.het.means<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TSHE.Hegyi.con.means1<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TSHE.Hegyi.het.means1<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TSHE.Hegyi.con.means2<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.het.means2<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TSHE.Hegyi.con.means3<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.het.means3<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TSHE.Hegyi.con.means4<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.het.means4<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TSHE.Hegyi.con.means5<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.het.means5<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TSHE.Hegyi.con.means6<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.het.means6<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        PSME.Hegyi.con.means<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        PSME.Hegyi.het.means<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        PSME.Hegyi.con.means1<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        PSME.Hegyi.het.means1<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        PSME.Hegyi.con.means2<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.het.means2<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        PSME.Hegyi.con.means3<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.het.means3<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        PSME.Hegyi.con.means4<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.het.means4<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        PSME.Hegyi.con.means5<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.het.means5<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        PSME.Hegyi.con.means6<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        PSME.Hegyi.het.means6<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        TABR.Hegyi.con.means<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TABR.Hegyi.het.means<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TABR.Hegyi.con.means1<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TABR.Hegyi.het.means1<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TABR.Hegyi.con.means2<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.het.means2<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TABR.Hegyi.con.means3<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.het.means3<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TABR.Hegyi.con.means4<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.het.means4<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TABR.Hegyi.con.means5<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.het.means5<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TABR.Hegyi.con.means6<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TABR.Hegyi.het.means6<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        ACCI.Hegyi.con.means<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ACCI.Hegyi.het.means<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ACCI.Hegyi.con.means1<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ACCI.Hegyi.het.means1<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ACCI.Hegyi.con.means2<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.het.means2<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ACCI.Hegyi.con.means3<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.het.means3<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ACCI.Hegyi.con.means4<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.het.means4<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ACCI.Hegyi.con.means5<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.het.means5<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ACCI.Hegyi.con.means6<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.het.means6<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        
        #######-
      }
      
    }
    
    #USING MIN AND MAX
    {
      ## DiRECT CLiMATE EFFECTS ##
      {   
        ABAM.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = mean.model.lag)
        ABAM.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = mean.model.lag)
        
        ABAM.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = ccsm4.lag)
        ABAM.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        ABAM.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        ABAM.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        ABAM.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        ABAM.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        ABAM.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        ABAM.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        ABAM.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        ABAM.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        ABAM.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        ABAM.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        ####
        
        TABR.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = mean.model.lag)
        TABR.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = mean.model.lag)
        
        TABR.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = ccsm4.lag)
        TABR.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        TABR.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        TABR.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        TABR.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        TABR.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        TABR.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        TABR.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        TABR.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        TABR.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        TABR.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        TABR.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        ########-
        TSHE.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = mean.model.lag)
        TSHE.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = mean.model.lag)
        
        TSHE.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = ccsm4.lag)
        TSHE.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        TSHE.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        TSHE.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        TSHE.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        TSHE.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        TSHE.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        TSHE.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        TSHE.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        TSHE.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        TSHE.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        TSHE.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        ########-
        
        PSME.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = mean.model.lag)
        PSME.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = mean.model.lag)
        
        PSME.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = ccsm4.lag)
        PSME.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        PSME.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        PSME.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        PSME.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        PSME.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        PSME.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        PSME.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        PSME.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        PSME.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        PSME.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        PSME.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        
        #######-
        
        ACCI.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = mean.model.lag)
        ACCI.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = mean.model.lag)
        
        ACCI.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = ccsm4.lag)
        ACCI.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        ACCI.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        ACCI.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        ACCI.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        ACCI.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        ACCI.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        ACCI.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        ACCI.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        ACCI.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        ACCI.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        ACCI.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
      }
      
      ## AGENT GENERIC ##
      {
        # possible<-c('mean.model.lag','ccsm4.lag','gfdl.cm3.lag','gfdl.esm2g.lag','gfdl.esm2m.lag','hadgem2.cc.lag','hadgem2.es.lag')
        ABAM.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ABAM.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ABAM.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        ABAM.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ABAM.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ABAM.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ABAM.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        ABAM.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ABAM.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ABAM.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ABAM.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ABAM.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ABAM.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        
        TABR.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TABR.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TABR.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        TABR.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TABR.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TABR.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TABR.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        TABR.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TABR.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TABR.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TABR.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TABR.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TABR.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TABR.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TABR.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        TABR.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ########-
        TSHE.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TSHE.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TSHE.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        TSHE.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TSHE.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TSHE.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TSHE.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        TSHE.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TSHE.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TSHE.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TSHE.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TSHE.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TSHE.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ########-
        
        PSME.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        PSME.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        PSME.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        PSME.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        PSME.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        PSME.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        PSME.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        PSME.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        PSME.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        PSME.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        PSME.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        PSME.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        PSME.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        PSME.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        PSME.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        PSME.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        
        #######-
        
        ACCI.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ACCI.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ACCI.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        ACCI.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ACCI.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ACCI.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ACCI.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        ACCI.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ACCI.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ACCI.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ACCI.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ACCI.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ACCI.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
      }
      
    }
    
    
    
    save.image(file='./OUTPUT/Cox/SENSITIVITY_4/Min.max.permutations.mort.20200710_heg50b.Rdata') #workspace image with climate and all 6 steps
    
  } else load('./OUTPUT/Cox/SENSITIVITY_4/Min.max.permutations.mort.20200710_heg50b.Rdata')
  
  
  ###############################################################################################################################################################
  
  ###############################################################################################################################################################-
  ######################################################################    HAZARD OVER TIME PLOTS    ###########################################################'
  #--------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  ### USING MEANS ###-
  {
    
    
    ### AGENT GENERIC
    {
      
      ### DIFFERENCE BETWEEN CON and HET - if no con, subtract 1 from all HR 
      ABAM.dat1x<-cbind(ABAM.Hegyi.het.means,ABAM.Hegyi.con.means); colnames(ABAM.dat1x) <- c('HRh','yearh','HRc','yearc')   # sensitivity control
      ABAM.dat2x<-cbind(ABAM.Hegyi.het.means1,ABAM.Hegyi.con.means1); colnames(ABAM.dat2x) <- c('HRh','yearh','HRc','yearc') # sensitivity very dry
      ABAM.dat3x<-cbind(ABAM.Hegyi.het.means2,ABAM.Hegyi.con.means2); colnames(ABAM.dat3x) <- c('HRh','yearh','HRc','yearc') # sensitivity mod dry
      ABAM.dat4x<-cbind(ABAM.Hegyi.het.means3,ABAM.Hegyi.con.means3); colnames(ABAM.dat4x) <- c('HRh','yearh','HRc','yearc') # sensitivity mod wet
      ABAM.dat5x<-cbind(ABAM.Hegyi.het.means4,ABAM.Hegyi.con.means4); colnames(ABAM.dat5x) <- c('HRh','yearh','HRc','yearc') # sensitivity very wet
      ABAM.dat6x<-cbind(ABAM.Hegyi.het.means5,ABAM.Hegyi.con.means5); colnames(ABAM.dat6x) <- c('HRh','yearh','HRc','yearc') # sensitivity ext wet
      ABAM.dat7x<-cbind(ABAM.Hegyi.het.means6,ABAM.Hegyi.con.means6); colnames(ABAM.dat7x) <- c('HRh','yearh','HRc','yearc') # sensitivity ext dry
      
      ABAM4<-ggplot(data=ABAM.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=ABAM.dat2x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=ABAM.dat3x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=ABAM.dat4x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=ABAM.dat5x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=ABAM.dat6x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=ABAM.dat7x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=ABAM.dat1x, color='red', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        theme(axis.title = element_blank()) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      
      ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      TSHE.dat1x<-cbind(TSHE.Hegyi.het.means,TSHE.Hegyi.con.means); colnames(TSHE.dat1x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat2x<-cbind(TSHE.Hegyi.het.means1,TSHE.Hegyi.con.means1); colnames(TSHE.dat2x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat3x<-cbind(TSHE.Hegyi.het.means2,TSHE.Hegyi.con.means2); colnames(TSHE.dat3x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat4x<-cbind(TSHE.Hegyi.het.means3,TSHE.Hegyi.con.means3); colnames(TSHE.dat4x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat5x<-cbind(TSHE.Hegyi.het.means4,TSHE.Hegyi.con.means4); colnames(TSHE.dat5x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat6x<-cbind(TSHE.Hegyi.het.means5,TSHE.Hegyi.con.means5); colnames(TSHE.dat6x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat7x<-cbind(TSHE.Hegyi.het.means6,TSHE.Hegyi.con.means6); colnames(TSHE.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      TSHE4<-ggplot(data=TSHE.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=TSHE.dat2x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=TSHE.dat3x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=TSHE.dat4x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=TSHE.dat5x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=TSHE.dat6x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=TSHE.dat7x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=TSHE.dat1x, color='red', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      
      ### DIFFERENCE BETWEEN CON and HET - if no con, subtract 1 from all HR
      PSME.dat1x<-cbind(PSME.Hegyi.het.means,PSME.Hegyi.con.means); colnames(PSME.dat1x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat2x<-cbind(PSME.Hegyi.het.means1,PSME.Hegyi.con.means1); colnames(PSME.dat2x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat3x<-cbind(PSME.Hegyi.het.means2,PSME.Hegyi.con.means2); colnames(PSME.dat3x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat4x<-cbind(PSME.Hegyi.het.means3,PSME.Hegyi.con.means3); colnames(PSME.dat4x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat5x<-cbind(PSME.Hegyi.het.means4,PSME.Hegyi.con.means4); colnames(PSME.dat5x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat6x<-cbind(PSME.Hegyi.het.means5,PSME.Hegyi.con.means5); colnames(PSME.dat6x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat7x<-cbind(PSME.Hegyi.het.means6,PSME.Hegyi.con.means6); colnames(PSME.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      PSME4<-ggplot(data=PSME.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=PSME.dat2x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=PSME.dat3x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=PSME.dat4x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=PSME.dat5x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=PSME.dat6x, color='red', alpha = 0.3, size=0.2)+ 
        geom_line(data=PSME.dat7x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=PSME.dat1x, color='red', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      
      ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      TABR.Hegyi.het.means <- TABR.Hegyi.con.means
      TABR.Hegyi.het.means[,'HR'] <- 1
      
      TABR.dat1x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means); colnames(TABR.dat1x) <- c('HRh','yearh','HRc','yearc')
      TABR.dat2x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means1); colnames(TABR.dat2x) <- c('HRh','yearh','HRc','yearc')
      TABR.dat3x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means2); colnames(TABR.dat3x) <- c('HRh','yearh','HRc','yearc')
      TABR.dat4x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means3); colnames(TABR.dat4x) <- c('HRh','yearh','HRc','yearc')
      TABR.dat5x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means4); colnames(TABR.dat5x) <- c('HRh','yearh','HRc','yearc')
      TABR.dat6x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means5); colnames(TABR.dat6x) <- c('HRh','yearh','HRc','yearc')
      TABR.dat7x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means6); colnames(TABR.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      TABR4<-ggplot(data=TABR.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=TABR.dat2x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=TABR.dat3x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=TABR.dat4x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=TABR.dat5x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=TABR.dat6x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=TABR.dat7x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=TABR.dat1x, color='red', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      
      ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      ACCI.dat1x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means); colnames(ACCI.dat1x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat2x<-cbind(ACCI.Hegyi.het.means1,ACCI.Hegyi.con.means1); colnames(ACCI.dat2x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat3x<-cbind(ACCI.Hegyi.het.means2,ACCI.Hegyi.con.means2); colnames(ACCI.dat3x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat4x<-cbind(ACCI.Hegyi.het.means3,ACCI.Hegyi.con.means3); colnames(ACCI.dat4x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat5x<-cbind(ACCI.Hegyi.het.means4,ACCI.Hegyi.con.means4); colnames(ACCI.dat5x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat6x<-cbind(ACCI.Hegyi.het.means5,ACCI.Hegyi.con.means5); colnames(ACCI.dat6x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat7x<-cbind(ACCI.Hegyi.het.means6,ACCI.Hegyi.con.means6); colnames(ACCI.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      
      ACCI4<-ggplot(data=ACCI.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=ACCI.dat2x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=ACCI.dat3x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=ACCI.dat4x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=ACCI.dat5x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=ACCI.dat6x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=ACCI.dat7x, color='red', alpha = 0.3, size=0.2)+
        geom_line(data=ACCI.dat1x, color='red', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      
      #########-
      
      plot<-plot_grid(ABAM4, PSME4, TABR4, TSHE4, ACCI4, nrow=2, ncol=3, align='v')
      
      y.grob<-textGrob("Stability Strength", gp=gpar(col="black", fontsize=10), rot=90)
      x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
      
      gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
      
      dev.print(file='./OUTPUT/Neighborhood/SENSITIVITY_4/FigS4_with2019_noMECH_heg50b.tif',tiff,width=7,height=6.5,res=600,units='in',compression='lzw')
      # dev.print(file=paste('./Papers/Fig2c_with2019_conifers','.tif',sep=''),tiff,width=6.75,height=6.5,res=600,units='in',compression='lzw')
      
      
      
    }
    
    
  }
  
  
  ####### USING MIN AND MAX ###########-
  {
    
    
    ### AGENT - GENERIC ###
    {
      
      # DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      ## to 2019
      # TABR.dat1x<-cbind(TABR.Hegyi.het.max,TABR.Hegyi.con.max); colnames(TABR.dat1x) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat2x<-cbind(TABR.Hegyi.het.max1,TABR.Hegyi.con.max1); colnames(TABR.dat2x) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat3x<-cbind(TABR.Hegyi.het.max2,TABR.Hegyi.con.max2); colnames(TABR.dat3x) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat4x<-cbind(TABR.Hegyi.het.max3,TABR.Hegyi.con.max3); colnames(TABR.dat4x) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat5x<-cbind(TABR.Hegyi.het.max4,TABR.Hegyi.con.max4); colnames(TABR.dat5x) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat6x<-cbind(TABR.Hegyi.het.max5,TABR.Hegyi.con.max5); colnames(TABR.dat6x) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat7x<-cbind(TABR.Hegyi.het.max6,TABR.Hegyi.con.max6); colnames(TABR.dat7x) <- c('HRh','yearh','HRc','yearc')
      # 
      # TABR.dat1n<-cbind(TABR.Hegyi.het.min,TABR.Hegyi.con.min); colnames(TABR.dat1n) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat2n<-cbind(TABR.Hegyi.het.min1,TABR.Hegyi.con.min1); colnames(TABR.dat2n) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat3n<-cbind(TABR.Hegyi.het.min2,TABR.Hegyi.con.min2); colnames(TABR.dat3n) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat4n<-cbind(TABR.Hegyi.het.min3,TABR.Hegyi.con.min3); colnames(TABR.dat4n) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat5n<-cbind(TABR.Hegyi.het.min4,TABR.Hegyi.con.min4); colnames(TABR.dat5n) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat6n<-cbind(TABR.Hegyi.het.min5,TABR.Hegyi.con.min5); colnames(TABR.dat6n) <- c('HRh','yearh','HRc','yearc')
      # TABR.dat7n<-cbind(TABR.Hegyi.het.min6,TABR.Hegyi.con.min6); colnames(TABR.dat7n) <- c('HRh','yearh','HRc','yearc')
      # 
      # TABR4a<-ggplot(data=TABR.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
      #   geom_line(data=TABR.dat2x, color='grey', size=0.2)+ 
      #   geom_line(data=TABR.dat3x, color='grey', size=0.2)+ 
      #   geom_line(data=TABR.dat4x, color='grey', size=0.2)+ 
      #   geom_line(data=TABR.dat5x, color='grey', size=0.2)+ 
      #   geom_line(data=TABR.dat6x, color='grey', size=0.2)+ 
      #   geom_line(data=TABR.dat7x, color='grey', size=0.2)+
      #   geom_line(data=TABR.dat2n, color='#FFB867', size=0.2)+ 
      #   geom_line(data=TABR.dat3n, color='#FFB867', size=0.2)+ 
      #   geom_line(data=TABR.dat4n, color='#FFB867', size=0.2)+ 
      #   geom_line(data=TABR.dat5n, color='#FFB867', size=0.2)+ 
      #   geom_line(data=TABR.dat6n, color='#FFB867', size=0.2)+ 
      #   geom_line(data=TABR.dat7n, color='#FFB867', size=0.2)+ 
      #   geom_line(data=TABR.dat1n, aes(y=(HRc-HRh)-0.01), color='#FE5900', size=0.4)+
      #   geom_line(data=TABR.dat1x, color='black', size=0.4)+
      #   geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
      #   # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
      #   theme(axis.title = element_blank()) +
      #   # ggtitle(expression(bolditalic("Abies amabilis"))) +
      #   scale_x_continuous(breaks=seq(2020,2100,20)) +
      #   scale_y_continuous(breaks=seq(-2,2,1))+
      #   coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
      #   geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
      #             linetype='dashed', color="black", alpha=0, size=0.2)
      
      TABR4a<-ggplot(data=TABR.Hegyi.con.max, aes(year,HR-1)) + theme_prefs +
        geom_line(data=TABR.Hegyi.con.max1, color='grey', size=0.2)+
        geom_line(data=TABR.Hegyi.con.max2, color='grey', size=0.2)+
        geom_line(data=TABR.Hegyi.con.max3, color='grey', size=0.2)+
        geom_line(data=TABR.Hegyi.con.max4, color='grey', size=0.2)+
        geom_line(data=TABR.Hegyi.con.max5, color='grey', size=0.2)+
        geom_line(data=TABR.Hegyi.con.max6, color='grey', size=0.2)+
        geom_line(data=TABR.Hegyi.con.min1, color='#FFB867', size=0.2)+
        geom_line(data=TABR.Hegyi.con.min2, color='#FFB867', size=0.2)+
        geom_line(data=TABR.Hegyi.con.min3, color='#FFB867', size=0.2)+
        geom_line(data=TABR.Hegyi.con.min4, color='#FFB867', size=0.2)+
        geom_line(data=TABR.Hegyi.con.min5, color='#FFB867', size=0.2)+
        geom_line(data=TABR.Hegyi.con.min6, color='#FFB867', size=0.2)+
        geom_line(data=TABR.Hegyi.con.min, color='#FE5900', size=0.4)+
        geom_line(data=TABR.Hegyi.con.max, color='black', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Taxus brevifolia"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      # grid.newpage()
      # pushViewport(viewport(layout = grid.layout(2,1)))
      # print(TABR1 + theme(plot.margin=unit(c(0,0,1,0),"mm"),legend.position='none',axis.title=element_blank()),vp=viewport(layout.pos.row=1,layout.pos.col=1))
      # print(TABR2 + theme(plot.margin=unit(c(0,0,1,0),"mm"),legend.position='none',axis.title=element_blank()),vp=viewport(layout.pos.row=2,layout.pos.col=1))
      # print(TABR3 + theme(plot.margin=unit(c(0,0,1,0),"mm"),legend.position='none',axis.title=element_blank()),vp=viewport(layout.pos.row=3,layout.pos.col=1))
      # 
      
      # dev.print(file=paste('./OUTPUT/Cox/Figures/wDBH/','TABR_hetvcon','.tif',sep=''),tiff,width=2.16,height=2,res=600,units='in',compression='lzw')
      # dev.print(file=paste('./Papers/Final Manuscript Documents/Fig2/','TABR_hetvcon','.tif',sep=''),tiff,width=1.6,height=3.2,res=600,units='in',compression='lzw')
      
      
      ##############-
      
      ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      ABAM.dat1x<-cbind(ABAM.Hegyi.het.max,ABAM.Hegyi.con.max); colnames(ABAM.dat1x) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat2x<-cbind(ABAM.Hegyi.het.max1,ABAM.Hegyi.con.max1); colnames(ABAM.dat2x) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat3x<-cbind(ABAM.Hegyi.het.max2,ABAM.Hegyi.con.max2); colnames(ABAM.dat3x) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat4x<-cbind(ABAM.Hegyi.het.max3,ABAM.Hegyi.con.max3); colnames(ABAM.dat4x) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat5x<-cbind(ABAM.Hegyi.het.max4,ABAM.Hegyi.con.max4); colnames(ABAM.dat5x) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat6x<-cbind(ABAM.Hegyi.het.max5,ABAM.Hegyi.con.max5); colnames(ABAM.dat6x) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat7x<-cbind(ABAM.Hegyi.het.max6,ABAM.Hegyi.con.max6); colnames(ABAM.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      ABAM.dat1n<-cbind(ABAM.Hegyi.het.min,ABAM.Hegyi.con.min); colnames(ABAM.dat1n) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat2n<-cbind(ABAM.Hegyi.het.min1,ABAM.Hegyi.con.min1); colnames(ABAM.dat2n) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat3n<-cbind(ABAM.Hegyi.het.min2,ABAM.Hegyi.con.min2); colnames(ABAM.dat3n) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat4n<-cbind(ABAM.Hegyi.het.min3,ABAM.Hegyi.con.min3); colnames(ABAM.dat4n) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat5n<-cbind(ABAM.Hegyi.het.min4,ABAM.Hegyi.con.min4); colnames(ABAM.dat5n) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat6n<-cbind(ABAM.Hegyi.het.min5,ABAM.Hegyi.con.min5); colnames(ABAM.dat6n) <- c('HRh','yearh','HRc','yearc')
      ABAM.dat7n<-cbind(ABAM.Hegyi.het.min6,ABAM.Hegyi.con.min6); colnames(ABAM.dat7n) <- c('HRh','yearh','HRc','yearc')
      
      ABAM4a<-ggplot(data=ABAM.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=ABAM.dat2x, color='grey', size=0.2)+ 
        geom_line(data=ABAM.dat3x, color='grey', size=0.2)+ 
        geom_line(data=ABAM.dat4x, color='grey', size=0.2)+ 
        geom_line(data=ABAM.dat5x, color='grey', size=0.2)+ 
        geom_line(data=ABAM.dat6x, color='grey', size=0.2)+ 
        geom_line(data=ABAM.dat7x, color='grey', size=0.2)+
        geom_line(data=ABAM.dat2n, color='#FFB867', size=0.2)+ 
        geom_line(data=ABAM.dat3n, color='#FFB867', size=0.2)+ 
        geom_line(data=ABAM.dat4n, color='#FFB867', size=0.2)+ 
        geom_line(data=ABAM.dat5n, color='#FFB867', size=0.2)+ 
        geom_line(data=ABAM.dat6n, color='#FFB867', size=0.2)+ 
        geom_line(data=ABAM.dat7n, color='#FFB867', size=0.2)+ 
        geom_line(data=ABAM.dat1n, color='#FE5900', size=0.4)+
        geom_line(data=ABAM.dat1x, color='black', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Abies amabilis"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      ##############-
      
      ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      TSHE.dat1x<-cbind(TSHE.Hegyi.het.max,TSHE.Hegyi.con.max); colnames(TSHE.dat1x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat2x<-cbind(TSHE.Hegyi.het.max1,TSHE.Hegyi.con.max1); colnames(TSHE.dat2x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat3x<-cbind(TSHE.Hegyi.het.max2,TSHE.Hegyi.con.max2); colnames(TSHE.dat3x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat4x<-cbind(TSHE.Hegyi.het.max3,TSHE.Hegyi.con.max3); colnames(TSHE.dat4x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat5x<-cbind(TSHE.Hegyi.het.max4,TSHE.Hegyi.con.max4); colnames(TSHE.dat5x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat6x<-cbind(TSHE.Hegyi.het.max5,TSHE.Hegyi.con.max5); colnames(TSHE.dat6x) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat7x<-cbind(TSHE.Hegyi.het.max6,TSHE.Hegyi.con.max6); colnames(TSHE.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      TSHE.dat1n<-cbind(TSHE.Hegyi.het.min,TSHE.Hegyi.con.min); colnames(TSHE.dat1n) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat2n<-cbind(TSHE.Hegyi.het.min1,TSHE.Hegyi.con.min1); colnames(TSHE.dat2n) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat3n<-cbind(TSHE.Hegyi.het.min2,TSHE.Hegyi.con.min2); colnames(TSHE.dat3n) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat4n<-cbind(TSHE.Hegyi.het.min3,TSHE.Hegyi.con.min3); colnames(TSHE.dat4n) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat5n<-cbind(TSHE.Hegyi.het.min4,TSHE.Hegyi.con.min4); colnames(TSHE.dat5n) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat6n<-cbind(TSHE.Hegyi.het.min5,TSHE.Hegyi.con.min5); colnames(TSHE.dat6n) <- c('HRh','yearh','HRc','yearc')
      TSHE.dat7n<-cbind(TSHE.Hegyi.het.min6,TSHE.Hegyi.con.min6); colnames(TSHE.dat7n) <- c('HRh','yearh','HRc','yearc')
      
      TSHE4a<-ggplot(data=TSHE.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=TSHE.dat2x, color='grey', size=0.2)+
        geom_line(data=TSHE.dat3x, color='grey', size=0.2)+
        geom_line(data=TSHE.dat4x, color='grey', size=0.2)+
        geom_line(data=TSHE.dat5x, color='grey', size=0.2)+
        geom_line(data=TSHE.dat6x, color='grey', size=0.2)+
        geom_line(data=TSHE.dat7x, color='grey', size=0.2)+
        geom_line(data=TSHE.dat2n, color='#FFB867', size=0.2)+
        geom_line(data=TSHE.dat3n, color='#FFB867', size=0.2)+
        geom_line(data=TSHE.dat4n, color='#FFB867', size=0.2)+
        geom_line(data=TSHE.dat5n, color='#FFB867', size=0.2)+
        geom_line(data=TSHE.dat6n, color='#FFB867', size=0.2)+
        geom_line(data=TSHE.dat7n, color='#FFB867', size=0.2)+
        geom_line(data=TSHE.dat1n, color='#FE5900', size=0.4)+
        geom_line(data=TSHE.dat1x, color='black', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      ##############-
      
      ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      #to 2019
      PSME.dat1x<-cbind(PSME.Hegyi.het.max,PSME.Hegyi.con.max); colnames(PSME.dat1x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat2x<-cbind(PSME.Hegyi.het.max1,PSME.Hegyi.con.max1); colnames(PSME.dat2x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat3x<-cbind(PSME.Hegyi.het.max2,PSME.Hegyi.con.max2); colnames(PSME.dat3x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat4x<-cbind(PSME.Hegyi.het.max3,PSME.Hegyi.con.max3); colnames(PSME.dat4x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat5x<-cbind(PSME.Hegyi.het.max4,PSME.Hegyi.con.max4); colnames(PSME.dat5x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat6x<-cbind(PSME.Hegyi.het.max5,PSME.Hegyi.con.max5); colnames(PSME.dat6x) <- c('HRh','yearh','HRc','yearc')
      PSME.dat7x<-cbind(PSME.Hegyi.het.max6,PSME.Hegyi.con.max6); colnames(PSME.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      PSME.dat1n<-cbind(PSME.Hegyi.het.min,PSME.Hegyi.con.min); colnames(PSME.dat1n) <- c('HRh','yearh','HRc','yearc')
      PSME.dat2n<-cbind(PSME.Hegyi.het.min1,PSME.Hegyi.con.min1); colnames(PSME.dat2n) <- c('HRh','yearh','HRc','yearc')
      PSME.dat3n<-cbind(PSME.Hegyi.het.min2,PSME.Hegyi.con.min2); colnames(PSME.dat3n) <- c('HRh','yearh','HRc','yearc')
      PSME.dat4n<-cbind(PSME.Hegyi.het.min3,PSME.Hegyi.con.min3); colnames(PSME.dat4n) <- c('HRh','yearh','HRc','yearc')
      PSME.dat5n<-cbind(PSME.Hegyi.het.min4,PSME.Hegyi.con.min4); colnames(PSME.dat5n) <- c('HRh','yearh','HRc','yearc')
      PSME.dat6n<-cbind(PSME.Hegyi.het.min5,PSME.Hegyi.con.min5); colnames(PSME.dat6n) <- c('HRh','yearh','HRc','yearc')
      PSME.dat7n<-cbind(PSME.Hegyi.het.min6,PSME.Hegyi.con.min6); colnames(PSME.dat7n) <- c('HRh','yearh','HRc','yearc')
      
      PSME4a<-ggplot(data=PSME.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=PSME.dat2x, color='grey', size=0.2)+ 
        geom_line(data=PSME.dat3x, color='grey', size=0.2)+ 
        geom_line(data=PSME.dat4x, color='grey', size=0.2)+ 
        geom_line(data=PSME.dat5x, color='grey', size=0.2)+ 
        geom_line(data=PSME.dat6x, color='grey', size=0.2)+ 
        geom_line(data=PSME.dat7x, color='grey', size=0.2)+
        geom_line(data=PSME.dat2n, color='#FFB867', size=0.2)+ 
        geom_line(data=PSME.dat3n, color='#FFB867', size=0.2)+ 
        geom_line(data=PSME.dat4n, color='#FFB867', size=0.2)+ 
        geom_line(data=PSME.dat5n, color='#FFB867', size=0.2)+ 
        geom_line(data=PSME.dat6n, color='#FFB867', size=0.2)+ 
        geom_line(data=PSME.dat7n, color='#FFB867', size=0.2)+ 
        geom_line(data=PSME.dat1n, color='#FE5900', size=0.4)+
        geom_line(data=PSME.dat1x, color='black', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      ##############-
      
      # DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
      ## to 2019
      ACCI.dat1x<-cbind(ACCI.Hegyi.het.max,ACCI.Hegyi.con.max); colnames(ACCI.dat1x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat2x<-cbind(ACCI.Hegyi.het.max1,ACCI.Hegyi.con.max1); colnames(ACCI.dat2x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat3x<-cbind(ACCI.Hegyi.het.max2,ACCI.Hegyi.con.max2); colnames(ACCI.dat3x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat4x<-cbind(ACCI.Hegyi.het.max3,ACCI.Hegyi.con.max3); colnames(ACCI.dat4x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat5x<-cbind(ACCI.Hegyi.het.max4,ACCI.Hegyi.con.max4); colnames(ACCI.dat5x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat6x<-cbind(ACCI.Hegyi.het.max5,ACCI.Hegyi.con.max5); colnames(ACCI.dat6x) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat7x<-cbind(ACCI.Hegyi.het.max6,ACCI.Hegyi.con.max6); colnames(ACCI.dat7x) <- c('HRh','yearh','HRc','yearc')
      
      ACCI.dat1n<-cbind(ACCI.Hegyi.het.min,ACCI.Hegyi.con.min); colnames(ACCI.dat1n) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat2n<-cbind(ACCI.Hegyi.het.min1,ACCI.Hegyi.con.min1); colnames(ACCI.dat2n) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat3n<-cbind(ACCI.Hegyi.het.min2,ACCI.Hegyi.con.min2); colnames(ACCI.dat3n) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat4n<-cbind(ACCI.Hegyi.het.min3,ACCI.Hegyi.con.min3); colnames(ACCI.dat4n) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat5n<-cbind(ACCI.Hegyi.het.min4,ACCI.Hegyi.con.min4); colnames(ACCI.dat5n) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat6n<-cbind(ACCI.Hegyi.het.min5,ACCI.Hegyi.con.min5); colnames(ACCI.dat6n) <- c('HRh','yearh','HRc','yearc')
      ACCI.dat7n<-cbind(ACCI.Hegyi.het.min6,ACCI.Hegyi.con.min6); colnames(ACCI.dat7n) <- c('HRh','yearh','HRc','yearc')
      
      ACCI4a<-ggplot(data=ACCI.dat1x, aes(yearc,HRc-HRh)) + theme_prefs +
        geom_line(data=ACCI.dat2x, color='grey', size=0.2)+ 
        geom_line(data=ACCI.dat3x, color='grey', size=0.2)+ 
        geom_line(data=ACCI.dat4x, color='grey', size=0.2)+ 
        geom_line(data=ACCI.dat5x, color='grey', size=0.2)+ 
        geom_line(data=ACCI.dat6x, color='grey', size=0.2)+ 
        geom_line(data=ACCI.dat7x, color='grey', size=0.2)+
        geom_line(data=ACCI.dat2n, color='#FFB867', size=0.2)+ 
        geom_line(data=ACCI.dat3n, color='#FFB867', size=0.2)+ 
        geom_line(data=ACCI.dat4n, color='#FFB867', size=0.2)+ 
        geom_line(data=ACCI.dat5n, color='#FFB867', size=0.2)+ 
        geom_line(data=ACCI.dat6n, color='#FFB867', size=0.2)+ 
        geom_line(data=ACCI.dat7n, color='#FFB867', size=0.2)+ 
        geom_line(data=ACCI.dat1n, color='#FE5900', size=0.4)+
        geom_line(data=ACCI.dat1x, color='black', size=0.4)+
        geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
        # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
        theme(axis.title = element_blank()) +
        # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
        scale_x_continuous(breaks=seq(2020,2100,20)) +
        scale_y_continuous(breaks=seq(-2,2,1))+
        coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
        geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                  linetype='dashed', color="black", alpha=0, size=0.2)
      
      
      #########-
      # plot<-plot_grid(ABAM4, PSME4, TABR4, TSHE4, ACCI4, COCOC4, VAPA4, nrow=2, ncol=4, align='v')
      plot<-plot_grid(ABAM4a, PSME4a, TABR4a, TSHE4a, ACCI4a, nrow=2, ncol=3, align='v')
      
      y.grob<-textGrob("Stability Strength", gp=gpar(col="black", fontsize=10), rot=90)
      x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
      
      gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
      
      dev.print(file=paste('./OUTPUT/Neighborhood/SENSITIVITY_4/','Fig2_with2019_noMECH_heg50b','.tif',sep=''),tiff,width=7.0,height=6.5,res=600,units='in',compression='lzw')
      # dev.print(file=paste('./Papers/','Fig2_with2019','.tif',sep=''),tiff,width=6.75,height=6.5,res=600,units='in',compression='lzw')
      
    }
    
  }
  
  ###############################################################################################################################################################
  
  ###############################################################################################################################################################-
  ###############################################################     UNCERTAINTY & COMMUNITY PLOTS (S11)   #####################################################'
  #--------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  load('./OUTPUT/Cox/SENSITIVITY_4/all_models_hetcon_w2019_wo2011_scaledHegyis_noMECH_20200710_heg50b.Rdata')
  
  library('rms')
  
  hazard.calc.cont.SE<-function(SE = 'none', units=1,watertable.value='mean',Hegyi.het.value='mean',Hegyi.con.value='mean',
                                species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                                predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                                tables=c('table.6'),climate.model=mean.model.lag){
    
    #center in same way as parameterized variables
    centered<-climate.model
    defx <- mean(centered[centered$year<2020&centered$year>2011,'Deficit'])
    snowx <- mean(centered[centered$year<2020&centered$year>2011,'snow'])
    centered[4]<-apply(centered[4],2,function(x) x-defx)
    centered[3]<-apply(centered[3],2,function(x) x-snowx)
    
    HR.continuous<-data.frame()
    sum.multiplier.continuous<-data.frame('year'=1951:2099,'sum'=NA)
    years<-c(1951:2099)
    
    for(k in species){
      for(j in predictors){ 
        if (exists(paste(tables,k,j,sep='.'))){
          for (a in years){
            mod.continuous<-eval(parse(text=paste(tables,k,j,sep='.')))
            rownames(mod.continuous)<-mod.continuous$predictor
            
            all.pred.continuous<-unlist(strsplit(mod.continuous$predictor,':',fixed=TRUE))
            all.pred.continuous<-unique(all.pred.continuous[all.pred.continuous!=j])
            
            beta.i.continuous<-mod.continuous[mod.continuous$predictor==j,'beta']
            
            SE.table = as.data.frame(summary(eval(parse(text=paste(species,'hetcon',sep='.'))))$coefficients)
            SE.table$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',rownames(SE.table))
            SE.table$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',SE.table$`Pretty Names`)
            SE.table$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',SE.table$`Pretty Names`)
            SE.table$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',SE.table$`Pretty Names`)
            SE.table$`Pretty Names`<-gsub(pattern='Neighbors.richness',replacement='richness',SE.table$`Pretty Names`)
            
            SE.beta = SE.table[SE.table$`Pretty Names` == j,4]
            
            if (SE == 'high'){
              beta.i.continuous<-beta.i.continuous + SE.beta
            } else if (SE == 'low'){
              beta.i.continuous<-beta.i.continuous - SE.beta
            } else ''
            
            #separate all interactions into component pieces
            if(length(grep('Deficit',all.pred.continuous,value=TRUE,fixed=TRUE)>0)|length(grep('snow',all.pred.continuous,value=TRUE,fixed=TRUE)>0)){
              if (nrow(mod.continuous)>1){
                
                for(m in mod.continuous$predictor){
                  SE.pred = SE.table[SE.table$`Pretty Names` == m,4]
                  
                  if (SE == 'high'){
                    mod.continuous[mod.continuous$predictor==m,'beta']<- mod.continuous[mod.continuous$predictor==m,'beta'] + SE.pred
                  } else if (SE == 'low'){
                    mod.continuous[mod.continuous$predictor==m,'beta']<- mod.continuous[mod.continuous$predictor==m,'beta'] - SE.pred
                  } else ''
                  
                  if(m != j){
                    
                    bn.continuous<-unlist(strsplit(m,':',fixed=TRUE))
                    bn.continuous<-bn.continuous[bn.continuous!=j]
                    
                    for(o in bn.continuous){
                      if(o %in% c('Deficit','snow')){
                        vn.continuous<-centered[centered$year==a,o]
                        mod.continuous[m,paste(o,a,'vn',sep='.')]<-vn.continuous
                      } else {
                        vn.continuous<-Variable.Summaries[Variable.Summaries$Species==paste(k,'gen',sep='.')&Variable.Summaries$`Pretty Names`==o,eval(parse(text=paste(o,'value',sep='.')))]
                        mod.continuous[m,paste(o,eval(parse(text=paste(o,'value',sep='.'))),'vn',sep='.')]<-vn.continuous
                        print(paste(a," - ",k,".",o,sep = ''))
                      }
                    }
                    
                    #multiply interaction beta by value of components
                    mod.continuous[m,'multiplier']<-apply(mod.continuous[m,!colnames(mod.continuous)%in%c('multiplier','predictor')],1,prod,na.rm=T) 
                  }
                  
                  mod.continuous[mod.continuous$predictor==j,'multiplier']<-0
                }
                
                sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-sum(mod.continuous$multiplier,na.rm=T)
              } else sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0
              
              HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']))
              HR.continuous[paste(k,j,a,sep='.'),'year']<-a
              
            } else {sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0; # 3 new lines here deal with non-climate-interacting predictors
            HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']));
            HR.continuous[paste(k,j,a,sep='.'),'year']<-a}
          }
        }
      }
    }
    return(HR.continuous)
  }
  
  
  ####### MEANS ####-
  {
    ## ABAM
    ABAM.table<-hazard.calc.cont.SE(species = 'ABAM', predictors = 'Hegyi.con')
    ABAM.table$lower.c<-hazard.calc.cont.SE(SE = 'low', species = 'ABAM', predictors = 'Hegyi.con')$HR
    ABAM.table$upper.c<-hazard.calc.cont.SE(SE = 'high', species = 'ABAM', predictors = 'Hegyi.con')$HR
    
    ABAM.table$HR.h<-hazard.calc.cont.SE(species = 'ABAM', predictors = 'Hegyi.het')$HR
    ABAM.table$lower.h<-hazard.calc.cont.SE(SE = 'low', species = 'ABAM', predictors = 'Hegyi.het')$HR
    ABAM.table$upper.h<-hazard.calc.cont.SE(SE = 'high', species = 'ABAM', predictors = 'Hegyi.het')$HR
    
    colnames(ABAM.table)[1] <- 'HR.c'
    
    ## PSME
    # PSME.table<-hazard.calc.cont.SE(species = 'PSME', predictors = 'Hegyi.con')
    # PSME.table$lower.c<-hazard.calc.cont.SE(SE = 'low', species = 'PSME', predictors = 'Hegyi.con')$HR
    # PSME.table$upper.c<-hazard.calc.cont.SE(SE = 'high', species = 'PSME', predictors = 'Hegyi.con')$HR
    # 
    # # PSME.table$HR.h<-hazard.calc.cont.SE(species = 'PSME', predictors = 'Hegyi.het')$HR
    # # PSME.table$lower.h<-hazard.calc.cont.SE(SE = 'low', species = 'PSME', predictors = 'Hegyi.het')$HR
    # # PSME.table$upper.h<-hazard.calc.cont.SE(SE = 'high', species = 'PSME', predictors = 'Hegyi.het')$HR
    # # 
    # PSME.table$HR.h<-1
    # PSME.table$lower.h<-0
    # PSME.table$upper.h<-0
    # 
    # colnames(PSME.table)[1] <- 'HR.c'
    
    #----#
    PSME.table<-hazard.calc.cont.SE(species = 'PSME', predictors = 'Hegyi.het')
    PSME.table$lower.h<-hazard.calc.cont.SE(SE = 'low', species = 'PSME', predictors = 'Hegyi.het')$HR
    PSME.table$upper.h<-hazard.calc.cont.SE(SE = 'high', species = 'PSME', predictors = 'Hegyi.het')$HR
    
    PSME.table$HR.c<-1
    PSME.table$lower.c<-0
    PSME.table$upper.c<-0
    
    colnames(PSME.table)[1] <- 'HR.h'
    
    ## TABR
    TABR.table<-hazard.calc.cont.SE(species = 'TABR', predictors = 'Hegyi.con')
    TABR.table$lower.c<-hazard.calc.cont.SE(SE = 'low', species = 'TABR', predictors = 'Hegyi.con')$HR
    TABR.table$upper.c<-hazard.calc.cont.SE(SE = 'high', species = 'TABR', predictors = 'Hegyi.con')$HR
    
    TABR.table$HR.h<-hazard.calc.cont.SE(species = 'TABR', predictors = 'Hegyi.het')$HR
    TABR.table$lower.h<-hazard.calc.cont.SE(SE = 'low', species = 'TABR', predictors = 'Hegyi.het')$HR
    TABR.table$upper.h<-hazard.calc.cont.SE(SE = 'high', species = 'TABR', predictors = 'Hegyi.het')$HR
    
    # TABR.table$HR.h<-1
    # TABR.table$lower.h<-0
    # TABR.table$upper.h<-0
    
    colnames(TABR.table)[1] <- 'HR.c'
    
    ## TSHE
    TSHE.table<-hazard.calc.cont.SE(species = 'TSHE', predictors = 'Hegyi.con')
    TSHE.table$lower.c<-hazard.calc.cont.SE(SE = 'low', species = 'TSHE', predictors = 'Hegyi.con')$HR
    TSHE.table$upper.c<-hazard.calc.cont.SE(SE = 'high', species = 'TSHE', predictors = 'Hegyi.con')$HR
    
    TSHE.table$HR.h<-hazard.calc.cont.SE(species = 'TSHE', predictors = 'Hegyi.het')$HR
    TSHE.table$lower.h<-hazard.calc.cont.SE(SE = 'low', species = 'TSHE', predictors = 'Hegyi.het')$HR
    TSHE.table$upper.h<-hazard.calc.cont.SE(SE = 'high', species = 'TSHE', predictors = 'Hegyi.het')$HR
    
    # TSHE.table$HR.h<-1
    # TSHE.table$lower.h<-0
    # TSHE.table$upper.h<-0
    
    colnames(TSHE.table)[1] <- 'HR.c'
    
    # ## ACCI
    # ACCI.table<-hazard.calc.cont.SE(species = 'ACCI', predictors = 'Hegyi.con')
    # ACCI.table$lower.c<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI', predictors = 'Hegyi.con')$HR
    # ACCI.table$upper.c<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI', predictors = 'Hegyi.con')$HR
    # 
    # ACCI.table$HR.h<-hazard.calc.cont.SE(species = 'ACCI', predictors = 'Hegyi.het')$HR
    # ACCI.table$lower.h<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI', predictors = 'Hegyi.het')$HR
    # ACCI.table$upper.h<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI', predictors = 'Hegyi.het')$HR
    # 
    # # ACCI.table$HR.h<-1
    # # ACCI.table$lower.h<-0
    # # ACCI.table$upper.h<-0
    # # 
    # colnames(ACCI.table)[1] <- 'HR.c'
    
    #----#
    ACCI.table<-hazard.calc.cont.SE(species = 'ACCI', predictors = 'Hegyi.het')
    ACCI.table$lower.h<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI', predictors = 'Hegyi.het')$HR
    ACCI.table$upper.h<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI', predictors = 'Hegyi.het')$HR
    
    ACCI.table$HR.c<-1
    ACCI.table$lower.c<-0
    ACCI.table$upper.c<-0
    
    colnames(ACCI.table)[1] <- 'HR.h'
    
    #### AVERAGE ACROSS COMMUNITY ###########-
    
    load(file = './OUTPUT/Cox/BA_weighted_averages_20181219')
    sum.weights <- sum(snapshots[snapshots$SPECIES%in%c('ABAM','PSME','TABR','TSHE','ACCI'),'BA.17.weighted']) # omit species with WACK numbers
    
    ABAM.table.weighted <- ABAM.table[,c('year','HR.c','HR.h')]
    ABAM.table.weighted[2:3] <- apply(ABAM.table.weighted[2:3],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='ABAM','BA.17.weighted'])
    
    PSME.table.weighted <- PSME.table[,c('year','HR.c','HR.h')]
    PSME.table.weighted[2:3] <- apply(PSME.table.weighted[2:3],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='PSME','BA.17.weighted'])
    PSME.table.weighted[c('HR.c')] <- NA
    
    
    TABR.table.weighted <- TABR.table[,c('year','HR.c','HR.h')]
    TABR.table.weighted[2:3] <- apply(TABR.table.weighted[2:3],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='TABR','BA.17.weighted'])
    # TABR.table.weighted[c('HR.h')] <- NA
    
    TSHE.table.weighted <- TSHE.table[,c('year','HR.c','HR.h')]
    TSHE.table.weighted[2:3] <- apply(TSHE.table.weighted[2:3],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='TSHE','BA.17.weighted'])
    # TSHE.table.weighted[c('HR.h')] <- NA
    
    ACCI.table.weighted <- ACCI.table[,c('year','HR.c','HR.h')]
    ACCI.table.weighted[2:3] <- apply(ACCI.table.weighted[2:3],2,
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='ACCI','BA.17.weighted'])
    ACCI.table.weighted[c('HR.c')] <- NA
    
    
    ##### omit species with WACK numbers
    
    community.table.weighted <- rbind(ABAM.table.weighted,PSME.table.weighted,TABR.table.weighted,
                                      TSHE.table.weighted, ACCI.table.weighted)
    
    community.weighted<-setNames(aggregate(community.table.weighted$HR.c,by=list(community.table.weighted$year),FUN=sum, na.rm = T),c('year','HR.c'))
    community.weighted$HR.h<-aggregate(community.table.weighted$HR.h,by=list(community.table.weighted$year),FUN=sum, na.rm = T)$x
    
    #weighted average of HR
    community.weighted[2:3] <- apply(community.weighted[2:3],2, 
                                     FUN = function(x) x / sum.weights)
    
    
    
    
    ######### PLOTS ############-
    ABAM.plot <- ggplot(data=ABAM.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c, ymax=upper.c), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c), color = 'red') +
      geom_ribbon(aes(ymin=lower.h, ymax=upper.h), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    PSME.plot <- ggplot(data=PSME.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c, ymax=upper.c), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c), color = 'red') +
      geom_ribbon(aes(ymin=lower.h, ymax=upper.h), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    TABR.plot <- ggplot(data=TABR.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c, ymax=upper.c), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c), color = 'red') +
      geom_ribbon(aes(ymin=lower.h, ymax=upper.h), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    TSHE.plot <- ggplot(data=TSHE.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c, ymax=upper.c), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c), color = 'red') +
      geom_ribbon(aes(ymin=lower.h, ymax=upper.h), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    ACCI.plot <- ggplot(data=ACCI.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c, ymax=upper.c), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c), color = 'red') +
      geom_ribbon(aes(ymin=lower.h, ymax=upper.h), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    
    community.plot <- ggplot(data=community.weighted,aes(x = year))+theme_prefs+
      geom_line(aes(y = HR.c), color = 'red') +
      geom_line(aes(y = HR.h), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    
    community.plot4<-ggplot(data=community.weighted, aes(year,HR.c-HR.h)) + theme_prefs +
      geom_line(color='red', size=0.4)+
      geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
      # theme(axis.title.x = element_blank(),axis.title.y = element_blank()) +
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(-2,2,1))+
      coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(-10,10,2))+ # could also use these dimensions
    #   coord_cartesian(ylim=c(-11,11), xlim=c(2010,2105))+
    #   geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #             linetype='dashed', color="black", alpha=0, size=0.2)
    
    #### all spp plots
    # plot<-plot_grid(ABAM.plot,PSME.plot,TABR.plot,TSHE.plot,
    #                 ACCI.plot,COCOC.plot,VAPA.plot,nrow=2, ncol=4, align='v')
    plot<-plot_grid(ABAM.plot,PSME.plot,TABR.plot,TSHE.plot, ACCI.plot,
                    nrow=2, ncol=3, align='v')
    y.grob<-textGrob("Hazard Ratio", gp=gpar(col="black", fontsize=10), rot=90)
    x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
    
    gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
    
    dev.print(file=paste('./Papers/','Fig3c_with2019_noMECH','.tif',sep=''),tiff,width=7,height=7,res=600,units='in',compression='lzw')
    
    #### comm plot
    plot<-plot_grid(community.plot4,nrow=1, ncol=1, align='v')
    y.grob<-textGrob("Stability Strength", gp=gpar(col="black", fontsize=10), rot=90)
    x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
    
    gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
    
    dev.print(file=paste('./Papers/','Fig4c_with2019_noMECH','.tif',sep=''),tiff,width=4,height=4,res=600,units='in',compression='lzw')
    
  }
  
  ####### MIN and MAX ####-
  {
    ## ABAM
    ABAM.table<-hazard.calc.cont.SE(species = 'ABAM',watertable.value = 'min', predictors = 'Hegyi.con')
    ABAM.table$lower.c.wet<-hazard.calc.cont.SE(SE = 'low', species = 'ABAM',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    ABAM.table$upper.c.wet<-hazard.calc.cont.SE(SE = 'high', species = 'ABAM',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    ABAM.table$HR.c.dry<-hazard.calc.cont.SE(species = 'ABAM',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    ABAM.table$lower.c.dry<-hazard.calc.cont.SE(SE = 'low', species = 'ABAM',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    ABAM.table$upper.c.dry<-hazard.calc.cont.SE(SE = 'high', species = 'ABAM',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    
    ABAM.table$HR.h.wet<-hazard.calc.cont.SE(species = 'ABAM',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    ABAM.table$lower.h.wet<-hazard.calc.cont.SE(SE = 'low', species = 'ABAM',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    ABAM.table$upper.h.wet<-hazard.calc.cont.SE(SE = 'high', species = 'ABAM',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    ABAM.table$HR.h.dry<-hazard.calc.cont.SE(species = 'ABAM',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    ABAM.table$lower.h.dry<-hazard.calc.cont.SE(SE = 'low', species = 'ABAM',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    ABAM.table$upper.h.dry<-hazard.calc.cont.SE(SE = 'high', species = 'ABAM',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    
    colnames(ABAM.table)[1] <- 'HR.c.wet'
    
    ## PSME
    # PSME.table<-hazard.calc.cont.SE(species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.con')
    # PSME.table$lower.c.wet<-hazard.calc.cont.SE(SE = 'low', species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    # PSME.table$upper.c.wet<-hazard.calc.cont.SE(SE = 'high', species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    # PSME.table$HR.c.dry<-hazard.calc.cont.SE(species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    # PSME.table$lower.c.dry<-hazard.calc.cont.SE(SE = 'low', species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    # PSME.table$upper.c.dry<-hazard.calc.cont.SE(SE = 'high', species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    # 
    # # PSME.table$HR.h.wet<-hazard.calc.cont.SE(species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    # # PSME.table$lower.h.wet<-hazard.calc.cont.SE(SE = 'low', species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    # # PSME.table$upper.h.wet<-hazard.calc.cont.SE(SE = 'high', species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    # # PSME.table$HR.h.dry<-hazard.calc.cont.SE(species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    # # PSME.table$lower.h.dry<-hazard.calc.cont.SE(SE = 'low', species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    # # PSME.table$upper.h.dry<-hazard.calc.cont.SE(SE = 'high', species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    # 
    # PSME.table$HR.h.wet<-1
    # PSME.table$lower.h.wet<-0
    # PSME.table$upper.h.wet<-0
    # PSME.table$HR.h.dry<-1
    # PSME.table$lower.h.dry<-0
    # PSME.table$upper.h.dry<-0
    # 
    # colnames(PSME.table)[1] <- 'HR.c.wet'
    
    #---#
    PSME.table<-hazard.calc.cont.SE(species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.het')
    PSME.table$lower.h.wet<-hazard.calc.cont.SE(SE = 'low', species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    PSME.table$upper.h.wet<-hazard.calc.cont.SE(SE = 'high', species = 'PSME',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    PSME.table$HR.h.dry<-hazard.calc.cont.SE(species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    PSME.table$lower.h.dry<-hazard.calc.cont.SE(SE = 'low', species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    PSME.table$upper.h.dry<-hazard.calc.cont.SE(SE = 'high', species = 'PSME',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    
    PSME.table$HR.c.wet<-1
    PSME.table$lower.c.wet<-0
    PSME.table$upper.c.wet<-0
    PSME.table$HR.c.dry<-1
    PSME.table$lower.c.dry<-0
    PSME.table$upper.c.dry<-0
    
    colnames(PSME.table)[1] <- 'HR.h.wet'
    
    ## TABR
    TABR.table<-hazard.calc.cont.SE(species = 'TABR',watertable.value = 'min', predictors = 'Hegyi.con')
    TABR.table$lower.c.wet<-hazard.calc.cont.SE(SE = 'low', species = 'TABR',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    TABR.table$upper.c.wet<-hazard.calc.cont.SE(SE = 'high', species = 'TABR',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    TABR.table$HR.c.dry<-hazard.calc.cont.SE(species = 'TABR',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    TABR.table$lower.c.dry<-hazard.calc.cont.SE(SE = 'low', species = 'TABR',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    TABR.table$upper.c.dry<-hazard.calc.cont.SE(SE = 'high', species = 'TABR',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    
    TABR.table$HR.h.wet<-hazard.calc.cont.SE(species = 'TABR',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    TABR.table$lower.h.wet<-hazard.calc.cont.SE(SE = 'low', species = 'TABR',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    TABR.table$upper.h.wet<-hazard.calc.cont.SE(SE = 'high', species = 'TABR',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    TABR.table$HR.h.dry<-hazard.calc.cont.SE(species = 'TABR',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    TABR.table$lower.h.dry<-hazard.calc.cont.SE(SE = 'low', species = 'TABR',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    TABR.table$upper.h.dry<-hazard.calc.cont.SE(SE = 'high', species = 'TABR',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    
    # TABR.table$HR.h.wet<-1
    # TABR.table$lower.h.wet<-0
    # TABR.table$upper.h.wet<-0
    # TABR.table$HR.h.dry<-1
    # TABR.table$lower.h.dry<-0
    # TABR.table$upper.h.dry<-0
    
    colnames(TABR.table)[1] <- 'HR.c.wet'
    
    ## TSHE
    TSHE.table<-hazard.calc.cont.SE(species = 'TSHE',watertable.value = 'min', predictors = 'Hegyi.con')
    TSHE.table$lower.c.wet<-hazard.calc.cont.SE(SE = 'low', species = 'TSHE',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    TSHE.table$upper.c.wet<-hazard.calc.cont.SE(SE = 'high', species = 'TSHE',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    TSHE.table$HR.c.dry<-hazard.calc.cont.SE(species = 'TSHE',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    TSHE.table$lower.c.dry<-hazard.calc.cont.SE(SE = 'low', species = 'TSHE',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    TSHE.table$upper.c.dry<-hazard.calc.cont.SE(SE = 'high', species = 'TSHE',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    
    TSHE.table$HR.h.wet<-hazard.calc.cont.SE(species = 'TSHE',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    TSHE.table$lower.h.wet<-hazard.calc.cont.SE(SE = 'low', species = 'TSHE',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    TSHE.table$upper.h.wet<-hazard.calc.cont.SE(SE = 'high', species = 'TSHE',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    TSHE.table$HR.h.dry<-hazard.calc.cont.SE(species = 'TSHE',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    TSHE.table$lower.h.dry<-hazard.calc.cont.SE(SE = 'low', species = 'TSHE',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    TSHE.table$upper.h.dry<-hazard.calc.cont.SE(SE = 'high', species = 'TSHE',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    
    # TSHE.table$HR.h.wet<-1
    # TSHE.table$lower.h.wet<-0
    # TSHE.table$upper.h.wet<-0
    # TSHE.table$HR.h.dry<-1
    # TSHE.table$lower.h.dry<-0
    # TSHE.table$upper.h.dry<-0
    
    colnames(TSHE.table)[1] <- 'HR.c.wet'
    
    ## ACCI
    # ACCI.table<-hazard.calc.cont.SE(species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.con')
    # ACCI.table$lower.c.wet<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    # ACCI.table$upper.c.wet<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.con')$HR
    # ACCI.table$HR.c.dry<-hazard.calc.cont.SE(species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    # ACCI.table$lower.c.dry<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    # ACCI.table$upper.c.dry<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.con')$HR
    # 
    # ACCI.table$HR.h.wet<-hazard.calc.cont.SE(species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    # ACCI.table$lower.h.wet<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    # ACCI.table$upper.h.wet<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    # ACCI.table$HR.h.dry<-hazard.calc.cont.SE(species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    # ACCI.table$lower.h.dry<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    # ACCI.table$upper.h.dry<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    # 
    # # ACCI.table$HR.h.wet<-1
    # # ACCI.table$lower.h.wet<-0
    # # ACCI.table$upper.h.wet<-0
    # # ACCI.table$HR.h.dry<-1
    # # ACCI.table$lower.h.dry<-0
    # # ACCI.table$upper.h.dry<-0
    # 
    # colnames(ACCI.table)[1] <- 'HR.c.wet'
    
    #---#
    ACCI.table<-hazard.calc.cont.SE(species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.het')
    ACCI.table$lower.h.wet<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    ACCI.table$upper.h.wet<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI',watertable.value = 'min', predictors = 'Hegyi.het')$HR
    ACCI.table$HR.h.dry<-hazard.calc.cont.SE(species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    ACCI.table$lower.h.dry<-hazard.calc.cont.SE(SE = 'low', species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    ACCI.table$upper.h.dry<-hazard.calc.cont.SE(SE = 'high', species = 'ACCI',watertable.value = 'max', predictors = 'Hegyi.het')$HR
    
    ACCI.table$HR.c.wet<-1
    ACCI.table$lower.c.wet<-0
    ACCI.table$upper.c.wet<-0
    ACCI.table$HR.c.dry<-1
    ACCI.table$lower.c.dry<-0
    ACCI.table$upper.c.dry<-0
    
    colnames(ACCI.table)[1] <- 'HR.h.wet'
    
    #### AVERAGE ACROSS COMMUNITY ###########-
    # if commented areas used above, use commented areas below accordingly / to match
    
    load(file = './OUTPUT/Cox/BA_weighted_averages_20181219')
    sum.weights <- sum(snapshots[snapshots$SPECIES%in%c('ABAM','PSME','TABR','TSHE','ACCI'),'BA.17.weighted'])
    
    ABAM.table.weighted <- ABAM.table[,c('year','HR.c.wet','HR.c.dry','HR.h.wet','HR.h.dry')]
    ABAM.table.weighted[2:5] <- apply(ABAM.table.weighted[2:5],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='ABAM','BA.17.weighted'])
    
    PSME.table.weighted <- PSME.table[,c('year','HR.c.wet','HR.c.dry','HR.h.wet','HR.h.dry')]
    PSME.table.weighted[2:5] <- apply(PSME.table.weighted[2:5],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='PSME','BA.17.weighted'])
    PSME.table.weighted[c('HR.c.wet','HR.c.dry')] <- NA
    
    
    TABR.table.weighted <- TABR.table[,c('year','HR.c.wet','HR.c.dry','HR.h.wet','HR.h.dry')]
    TABR.table.weighted[2:5] <- apply(TABR.table.weighted[2:5],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='TABR','BA.17.weighted'])
    # TABR.table.weighted[c('HR.h.wet','HR.h.dry')] <- NA
    
    
    TSHE.table.weighted <- TSHE.table[,c('year','HR.c.wet','HR.c.dry','HR.h.wet','HR.h.dry')]
    TSHE.table.weighted[2:5] <- apply(TSHE.table.weighted[2:5],2, 
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='TSHE','BA.17.weighted'])
    # TSHE.table.weighted[c('HR.h.wet','HR.h.dry')] <- NA
    
    
    ACCI.table.weighted <- ACCI.table[,c('year','HR.c.wet','HR.c.dry','HR.h.wet','HR.h.dry')]
    ACCI.table.weighted[2:5] <- apply(ACCI.table.weighted[2:5],2,
                                      FUN = function(x) x * snapshots[snapshots$SPECIES=='ACCI','BA.17.weighted'])
    ACCI.table.weighted[c('HR.c.wet','HR.c.dry')] <- NA
    
    
    
    community.table.weighted <- rbind(ABAM.table.weighted,PSME.table.weighted,TABR.table.weighted,
                                      TSHE.table.weighted, ACCI.table.weighted)
    
    wetdry.com.weighted<-setNames(aggregate(community.table.weighted$HR.c.wet,by=list(community.table.weighted$year),FUN=sum, na.rm = T),c('year','HR.c.wet'))
    wetdry.com.weighted$HR.c.dry<-aggregate(community.table.weighted$HR.c.dry,by=list(community.table.weighted$year),FUN=sum, na.rm = T)$x
    wetdry.com.weighted$HR.h.wet<-aggregate(community.table.weighted$HR.h.wet,by=list(community.table.weighted$year),FUN=sum, na.rm = T)$x
    wetdry.com.weighted$HR.h.dry<-aggregate(community.table.weighted$HR.h.dry,by=list(community.table.weighted$year),FUN=sum, na.rm = T)$x
    
    #weighted average of HR
    wetdry.com.weighted[2:5] <- apply(wetdry.com.weighted[2:5],2, 
                                      FUN = function(x) x / sum.weights)
    
    
    ######### PLOTS ############-
    ABAM.dry <- ggplot(data=ABAM.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.dry, ymax=upper.c.dry), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.dry, ymax=upper.h.dry), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    PSME.dry <- ggplot(data=PSME.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.dry, ymax=upper.c.dry), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.dry, ymax=upper.h.dry), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    TABR.dry <- ggplot(data=TABR.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.dry, ymax=upper.c.dry), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.dry, ymax=upper.h.dry), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    TSHE.dry <- ggplot(data=TSHE.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.dry, ymax=upper.c.dry), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.dry, ymax=upper.h.dry), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    ACCI.dry <- ggplot(data=ACCI.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.dry, ymax=upper.c.dry), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.dry, ymax=upper.h.dry), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,10,2))+
      theme(axis.title = element_blank()) +
      theme(axis.text.x = element_blank()) +
      coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    COCOC.dry <- ggplot(data=COCOC.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.dry, ymax=upper.c.dry), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.dry, ymax=upper.h.dry), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,10,2))+
      theme(axis.title = element_blank()) +
      theme(axis.text.x = element_blank()) +
      coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    VAPA.dry <- ggplot(data=VAPA.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.dry, ymax=upper.c.dry), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.dry, ymax=upper.h.dry), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,10,2))+
      theme(axis.title = element_blank()) +
      theme(axis.text.x = element_blank()) +
      coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    community.dry <- ggplot(data=wetdry.com.weighted,aes(x = year))+theme_prefs+
      geom_line(aes(y = HR.c.dry), color = 'red') +
      geom_line(aes(y = HR.h.dry), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    ###---
    ABAM.wet <- ggplot(data=ABAM.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.wet, ymax=upper.c.wet), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.wet, ymax=upper.h.wet), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    PSME.wet <- ggplot(data=PSME.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.wet, ymax=upper.c.wet), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.wet, ymax=upper.h.wet), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    TABR.wet <- ggplot(data=TABR.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.wet, ymax=upper.c.wet), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.wet, ymax=upper.h.wet), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    TSHE.wet <- ggplot(data=TSHE.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.wet, ymax=upper.c.wet), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.wet, ymax=upper.h.wet), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    ACCI.wet <- ggplot(data=ACCI.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.wet, ymax=upper.c.wet), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.wet, ymax=upper.h.wet), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,10,2))+
      theme(axis.title = element_blank()) +
      theme(axis.text.x = element_blank()) +
      coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    COCOC.wet <- ggplot(data=COCOC.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.wet, ymax=upper.c.wet), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.wet, ymax=upper.h.wet), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,10,2))+
      theme(axis.title = element_blank()) +
      theme(axis.text.x = element_blank()) +
      coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    VAPA.wet <- ggplot(data=VAPA.table,aes(x = year))+theme_prefs+
      geom_ribbon(aes(ymin=lower.c.wet, ymax=upper.c.wet), fill = 'red', alpha = 0.5)+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_ribbon(aes(ymin=lower.h.wet, ymax=upper.h.wet), fill = 'blue', alpha = 0.5)+
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,10,2))+
      theme(axis.title = element_blank()) +
      theme(axis.text.x = element_blank()) +
      coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    
    community.wet <- ggplot(data=wetdry.com.weighted,aes(x = year))+theme_prefs+
      geom_line(aes(y = HR.c.wet), color = 'red') +
      geom_line(aes(y = HR.h.wet), color = 'blue')+
      geom_hline(yintercept = 1,color='black', size = 0.2,linetype='dashed')+
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(0,2,1))+
      theme(axis.title = element_blank()) +
      coord_cartesian(ylim=c(-0.25,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-0.25), ymax=2.5),
                linetype='dashed', color="black", alpha=0, size=0.2)
    # scale_y_continuous(breaks=seq(0,10,2))+
    # theme(axis.title = element_blank()) +
    # theme(axis.text.x = element_blank()) +
    # coord_cartesian(ylim=c(-1,11), xlim=c(2010,2105))+
    # geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
    #           linetype='dashed', color="black", alpha=0, size=0.2)
    
    community.diff<-ggplot(data=wetdry.com.weighted, aes(x = year)) + theme_prefs +
      geom_line(aes(y = HR.c.wet - HR.h.wet), color='#FE5900', size=0.4)+
      geom_line(aes(y = HR.c.dry - HR.h.dry), color='black', size=0.4)+
      geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
      # xlab("year")+ylab("Coexistence Likelihood")+
      theme(axis.title = element_blank(),axis.title.x = element_blank(),axis.title.y = element_blank()) +
      # ggtitle(expression(bolditalic("Abies amabilis"))) +
      scale_x_continuous(breaks=seq(2020,2100,20)) +
      scale_y_continuous(breaks=seq(-2,2,1))+
      coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
      geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
                linetype='dashed', color="black", alpha=0, size=0.2)
    
    
    blank <- ggplot(data=VAPA.table,aes(x = year))+theme_prefs+
      theme(axis.title = element_blank(),axis.text = element_blank(),
            axis.ticks = element_blank(),axis.line = element_blank()) 
    
    ### all spp plots
    # plot<-plot_grid(ABAM.wet,PSME.wet,TABR.wet,TSHE.wet,
    #                 ABAM.dry,PSME.dry,TABR.dry,TSHE.dry,
    #                 ACCI.wet,COCOC.wet,VAPA.wet,blank,
    #                 ACCI.dry,COCOC.dry,VAPA.dry,nrow=4, ncol=4, align='v')
    plot<-plot_grid(ABAM.wet,PSME.wet,TABR.wet,TSHE.wet,
                    ABAM.dry,PSME.dry,TABR.dry,TSHE.dry,nrow=2, ncol=4, align='v')
    y.grob<-textGrob("Hazard Ratio", gp=gpar(col="black", fontsize=10), rot=90)
    x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
    
    gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
    
    dev.print(file=paste('./Papers/','Fig3all_w2019_conifers','.tif',sep=''),tiff,width=7.0,height=6.5,res=600,units='in',compression='lzw')
    
    
    ### comm plot
    plot<-plot_grid(community.plot4, community.diff,nrow=1, ncol=2, align='v')
    y.grob<-textGrob("Coexistence Likelihood", gp=gpar(col="black", fontsize=10), rot=90)
    x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
    
    gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
    
    dev.print(file=paste('./OUTPUT/Neighborhood/SENSITIVITY_4/','FigS11both_w2019_heg50b','.tif',sep=''),tiff,width=7,height=3.25,res=600,units='in',compression='lzw')
    
    
    ### comm.diff plot
    plot<-community.diff
    y.grob<-textGrob("Stability Strength", gp=gpar(col="black", fontsize=10), rot=90)
    x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
    
    gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
    
    dev.print(file=paste('./OUTPUT/Neighborhood/SENSITIVITY_4/','FigS11_w2019_heg50b','.tif',sep=''),tiff,width=4,height=4,res=600,units='in',compression='lzw')
    
  }
  
  ###############################################################################################################################################################
  
}


##############################################################################################################################################

##############################################################################################################################################-
##############################################                COMPARISON PLOT S12                #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------


table.e <- data.frame('focal' = rep(c(rep(10,3)),50), 
                      'neighbor' = rep(c(1,10,100),50),
                      'x' = rep(1:50,each=3), 'y' = NA, 'Kernel' = 'Exponential')
table.g <- data.frame('focal' = rep(c(rep(10,3)),50), 
                      'neighbor' = rep(c(1,10,100),50),
                      'x' = rep(1:50,each=3), 'y' = NA, 'Kernel' = 'Gaussian')
table.h <- data.frame('focal' = rep(c(rep(10,3)),50), 
                      'neighbor' = rep(c(1,10,100),50),
                      'x' = rep(1:50,each=3), 'y' = NA, 'Kernel' = 'Geometric')

table.e$y <- kern.exp(table.e$focal, table.e$neighbor, table.e$x)
table.g$y <- kern.invsq(table.g$focal, table.g$neighbor, table.g$x)
table.h$y <- kern.heg(table.h$focal, table.h$neighbor, table.h$x)

table <- rbind(table.e, table.g, table.h)

ggplot(table, aes(x = x, y = y, color = Kernel)) +
  facet_wrap(~as.factor(neighbor)) +
  geom_line(size=1) + coord_cartesian(ylim = c(0,5)) + 
  theme_prefs +
  ylab('Interaction Strength') + xlab('Distance (m)')


##############################################################################################################################################

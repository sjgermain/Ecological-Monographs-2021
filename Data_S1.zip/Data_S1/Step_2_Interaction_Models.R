## Wind River Stability - Survival Analysis ##
## Sara Germain ##
## March 2021 ##

setwd("WFDP_Demography_20200303")


RUN.WATERBALANCE=F
RUN.PRISM.SUMMARY=F

##############################################################################################################################################-
##############################################              LIBRARIES AND FUNCTIONS              #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

library("survival")
library('dplyr')
library('ggplot2')

#functions
mround<-function(x,base){
  base*round((x-(base/2-0.1))/base)
}

stand = function(focal.influence,mean.influence,sd.influence){
  (focal.influence-mean.influence)/sd.influence
}

basal_area = function(tree.DBH){
  return(0.0001*(pi*((0.5*tree.DBH)^2)))
}

theme_prefs<-theme_classic() + theme(axis.title.x = element_text(size=8),
                                     axis.title.y = element_text(size=8),
                                     axis.text.x = element_text(size=8, colour='black'),
                                     axis.text.y = element_text(size=8, colour='black'),
                                     axis.ticks = element_line(colour='black'),
                                     legend.text = element_text(size=8),
                                     legend.title = element_text(size=8),
                                     plot.title=element_text(size=10,hjust=0.5, vjust=-3))

##############################################################################################################################################

##############################################################################################################################################-
################################################              CREATE BASELINE DATA            ################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

#common species analyzed
spplist1<-c('ABAM','PSME','TABR','TSHE','ACCI')

#baseline data
trees<-read.csv("./DATA/WFDP_Tree_20200305.csv",na.strings='NULL') #SQL code = SELECT STEM_TAG, TREE_TAG, CENSUS, DATE, DBH_DATE, IN_YR, QUADRAT, SPECIES, DBH, GROWTH_DBH, BIOMASS_DBH, STATUS, MORT_DATE, VIGOR, DA, SC, SNAG_HEIGHT, SNAG_TD, PLOT_X, PLOT_Y, UTM_X, UTM_Y, RELATIVE_PLOT_X, RELATIVE_PLOT_Y, COMMENT, NURSE_LOG, ES, MT, LEANER_ANGLE FROM `Tree` WHERE QUADRAT not like 'Q%'
trees<-trees[(trees$MORT_DATE>0 & is.na(trees$MORT_DATE)==F)|is.na(trees$MORT_DATE)==T,]
trees[trees$CENSUS>17,"BIOMASS_DBH"] <- trees[trees$CENSUS>17,"DBH"]
trees<-trees[is.na(trees$BIOMASS_DBH)==F&is.na(trees$SPECIES)==F&is.na(trees$PLOT_X)==F&is.na(trees$PLOT_Y)==F,]
trees$STEM_TAG <- as.character(trees$STEM_TAG)

neighbors<-read.csv("./OUTPUT/Neighborhood/WFDP_Tree_with_neighbors_20200306.csv",na.strings='NA')
neighbors<-neighbors[(neighbors$MORT_DATE>0 & is.na(neighbors$MORT_DATE)==F)|is.na(neighbors$MORT_DATE)==T,]
neighbors$STEM_TAG <- as.character(neighbors$STEM_TAG)
nrow(neighbors[duplicated(neighbors$STEM_TAG),]) # double check!

morts<-read.csv("./DATA/WFDP_Mortality_20200311.csv",na.strings='NULL')
morts$STEM_TAG <- as.character(morts$STEM_TAG)
mechanical<-morts[(is.na(morts$FAD1)==F & morts$FAD1 >=80) | 
                    (is.na(morts$FAD2)==F & morts$FAD2 >=80) |
                    (is.na(morts$FAD3)==F & morts$FAD3 >=80) |
                    (is.na(morts$FAD4)==F & morts$FAD4 >=80) |
                    (is.na(morts$FAD5)==F & morts$FAD5 >=80),]
fungus<-mechanical[(is.na(mechanical$FAD1)==F & mechanical$FAD1 %in% 60:65) | 
                    (is.na(mechanical$FAD2)==F & mechanical$FAD2 %in% 60:65) |
                    (is.na(mechanical$FAD3)==F & mechanical$FAD3 %in% 60:65) |
                    (is.na(mechanical$FAD4)==F & mechanical$FAD4 %in% 60:65) |
                    (is.na(mechanical$FAD5)==F & mechanical$FAD5 %in% 60:65),]
  
mechanical<-mechanical[!mechanical$STEM_TAG %in% fungus$STEM_TAG,]  

# restrict dataset to common species
live.tree<-trees[trees$CENSUS>=17,]
live.tree<-live.tree[live.tree$CENSUS<20,] # no ingrowth from most recent year; consider only trees that COULD die
nrow(live.tree[duplicated(live.tree$STEM_TAG),]) # double check!

live.tree<-merge(live.tree,neighbors[c(1,31:82)],by='STEM_TAG')
live.tree[live.tree$STEM_TAG=='23-0378','BIOMASS_DBH']<-14.9
live.tree$DA<-NA
live.tree$DA<-ifelse(live.tree$STATUS%in%c(1,2),0,1)

live.tree$SPECIES<-as.character(live.tree$SPECIES)
live.tree <- live.tree[live.tree$SPECIES %in% spplist1,]

live.tree<-live.tree[!live.tree$STEM_TAG %in% mechanical$STEM_TAG,] #omit trees that died from mechanical damage

#### standardize and center
live.tree <- live.tree[abs(live.tree$zscore.Hegyi.het)<4 & abs(live.tree$zscore.Hegyi.con)<4,] #truncate dataset at +/- 4 SD
live.tree['elev.diff']<-apply(live.tree['elev.diff'],2,FUN= function(x){x-mean(x)}) #center elevation
live.tree['BIOMASS_DBH']<-apply(live.tree['BIOMASS_DBH'],1,FUN= function(x){log(x)}) #transform DBH 

live.tree$conifer<-ifelse(live.tree$SPECIES%in%c("TSHE","TABR","ABAM","PSME","THPL","ABGR","ABPR","PIMO"),1,0)
neighbor.predictors<-c("zscore.Hegyi.con","zscore.Hegyi.het","elev.diff")


## wet v dry tree mortality rates
# mort_fun <- function(population, mortalities, interval){
#   (1-(((population-mortalities)/population)^(1/interval)))*100
# }
# 
# wet <- mort_fun(nrow(live.tree[live.tree$elev.diff < 0,]),nrow(live.tree[live.tree$elev.diff < 0 & is.na(live.tree$MORT_DATE)==F,]),(2019-2011))
# dry <- mort_fun(nrow(live.tree[live.tree$elev.diff > 0,]),nrow(live.tree[live.tree$elev.diff > 0 & is.na(live.tree$MORT_DATE)==F,]),(2019-2011))
# 
# ## wet v dry tree recruitment rates
# rec_fun <- function(population, recruits, interval){
#   ((((population+recruits)/population)^(1/interval))-1)*100
# }
# 
# wet <- rec_fun(nrow(live.tree[live.tree$elev.diff < 0 & is.na(live.tree$IN_YR)==T,]),nrow(live.tree[live.tree$elev.diff < 0 & is.na(live.tree$IN_YR)==F,]),(2018-2011))
# dry <- rec_fun(nrow(live.tree[live.tree$elev.diff > 0 & is.na(live.tree$IN_YR)==T,]),nrow(live.tree[live.tree$elev.diff > 0 & is.na(live.tree$IN_YR)==F,]),(2018-2011))


## mortalities 
# morts<-read.csv("./DATA/Mortality/WFDP_Mortality_20190312.csv",na.strings='NULL')
# morts<-morts[!morts$STEM_TAG=='21-0609',]
# morts$STEM_TAG<-as.character(morts$STEM_TAG)
# morts<-merge(tree[,c("STEM_TAG","BIOMASS_DBH")],morts,by='STEM_TAG')
# morts$STEM_TAG<-as.character(morts$STEM_TAG)                   


#historical climate
if (RUN.WATERBALANCE==T) {
  
  ##############################################              LIBRARIES AND FUNCTIONS              #############################################-
  thornthwaite<-function (series, latitude, clim_norm = NULL, first.yr = NULL,last.yr = NULL, quant = c(0, 0.1, 0.25, 0.5, 0.75, 0.9, 1),
                           snow.init = 75, Tsnow = -1, TAW = 100, fr.sn.acc = 0.95,snow_melt_coeff = 1){
    
    ExAtRa<-function (DOY, latitude, Gsc = 0.082, unit = "mm", T = 12){
      phi <- latitude * pi/180
      delta <- 0.4093 * sin(2 * pi * (284 + DOY)/365)
      dr <- 1 + 0.033 * cos(2 * pi * DOY/365)
      omegaS <- acos(-tan(phi) * tan(delta))
      R_MJ <- (24 * (60)/pi) * Gsc * dr * ((omegaS) * sin(phi) * 
                                             sin(delta) + cos(phi) * cos(delta) * sin(omegaS))
      if (unit == "mm") {
        lambda <- 2.501 - 0.002361 * T
        R_H2O <- R_MJ/lambda
        return(R_H2O)
      }
      else if (unit == "MJ") 
        return(R_MJ)
      else print("Incorrect unit!", quote = FALSE)
    }
    
    daylength<-function (lat, doy){
      if (class(doy) == "Date" | class(doy) == "character") {
        doy <- as.character(doy)
        doy <- as.numeric(format(as.Date(doy), "%j"))
      }
      else {
        doy <- (doy - 1)%%365 + 1
      }
      lat[lat > 90 | lat < -90] <- NA
      P <- asin(0.39795 * cos(0.2163108 + 2 * atan(0.9671396 * 
                                                     tan(0.0086 * (doy - 186)))))
      a <- (sin(0.8333 * pi/180) + sin(lat * pi/180) * sin(P))/(cos(lat * 
                                                                      pi/180) * cos(P))
      a <- pmin(pmax(a, -1), 1)
      DL <- 24 - (24/pi) * acos(a)
      return(DL)
    }
    
    month_names <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    month_lengths <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 
                       30, 31)
    m <- c("min", paste(quant[-c(1, length(quant))] * 100, "%", 
                        sep = ""), "max")
    yDay <- strptime(paste(15, "/", 1:12, "/", 2014, sep = ""), 
                     format = "%d/%m/%Y")$yday + 1
    rel_daylength <- daylength(latitude, yDay)/12
    chg <- ExAtRa(DOY = yDay, latitude = latitude, unit = "mm")
    fTAW <- (-1.05e-07 * TAW^2 + 5.4225e-05 * TAW - 0.00878)
    ultStorPrA <- TAW
    if (is.null(first.yr)) 
      first.yr <- min(series$year)
    else first.yr <- max(first.yr, min(series$year))
    if (is.null(last.yr)) 
      last.yr <- max(series$year)
    else last.yr <- min(last.yr, max(series$year))
    years <- first.yr:last.yr
    tPrec <- seq(1:12)
    tET0 <- seq(1:12)
    tStor <- seq(1:12)
    tPmE <- seq(1:12)
    tDef <- seq(1:12)
    tSur <- seq(1:12)
    tPack <- seq(1:12)
    snowpack_jan <- snow.init
    for (ii in 1:length(years)) {
      zzz <- data.frame(series[series$year == years[ii], ])
      zzz <- data.frame(zzz$P, (zzz$Tn + zzz$Tx)/2, zzz$Tn, zzz$Tx)
      names(zzz) <- c("Prec1", "Tmean1", "Tn1", "Tx1")
      if (!is.null(clim_norm)) {
        zzz$Prec1[is.na(zzz$Prec1)] <- clim_norm$P[is.na(zzz$Prec1)]
        zzz$Tmean1[is.na(zzz$Tmean1)] <- clim_norm$Tm[is.na(zzz$Tmean1)]
        zzz$Tn1[is.na(zzz$Tn1)] <- clim_norm$Tn[is.na(zzz$Tn1)]
        zzz$Tx1[is.na(zzz$Tx1)] <- clim_norm$Tx[is.na(zzz$Tx1)]
      }
      if (sum(is.na(zzz$Prec1)) != 0 | sum(is.na(zzz$Tmean1)) != 
          0) 
        print(paste("Monthly values missing in year", first.yr + 
                      ii - 1), quote = FALSE)
      else {
        Prec <- zzz[, 1]
        Tmean <- zzz[, 2]
        Tn <- zzz[, 3]
        Tx <- zzz[, 4]
        Storage <- rep(TAW, length(Tmean))
        Percola <- rep(0, length(Tmean))
        TmeanCor <- Tmean
        TmeanCor[TmeanCor < 0] <- 0
        ITM <- ((TmeanCor/5)^1.514)
        ITA <- sum(ITM)
        exp <- 6.75e-07 * ITA^3 - 7.71e-05 * ITA^2 + 0.01792 * 
          ITA + 0.492
        PET <- (16 * (10 * TmeanCor/ITA)^exp) * rel_daylength
        SnowAcc <- rep(0, 12)
        SnowPrec <- Prec
        SnowPrec[Tmean >= Tsnow] <- 0
        month_max <- max(min(which(Tmean >= Tsnow) - 1), 
                         1)
        SnowAcc_wint <- NULL
        for (i in 1:month_max) {
          if (i == 1) 
            SnowAcc_wint[i] <- snowpack_jan + SnowPrec[i] * 
              fr.sn.acc
          else SnowAcc_wint[i] <- SnowAcc_wint[i - 1] + 
              SnowPrec[i] * fr.sn.acc
        }
        snowpack_ref <- SnowAcc_wint[month_max]
        snow_depl <- NULL
        SnowAcc[1] <- SnowAcc_wint[1]
        snow_depl[1] <- SnowPrec[1] * (1 - fr.sn.acc)
        if (Tmean[1] >= Tsnow) {
          snow_depl[1] <- snow_melt_coeff[1] * SnowAcc[1]
          SnowAcc[1] <- SnowAcc[1] - snow_depl[1]
        }
        count_thaw <- 0
        for (i in 2:12) {
          snow_depl[i] <- SnowPrec[i] * (1 - fr.sn.acc)
          SnowAcc[i] <- SnowAcc[i - 1] + SnowPrec[i] * 
            fr.sn.acc
          if (Tmean[i] >= Tsnow) {
            count_thaw <- count_thaw + 1
            if (count_thaw > length(snow_melt_coeff)) {
              snow_depl[i] <- SnowAcc[i]
            }
            else snow_depl[i] <- snow_depl[i] + SnowAcc[i] * 
                snow_melt_coeff[count_thaw]
          }
          SnowAcc[i] <- SnowAcc[i] - snow_depl[i]
        } 
        
        snowpack_jan <- SnowAcc[12]
        Liq_Prec <- Prec
        Liq_Prec[Tmean < Tsnow] <- Prec[Tmean < Tsnow] * 
          (1 - fr.sn.acc)
        P.minus.ET <- Liq_Prec + snow_depl - PET
        if (ii == 1) 
          last_Storage <- TAW
        if (!is.na(P.minus.ET[1]) & P.minus.ET[1] > 0) {
          Storage[1] <- last_Storage + P.minus.ET[1]
          if (Storage[1] > TAW) {
            Percola[1] <- Storage[1] - TAW
            Storage[1] <- TAW
          }
        }
        else {
          PETvir <- (log10(TAW) - log10(last_Storage))/fTAW
          Storage[1] <- TAW * 10^(-(PETvir + P.minus.ET[1]) * 
                                    fTAW)
        }
        for (i in 2:length(Storage)) {
          if (!is.na(P.minus.ET[i]) & P.minus.ET[i] > 0) {
            Storage[i] <- Storage[i - 1] + P.minus.ET[i]
            if (Storage[i] > TAW) {
              Percola[i] <- Storage[i] - TAW
              Storage[i] <- TAW
            }
          }
          else {
            PETvir <- (log10(TAW) - log10(Storage[i - 1]))/fTAW
            Storage[i] <- TAW * 10^(-(PETvir + P.minus.ET[i]) * 
                                      fTAW)
          }
        }
        last_Storage <- Storage[12]
        delta.sto <- c(0, diff(Storage))
        ETr <- (Liq_Prec + snow_depl - delta.sto)
        for (i in 1:length(ETr)) {
          if (P.minus.ET[i] > 0) 
            ETr[i] <- PET[i]
        }
        Def <- PET - ETr
        Def[Def < 0] <- 0
        Sur <- Liq_Prec + snow_depl - ETr - (TAW - Storage)
        Sur[Sur < 0] <- 0
        tPrec <- data.frame(tPrec, Prec)
        tET0 <- data.frame(tET0, PET)
        tStor <- data.frame(tStor, Storage)
        tPmE <- data.frame(tPmE, P.minus.ET)
        tDef <- data.frame(tDef, Def)
        tSur <- data.frame(tSur, Sur)
        tPack<- data.frame(tPack, SnowAcc)
        
      }
    }
    names(tPrec) <- c("Month", years)
    row.names(tPrec) <- month_names
    names(tET0) <- c("Month", years)
    row.names(tET0) <- month_names
    names(tStor) <- c("Month", years)
    row.names(tStor) <- month_names
    names(tPmE) <- c("Month", years)
    row.names(tPmE) <- month_names
    names(tDef) <- c("Month", years)
    row.names(tDef) <- month_names
    names(tSur) <- c("Month", years)
    row.names(tSur) <- month_names
    names(tPack) <- c("Month", years)
    row.names(tPack) <- month_names
    list_thornt <- list(round(tPrec[-1], 1), round(tET0[-1], 
                                                   1), round(tStor[-1], 1), round(tPmE[-1], 1), round(tDef[-1], 
                                                                                                      1), round(tSur[-1], 1),round(tPack[-1],1))
    names(list_thornt) <- c("Precipitation", "Et0", "Storage", 
                            "Prec. - Evap.", "Deficit", "Surplus","Pack")
    qPrec <- data.frame(quant)
    qET0 <- data.frame(quant)
    qStor <- data.frame(quant)
    qPmE <- data.frame(quant)
    qDef <- data.frame(quant)
    qSur <- data.frame(quant)
    ttPrec <- t(tPrec)
    ttET0 <- t(tET0)
    ttStor <- t(tStor)
    ttPmE <- t(tPmE)
    ttDef <- t(tDef)
    ttSur <- t(tSur)
    qPrec <- as.data.frame(apply(ttPrec[-1, ], FUN = quantile, 
                                 probs = quant, na.rm = T, MARGIN = 2))
    names(qPrec) <- month_names
    qET0 <- as.data.frame(apply(ttET0[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qET0) <- month_names
    qStor <- as.data.frame(apply(ttStor[-1, ], FUN = quantile, 
                                 probs = quant, na.rm = T, MARGIN = 2))
    names(qStor) <- month_names
    qPmE <- as.data.frame(apply(ttPmE[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qPmE) <- month_names
    qDef <- as.data.frame(apply(ttDef[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qDef) <- month_names
    qSur <- as.data.frame(apply(ttSur[-1, ], FUN = quantile, 
                                probs = quant, na.rm = T, MARGIN = 2))
    names(qSur) <- month_names
    list_quant <- list(round(qPrec, 1), round(qET0, 1), round(qStor, 
                                                              1), round(qPmE, 1), round(qDef, 1), round(qSur, 1),tPack)
    names(list_quant) <- names(list_thornt)
    list_2.lists <- list(W_balance = list_thornt, quantiles = list_quant)
    class(list_2.lists) <- "thornthwaite"
    return(list_2.lists)
  }
  
  ##################################################             MAKE DATAFRAMES              #############################################-
  {
    WFDP_clim_norm<-read.csv(file='./DATA/Climate/NEX PRISM 800-m/PRISM_800m_1981-2010normals.csv'); 
    WFDP_clim_norm<-cbind(x=c(1:13),WFDP_clim_norm)
    WFDP_clim_norm<-WFDP_clim_norm[1:12,];
    WFDP_norms<-cbind(WFDP_clim_norm[,3:6]);colnames(WFDP_norms)[1:4]<-c("P","Tn","Tx","Tm")
    WFDP_monthly<-read.csv(file='./DATA/Climate/NEX PRISM 800-m/PRISM_800m_2010-2019_monthly_forThornthwaite.csv')
    }
  
  ##################################################                RUN MODELS              #############################################-
  {
    WFDP_WB<-thornthwaite(series=WFDP_monthly,latitude=45.8197,clim_norm=WFDP_norms,TAW=120,Tsnow=0,snow_melt_coeff=c(0.8,0.8))
    
    WFDP_yearly_deficit<-data.frame("year"=c(2010:2019),"deficit"=NA)
    for(i in 2010:2019){
      WFDP_yearly_deficit[WFDP_yearly_deficit$year==i,2]<-sum(WFDP_WB$W_balance$Deficit[,colnames(WFDP_WB$W_balance$Deficit)==i])}

    WFDP_yearly_snowppack<-data.frame("year"=c(2010:2019),"snowppack"=NA)
    for(i in 2010:2019){
      WFDP_yearly_snowppack[WFDP_yearly_snowppack$year==i,2]<-max(WFDP_WB$W_balance$Pack[,colnames(WFDP_WB$W_balance$Pack)==i])}

    def.snow<-merge(WFDP_yearly_deficit,WFDP_yearly_snowppack,by='year')
    
    save(def.snow,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr",format(Sys.time(),'%Y%m%d'),sep=''))
  }  
} else 
  if (RUN.PRISM.SUMMARY==T) {
    
    PRISM<-read.csv("./DATA/Climate/NEX PRISM 800-m/PRISM_800m_2010-2019_monthly.csv",na.strings='NULL')
    
    WFDP_yearly_deficit<-data.frame("year"=c(2010:2019),"deficit"=NA)
    for(i in 2010:2019){WFDP_yearly_deficit[WFDP_yearly_deficit$year==i,2]<-sum(PRISM[PRISM$year==i,'deficit'])}
    
    WFDP_yearly_snowppack<-data.frame("year"=c(2010:2019),"snowppack"=NA)
    for(i in 2010:2019){WFDP_yearly_snowppack[WFDP_yearly_snowppack$year==i,2]<-max(PRISM[(PRISM$year==i&PRISM$month<=7)|(PRISM$year==(i-1)&PRISM$month>7),'snow'])}
    
    def.snow<-merge(WFDP_yearly_deficit,WFDP_yearly_snowppack,by='year')
    
    save(def.snow,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    } else load("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_20200310")

colnames(def.snow)[1]<-'CENSUS'
def.snow$deflag1<-def.snow[c(nrow(def.snow),1:(nrow(def.snow)-1)),'deficit']
def.snow<-def.snow[def.snow$CENSUS>2011,]


# ## before centering, look at variability
# def.snow2<-def.snow[def.snow$CENSUS!=2016 & def.snow$CENSUS!=2019,]
# summary(with(def.snow2,lm(deflag1~snowppack)))
# summary(with(def.snow,lm(deflag1~snowppack)))
# Pval <- paste('== ','0.43',sep='')
# R2 <- paste('== ','0.11',sep='')
# 
# ggplot(data = def.snow, aes(snowppack,deflag1)) + theme_prefs +
#   geom_smooth(method = lm) +
#   geom_point() +
#   scale_x_continuous(name=expression(paste("Annual Snowpack (mm ",H[2],"O)",sep=''),parse=T))+
#   scale_y_continuous(name=expression(paste("Annual Deficit (mm ",H[2],"O)",sep=''),parse=T))+
#   annotate("text", x=50,y=300, label = paste("italic(P)", Pval), parse = TRUE, size=3) +
#   annotate("text", x=50,y=280, label = paste("italic(R)^2", R2), parse = TRUE, size=3) +
#   geom_text(aes(label=CENSUS),hjust=(-0.2), vjust=(-0.7), size=3) +
#   coord_cartesian(ylim=c(0,300),xlim=c(0,520))
# 
# dev.print(file=paste('./Papers/FigS7','.tif',sep=''),tiff,width=4,height=4,res=600,units='in',compression='lzw')
# #############-

def.snow[2:4]<-apply(def.snow[2:4],2,FUN= function(x){x-mean(x)}) #center variables


##############################################################################################################################################

##############################################################################################################################################-
#########################################                COX REGRESSION - AGENT GENERIC              #########################################-
#---------------------------------------------------------------------------------------------------------------------------------------------


  ##################################################             MAKE DATAFRAMES              #############################################-
  {
    #create data
    
  timeframe<-2020-2012
  tree.cox<-live.tree[,c('STEM_TAG','SPECIES','CENSUS','MORT_DATE','IN_YR','BIOMASS_DBH','DBH_BIN','DA','conifer',neighbor.predictors)]
  tree.cox<-do.call("rbind", replicate(timeframe, tree.cox, simplify = FALSE))
  tree.cox<-tree.cox[order(tree.cox$STEM_TAG),]
  nrows<-nrow(tree.cox)
  tree.cox$CENSUS<-rep(paste(2012:2019),(nrows/timeframe))
  tree.cox<-merge(tree.cox,def.snow,by='CENSUS')
  tree.cox<-tree.cox[order(tree.cox$STEM_TAG),]
  
  #remove trees from earlier censuses that were ingrowth later on
  tree.cox<-tree.cox[(is.na(tree.cox$IN_YR)==F&tree.cox$CENSUS>=tree.cox$IN_YR)|is.na(tree.cox$IN_YR)==T,]
  
  #set DA to change to dead in year that tree died, then remove subsequent years for dead trees
  tree.cox$DA<-0
  tree.cox[is.na(tree.cox$MORT_DATE)==F&tree.cox$CENSUS>=tree.cox$MORT_DATE,'DA']<-1
  tree.cox<-tree.cox[(is.na(tree.cox$MORT_DATE)==F&tree.cox$CENSUS<=tree.cox$MORT_DATE)|is.na(tree.cox$MORT_DATE)==T,]
  # test<-live.tree[live.tree$MORT_DATE==2015&is.na(live.tree$MORT_DATE)==F,'STEM_TAG'] #trees that died in 2015
  # tree.cox[tree.cox$STEM_TAG%in%test,] #make sure DA changes on appropriate date and subsequent entries are deleted (once it's dead, it's out of dataset)

  tree.cox[is.na(tree.cox$MORT_DATE)==T,'MORT_DATE']<-90
  tree.cox[tree.cox$MORT_DATE==2011&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-0
  tree.cox[tree.cox$MORT_DATE==2012&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-1
  tree.cox[tree.cox$MORT_DATE==2013&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-2
  tree.cox[tree.cox$MORT_DATE==2014&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-3
  tree.cox[tree.cox$MORT_DATE==2015&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-4
  tree.cox[tree.cox$MORT_DATE==2016&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-5
  tree.cox[tree.cox$MORT_DATE==2017&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-6
  tree.cox[tree.cox$MORT_DATE==2018&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-7
  tree.cox[tree.cox$MORT_DATE==2019&is.na(tree.cox$MORT_DATE)==F,'MORT_DATE']<-8
  
  tree.cox[tree.cox$CENSUS==2011&is.na(tree.cox$CENSUS)==F,'CENSUS']<-0
  tree.cox[tree.cox$CENSUS==2012&is.na(tree.cox$CENSUS)==F,'CENSUS']<-1
  tree.cox[tree.cox$CENSUS==2013&is.na(tree.cox$CENSUS)==F,'CENSUS']<-2
  tree.cox[tree.cox$CENSUS==2014&is.na(tree.cox$CENSUS)==F,'CENSUS']<-3
  tree.cox[tree.cox$CENSUS==2015&is.na(tree.cox$CENSUS)==F,'CENSUS']<-4
  tree.cox[tree.cox$CENSUS==2016&is.na(tree.cox$CENSUS)==F,'CENSUS']<-5
  tree.cox[tree.cox$CENSUS==2017&is.na(tree.cox$CENSUS)==F,'CENSUS']<-6
  tree.cox[tree.cox$CENSUS==2018&is.na(tree.cox$CENSUS)==F,'CENSUS']<-7
  tree.cox[tree.cox$CENSUS==2019&is.na(tree.cox$CENSUS)==F,'CENSUS']<-8
  
  tree.cox$CENSUS<-as.numeric(tree.cox$CENSUS)

  tree.cox[is.na(tree.cox)==T]<-0
  tree.cox[which(tree.cox==Inf)]<-0

  Angiosperm<-tree.cox[tree.cox$conifer!=1,]
  Gymnosperm<-tree.cox[tree.cox$conifer==1,]

  #get data per spp
  for(i in spplist1){
    species<-tree.cox[tree.cox$SPECIES==i,]
    assign(paste(i,'gen',sep='.'),species)
  }
  rm(species)
  
  # save(ABAM.gen,ACCI.gen,PSME.gen,TABR.gen,TSHE.gen,file='./OUTPUT/Cox/Species_dataframes_agentGeneric_noMECH_20200311.Rdata')
  
  }

  ##################################################                RUN MODELS                #############################################-
    
    for(i in spplist1){
    datt<-paste(i,'gen',sep='.')

    temp<-coxph(Surv(time=CENSUS,event=DA)~BIOMASS_DBH+cluster(STEM_TAG)+(deflag1+zscore.Hegyi.het+snowppack+elev.diff)^4+
                  (deflag1+zscore.Hegyi.con+snowppack+elev.diff)^4, data=eval(parse(text=datt)))

    assign(paste(i,'hetcon',sep='.'),temp)

    rm(temp,datt)
  }
    
    save(ABAM.hetcon, PSME.hetcon, TABR.hetcon,TSHE.hetcon, ACCI.hetcon, 
                 file='./OUTPUT/Cox/all_models_hetcon_w2019_wo2011_scaledHegyis_noMECH_20200311.Rdata')
    

  ########### make master table - HR ###########-
  {
    table.6<-data.frame()
  for(i in spplist1){
    model<-eval(parse(text=paste(i,'hetcon',sep='.')))

    for(j in names(model$coefficients)){
      table.6[j,i]<-(exp(model$coefficients[j])-1)*100
    }
    t<-ifelse(summary(model)$coefficients[,6]<0.001,'***',
              ifelse(summary(model)$coefficients[,6]<0.01,'**',
                     ifelse(summary(model)$coefficients[,6]<0.05,'*','')))
    t2<-ifelse(table.6[is.na(table.6[,i])==F,i]<0,"'- ","'+ ")
    t3<-as.character(abs(round(table.6[is.na(table.6[,i])==F,i],2)))
    t3[t3==0]<-'< 0.01'
    table.6[is.na(table.6[,i])==F,i]<-as.character(paste(t2,t3,'% ',t,sep=''))
  }
    table.6$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',rownames(table.6))
    table.6$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',rownames(table.6))
  table.6$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',table.6$`Pretty Names`)
  table.6$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',table.6$`Pretty Names`)
  table.6$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',table.6$`Pretty Names`)
  table.6[order(table.6$`Pretty Names`),]

  save(table.6,file=paste('./OUTPUT/Cox/HetCon.table.HR_w2019_w02011_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),'Rdata',sep='.'))
  # write.csv(x=table.6,file=paste('./OUTPUT/Cox/HetCon.table.HR_w2019_w02011_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),'csv',sep='.'))
  }
 
   ########### make master table - BETAS ###########-
  {
    table.6b<-data.frame()
    for(i in spplist1){
      model<-eval(parse(text=paste(i,'hetcon',sep='.')))
      for(j in names(model$coefficients)){
        table.6b[j,i]<-as.numeric(model$coefficients[j])
      } # remove following section to make BETA table for climate_projections usage, keep for MS table
      t<-ifelse(summary(model)$coefficients[,6]<0.001,'***',
                ifelse(summary(model)$coefficients[,6]<0.01,'**',
                       ifelse(summary(model)$coefficients[,6]<0.05,'*','')))
      t2<-ifelse(table.6b[is.na(table.6b[,i])==F,i]<0,"'- ","'+ ")
      t3<-as.character(abs(round(table.6b[is.na(table.6b[,i])==F,i],3)))
      t3[t3==0]<-paste('t')
      table.6b[is.na(table.6b[,i])==F,i]<-as.character(paste(t2,t3,t,sep=''))

      }
    table.6b$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',rownames(table.6b))
    table.6b$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',table.6b$`Pretty Names`)
    table.6b$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',table.6b$`Pretty Names`)
    table.6b$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',table.6b$`Pretty Names`)
    table.6b$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',table.6b$`Pretty Names`)
    table.6b[order(table.6b$`Pretty Names`),]
    
    # save(table.6b,file=paste('./OUTPUT/Cox/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
    write.csv(x=table.6b,file=paste('./OUTPUT/Cox/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),'csv',sep='.'))
  }
  
##############################################################################################################################################

##############################################################################################################################################-
#################################################              MODEL SUMMARIES              ##################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

#get event and non-event N (do for each spp)
nrow(live.tree[live.tree$SPECIES=='ABAM'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
nrow(live.tree[live.tree$SPECIES=='ABAM'&is.na(live.tree$MORT_DATE)==T,])

nrow(live.tree[live.tree$SPECIES=='PSME'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
nrow(live.tree[live.tree$SPECIES=='PSME'&is.na(live.tree$MORT_DATE)==T,])

nrow(live.tree[live.tree$SPECIES=='TABR'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
nrow(live.tree[live.tree$SPECIES=='TABR'&is.na(live.tree$MORT_DATE)==T,])

nrow(live.tree[live.tree$SPECIES=='TSHE'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
nrow(live.tree[live.tree$SPECIES=='TSHE'&is.na(live.tree$MORT_DATE)==T,])

nrow(live.tree[live.tree$SPECIES=='ACCI'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
nrow(live.tree[live.tree$SPECIES=='ACCI'&is.na(live.tree$MORT_DATE)==T,])

nrow(live.tree[live.tree$SPECIES=='COCOC'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
nrow(live.tree[live.tree$SPECIES=='COCOC'&is.na(live.tree$MORT_DATE)==T,])

nrow(live.tree[live.tree$SPECIES=='VAPA'&is.na(live.tree$MORT_DATE)==F&live.tree$MORT_DATE!=0,])
nrow(live.tree[live.tree$SPECIES=='VAPA'&is.na(live.tree$MORT_DATE)==T,])

#concordances
  species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA')
  concordances<-data.frame('C'=NA)
  for(k in species){
    mod<-eval(parse(text=paste(k,'hetcon',sep='.')))
    concordances[k,'C'] <- mod$concordance['concordant'] / (mod$concordance['concordant'] + mod$concordance['discordant'])
  }
  
  concordances$spp<-rownames(concordances);concordances<-concordances[-1,]

  save(concordances,file='./OUTPUT/Cox/Cox.Models.Concordances.noMECH.20200311.Rdata')
  
##############################################################################################################################################  

 
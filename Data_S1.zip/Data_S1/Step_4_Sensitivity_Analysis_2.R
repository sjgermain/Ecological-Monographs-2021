## Wind River Stability - Survival Analysis ##
## Sensitivity Analysis TWO ##
## Sara Germain ##
## March 2021 ##


setwd("WFDP_Demography_20200303")


LOAD.CLIMATE=T
RUN.PRISM.SUMMARY=F
RUN.BETAS=F
RUN.VAR.SUMMARY=F
RUN.FUNC.CALC=F

##############################################################################################################################################-
############################################################## LIBRARIES AND FUNCTIONS #######################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

library('nlme')
library('grid')
library('ggplot2')
library('gridExtra')
library('cowplot')

right <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

left <- function(x, n){
  substr(x, 1, n)
}

theme_prefs<-theme_classic() + theme(axis.title.x = element_text(size=8),
                                     axis.title.y = element_text(size=8),
                                     axis.text.x = element_text(size=8, colour='black'),
                                     axis.text.y = element_text(size=8, colour='black'),
                                     axis.ticks = element_line(colour='black'),
                                     legend.text = element_text(size=8),
                                     legend.title = element_text(size=8),
                                     plot.title=element_text(size=10,hjust=0.5, vjust=-3))

##############################################################################################################################################

##############################################################################################################################################-
############################################################### CLIMATE PROJECTIONS ##########################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

if(LOAD.CLIMATE==T){
  if (RUN.PRISM.SUMMARY==T){
    
    ## DATA ## 
    {
      historical<-datt<-read.csv("./DATA/Climate/NEX PRISM 800-m/prism_historical_195001-201912.csv",na.strings='NULL')
      datt<-read.csv("./DATA/Climate/NEX PRISM 800-m/HadGEM2-ES_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt1<-read.csv("./DATA/Climate/NEX PRISM 800-m/HadGEM2-CC_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt2<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-CM3_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt3<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-ESM2G_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt4<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-ESM2M_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt5<-read.csv("./DATA/Climate/NEX PRISM 800-m/CCSM4_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      
      historical$year<-as.character(historical$year)
      datt$year<-as.character(datt$year)
      datt1$year<-as.character(datt1$year)
      datt2$year<-as.character(datt2$year)
      datt3$year<-as.character(datt3$year)
      datt4$year<-as.character(datt4$year)
      datt5$year<-as.character(datt5$year)
      
      historical$year<-as.numeric(right(historical$year,4))
      datt$year<-as.numeric(right(datt$year,4))
      datt1$year<-as.numeric(right(datt1$year,4))
      datt2$year<-as.numeric(right(datt2$year,4))
      datt3$year<-as.numeric(right(datt3$year,4))
      datt4$year<-as.numeric(right(datt4$year,4))
      datt5$year<-as.numeric(right(datt5$year,4))
      
      mean.time<-seq(1950,2099,1)
      mean.model.all<- datt1
      mean.model.all[1:nrow(mean.model.all),3:ncol(mean.model.all)]<-NA
      for(i in mean.time){
        for(k in 1:12){
          for(j in colnames(mean.model.all)[3:ncol(mean.model.all)]){
            mean.model.all[mean.model.all$year==i&mean.model.all$month==k,j] <- mean(c(datt[datt$year==i&datt$month==k,colnames(datt)==j],
                                                                                       datt1[datt1$year==i&datt1$month==k,colnames(datt1)==j],
                                                                                       datt2[datt2$year==i&datt2$month==k,colnames(datt2)==j],
                                                                                       datt3[datt3$year==i&datt3$month==k,colnames(datt3)==j],
                                                                                       datt4[datt4$year==i&datt4$month==k,colnames(datt4)==j],
                                                                                       datt5[datt5$year==i&datt5$month==k,colnames(datt5)==j]))
          }
        }
      }
      
      # write.csv(datt[datt$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/hadgem2.es.alldata.csv')
      # write.csv(datt1[datt1$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/hadgem2.cc.alldata.csv')
      # write.csv(datt2[datt2$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/gfdl.cm3.alldata.csv')
      # write.csv(datt3[datt3$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/gfdl.esm2g.alldata.csv')
      # write.csv(datt4[datt4$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/gfdl.esm2m.cc.alldata.csv')
      # write.csv(datt5[datt5$year>2019,],file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/ccsm4.alldata.csv')
      # write.csv(mean.model.all,file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/mean.model.alldata.csv')
      # write.csv(historical,file='./DATA/Climate/NEX PRISM 800-m/Supplement_Tables/historical.alldata.csv')
      
    }
    
    ##########################################################################################################################################################################'
    ################################################################## GET DEFICIT and SNOWPACK PROJECTIONS ##################################################################'
    #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    WFDP_yearly_deficit0<-data.frame("year"=c(1950:2019),"deficit"=NA)
    for(i in 1950:2019){WFDP_yearly_deficit0[WFDP_yearly_deficit0$year==i,2]<-sum(historical[historical$year==i,'deficit'])}
    WFDP_yearly_snowppack0<-data.frame("year"=c(1950:2019),"snowppack"=NA)
    for(i in 1950:2019){WFDP_yearly_snowppack0[WFDP_yearly_snowppack0$year==i,2]<-max(historical[(historical$year==i&historical$month<=7)|(historical$year==(i-1)&historical$month>7),'snow'])}
    hist.defsnow<-merge(WFDP_yearly_deficit0,WFDP_yearly_snowppack0,by='year')
    save(hist.defsnow,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_HISTORICAL_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit[WFDP_yearly_deficit$year==i,2]<-sum(datt[datt$year==i,'deficit'])}
    WFDP_yearly_snowppack<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack[WFDP_yearly_snowppack$year==i,2]<-max(datt[(datt$year==i&datt$month<=7)|(datt$year==(i-1)&datt$month>7),'snow'])}
    hadgem2.es<-merge(WFDP_yearly_deficit,WFDP_yearly_snowppack,by='year')
    hadgem2.es<-hadgem2.es[hadgem2.es$year>2019,]
    save(hadgem2.es,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-ES_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit1<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit1[WFDP_yearly_deficit1$year==i,2]<-sum(datt1[datt1$year==i,'deficit'])}
    WFDP_yearly_snowppack1<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack1[WFDP_yearly_snowppack1$year==i,2]<-max(datt1[(datt1$year==i&datt1$month<=7)|(datt1$year==(i-1)&datt1$month>7),'snow'])}
    hadgem2.cc<-merge(WFDP_yearly_deficit1,WFDP_yearly_snowppack1,by='year')
    hadgem2.cc<-hadgem2.cc[hadgem2.cc$year>2019,]
    save(hadgem2.cc,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-CC_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit2<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit2[WFDP_yearly_deficit2$year==i,2]<-sum(datt2[datt2$year==i,'deficit'])}
    WFDP_yearly_snowppack2<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack2[WFDP_yearly_snowppack2$year==i,2]<-max(datt2[(datt2$year==i&datt2$month<=7)|(datt2$year==(i-1)&datt2$month>7),'snow'])}
    gfdl.cm3<-merge(WFDP_yearly_deficit2,WFDP_yearly_snowppack2,by='year')
    gfdl.cm3<-gfdl.cm3[gfdl.cm3$year>2019,]
    save(gfdl.cm3,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-CM3_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit3<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit3[WFDP_yearly_deficit3$year==i,2]<-sum(datt3[datt3$year==i,'deficit'])}
    WFDP_yearly_snowppack3<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack3[WFDP_yearly_snowppack3$year==i,2]<-max(datt3[(datt3$year==i&datt3$month<=7)|(datt3$year==(i-1)&datt3$month>7),'snow'])}
    gfdl.esm2g<-merge(WFDP_yearly_deficit3,WFDP_yearly_snowppack3,by='year')
    gfdl.esm2g<-gfdl.esm2g[gfdl.esm2g$year>2019,]
    save(gfdl.esm2g,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2G_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit4<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit4[WFDP_yearly_deficit4$year==i,2]<-sum(datt4[datt4$year==i,'deficit'])}
    WFDP_yearly_snowppack4<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack4[WFDP_yearly_snowppack4$year==i,2]<-max(datt4[(datt4$year==i&datt4$month<=7)|(datt4$year==(i-1)&datt4$month>7),'snow'])}
    gfdl.esm2m<-merge(WFDP_yearly_deficit4,WFDP_yearly_snowppack4,by='year')
    gfdl.esm2m<-gfdl.esm2m[gfdl.esm2m$year>2019,]
    save(gfdl.esm2m,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2M_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit5<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit5[WFDP_yearly_deficit5$year==i,2]<-sum(datt5[datt5$year==i,'deficit'])}
    WFDP_yearly_snowppack5<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack5[WFDP_yearly_snowppack5$year==i,2]<-max(datt5[(datt5$year==i&datt5$month<=7)|(datt5$year==(i-1)&datt5$month>7),'snow'])}
    ccsm4<-merge(WFDP_yearly_deficit5,WFDP_yearly_snowppack5,by='year')
    ccsm4<-ccsm4[ccsm4$year>2019,]
    save(ccsm4,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_CCSM4_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    mean.time<-seq(2020,2099,1)
    mean.model<- data.frame('year'=seq(2020,2099,1),'deficit'=NA,'snowppack'=NA)
    for(i in mean.time){
      mean.model[mean.model$year==i,'deficit'] <- mean(c(hadgem2.cc[hadgem2.cc$year==i,'deficit'],
                                                         hadgem2.es[hadgem2.es$year==i,'deficit'],
                                                         gfdl.cm3[gfdl.cm3$year==i,'deficit'],
                                                         gfdl.esm2g[gfdl.esm2g$year==i,'deficit'],
                                                         gfdl.esm2m[gfdl.esm2m$year==i,'deficit'],
                                                         ccsm4[ccsm4$year==i,'deficit']))
      mean.model[mean.model$year==i,'snowppack'] <- mean(c(hadgem2.cc[hadgem2.cc$year==i,'snowppack'],
                                                           hadgem2.es[hadgem2.es$year==i,'snowppack'],
                                                           gfdl.cm3[gfdl.cm3$year==i,'snowppack'],
                                                           gfdl.esm2g[gfdl.esm2g$year==i,'snowppack'],
                                                           gfdl.esm2m[gfdl.esm2m$year==i,'snowppack'],
                                                           ccsm4[ccsm4$year==i,'snowppack']))
    }
    
    save(mean.model,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_MEANMODEL_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    
    mean.full.model <- rbind(hist.defsnow,mean.model)
    save(mean.full.model,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    #create lagged deficit -------------------------------------------------------------
    models<-c('ccsm4','gfdl.cm3','gfdl.esm2g','gfdl.esm2m','hadgem2.cc','hadgem2.es','mean.model')
    
    for (i in models){
      model<-eval(parse(text=i))
      combined<-rbind(hist.defsnow,model)
      for (j in 2:nrow(combined)){
        combined[j,'deflag1'] <- combined[j-1,'deficit']
        assign(paste(i,'lag',sep='.'),combined)
      }
    }
    
    colnames(mean.model.lag)[3]<-'snow'
    colnames(mean.model.lag)[4]<-'Deficit'
    colnames(ccsm4.lag)[3]<-'snow'
    colnames(ccsm4.lag)[4]<-'Deficit'
    colnames(gfdl.cm3.lag)[3]<-'snow'
    colnames(gfdl.cm3.lag)[4]<-'Deficit'
    colnames(gfdl.esm2g.lag)[3]<-'snow'
    colnames(gfdl.esm2g.lag)[4]<-'Deficit'
    colnames(gfdl.esm2m.lag)[3]<-'snow'
    colnames(gfdl.esm2m.lag)[4]<-'Deficit'
    colnames(hadgem2.cc.lag)[3]<-'snow'
    colnames(hadgem2.cc.lag)[4]<-'Deficit'
    colnames(hadgem2.es.lag)[3]<-'snow'
    colnames(hadgem2.es.lag)[4]<-'Deficit'
    
    save(mean.model.lag,ccsm4.lag,gfdl.cm3.lag,gfdl.esm2g.lag,gfdl.esm2m.lag,hadgem2.cc.lag,hadgem2.es.lag,
         file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_lagged.def_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    #########################################################################################################################################################################
    #################################################################### SUMMARIZE DEFICIT AND SNOWPACK #####################################################################'
    #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    future.def<-summary(mean.model[mean.model$year>2060&mean.model$year<2070,'deficit'])
    
    future.snow<-summary(mean.model[mean.model$year>2060&mean.model$year<2070,'snowppack'])
    
    past.def<-summary(hist.defsnow[hist.defsnow$year>2010&hist.defsnow$year<2020,'deficit'])
    
    past.snow<-summary(hist.defsnow[hist.defsnow$year>2010&hist.defsnow$year<2020,'snowppack'])
    
    #####################################################################################################################################################################
    
    
  } else c(load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_CCSM4_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-CM3_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2G_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2M_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-CC_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-ES_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_HISTORICAL_PRISM_method_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_MEANMODEL_PRISM_method_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_PRISM_method_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_lagged.def_PRISM_method_20200310'))
}

##############################################################################################################################################

##############################################################################################################################################-
######################################################## 3 STEPS - PROJECT HAZARD FORWARD ####################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

#STEP 1 - GET ALL SIGNIFICANT BETAS
if (RUN.BETAS==T){
  
  load('./OUTPUT/Cox/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH.20200311.Rdata')
  load('./OUTPUT/Cox/HetCon.table.HR_w2019_w02011_scaledHegyis_noMECH.20200311.Rdata')
  
  tables = c('table.6')
  species=c('ABAM','PSME','TABR','TSHE','ACCI')
  speciesb=c('ABAMb','PSMEb','TABRb','TSHEb','ACCIb')
  predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con')
  
  for(i in tables){
    #make data
    hr<-eval(parse(text=i))
    beta<-eval(parse(text=paste(i,'b',sep='')))
    colnames(beta)[1:length(beta)]<-paste(colnames(beta),'b',sep='')
    merged<-cbind(hr,beta)
    
    for(j in 1:nrow(merged)){
      for (k in colnames(hr)){  
        #get all significant betas
        sig.hr<-grep(pattern="*", merged[,k], value=TRUE, fixed=TRUE) 
        sig.betas<-as.numeric(merged[merged[,k]%in%sig.hr,paste(k,'b',sep='')]) 
        name<-merged[merged[,k]%in%sig.hr,ncol(merged)]
        fin<-data.frame('predictor' = name, 'beta' = sig.betas, 'hr' = sig.hr)
        
        for(m in predictors){
          #get significant betas per predictor of interest
          pred<-grep(pattern=parse(text=m), fin$predictor, value=TRUE) 
          pred.beta<-as.numeric(fin[fin$predictor%in%pred,'beta']) 
          finale<-data.frame('predictor' = pred, 'beta' = pred.beta)
          finale$predictor<-as.character(finale$predictor)
          
          #get non-significant betas for lower-order interaction terms of significant higher-order interactions
          add.cum<-c()
          for(p in finale$predictor){
            pieces <- unlist(strsplit(p,':',fixed=TRUE)) #all components of interaction
            
            if (length(pieces) >= 3) {
              bivar<-as.vector(outer(pieces, pieces, paste, sep=":")) #all possible combos of components
              trivar<-as.vector(outer(bivar, pieces, paste, sep=":"))
              add<-c(bivar, trivar) 
              add.cum<-c(add.cum,add)
            }
            
            addition<-grep(pattern=parse(text=m), add.cum, value=TRUE)
            addition<-c(addition,m)
            newname<-beta[(!beta$`Pretty Names`%in%finale$predictor)&beta$`Pretty Names`%in%addition,ncol(beta)]
            newbeta<-beta[(!beta$`Pretty Names`%in%finale$predictor)&beta$`Pretty Names`%in%addition,paste(k,'b',sep='')]
            newfin<-data.frame('predictor' = newname, 'beta' = newbeta)
            
            total.finale<-rbind(finale,newfin)
            assign(paste(i,k,m,sep='.'),total.finale)
            print(paste(i,k,m))
            
          }
        }
      }
    }
  }
  
  rm(beta)
  rm(fin)
  rm(finale)
  rm(hr)
  rm(merged)
  rm(newfin)
  rm(total.finale)
  
  save.image(file=paste('./OUTPUT/Cox/Project.HR.model.BetaTables_w2019_wo2011_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
  
  
  
} else {load('./OUTPUT/Cox/Project.HR.model.BetaTables_w2019_wo2011_scaledHegyis_noMECH.20200312.Rdata')}

#STEP 2 - DEFINE MIN and MAX for PREDICTORS
if (RUN.VAR.SUMMARY==T){
  
  
  load('./OUTPUT/Cox/Species_dataframes_agentGeneric_noMECH_20200311.Rdata')
  load("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_20200310")
  colnames(def.snow)[1]<-'CENSUS'
  def.snow$deflag1<-def.snow[c(nrow(def.snow),1:(nrow(def.snow)-1)),'deficit']
  def.snow<-def.snow[def.snow$CENSUS>2011,]
  def.snow[2:4]<-apply(def.snow[2:4],2,FUN= function(x){x-mean(x)}) #center variables
  
  variables<-c('elev.diff','zscore.Hegyi.con','zscore.Hegyi.het')
  Variable.Summaries<-c()
  species=c('ABAM','PSME','TABR','TSHE','ACCI')
  
  for (i in paste(species,'gen',sep='.')){
    for (j in variables){
      model<-eval(parse(text=i))
      datt<-data.frame('Species'=paste(i),'Variable'=paste(j),'min'= ifelse(min(model[,j])<=(mean(model[,j])-(2*sd(model[,j]))),(mean(model[,j])-(2*sd(model[,j]))),min(model[,j])),
                       'mean'=mean(model[,j]),'max'=ifelse(max(model[,j])>=(mean(model[,j])+(2*sd(model[,j]))),(mean(model[,j])+(2*sd(model[,j]))),min(model[,j])))
      Variable.Summaries<-rbind(Variable.Summaries,datt)
    }
  }
  for (i in paste(species,'gen',sep='.')){
    blat<-data.frame('Species'=paste(i),'Variable'=c('snowppack','deflag1'),'min'=c(min(def.snow$snowppack),min(def.snow$deflag1)),
                     'mean'=c(0,0),'max'=c(max(def.snow$snowppack),max(def.snow$deflag1)))
    Variable.Summaries<-rbind(Variable.Summaries,blat)
  }
  Variable.Summaries<-Variable.Summaries[order(Variable.Summaries$Species,Variable.Summaries$Variable),]
  
  Variable.Summaries$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',Variable.Summaries$Variable)
  Variable.Summaries$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',Variable.Summaries$`Pretty Names`)
  Variable.Summaries$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',Variable.Summaries$`Pretty Names`)
  Variable.Summaries$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',Variable.Summaries$`Pretty Names`)
  Variable.Summaries$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',Variable.Summaries$`Pretty Names`)
  
  save(Variable.Summaries,file=paste('./OUTPUT/Cox/Project.HR.model.VariableSummaries_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
  
} else {load('./OUTPUT/Cox/Project.HR.model.VariableSummaries_scaledHegyis_noMECH.20200312.Rdata')}

#STEP 3 - CREATE HAZARD RATIO FUNCTIONS
if (RUN.FUNC.CALC==T){
  
  hazard.calc<-function(units=1,snow.value='mean',watertable.value='mean',richness.value='mean',Deficit.value='mean',Hegyi.het.value='mean',
                        Hegyi.con.value='mean',N.value='mean',P.value='mean',TEB.value='mean',
                        species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                        predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                        tables=c('table.6')){
    HR<-data.frame()
    
    for(k in species){
      for(j in predictors){ 
        if (exists(paste(tables,k,j,sep='.'))){
          mod<-eval(parse(text=paste(tables,k,j,sep='.')))
          rownames(mod)<-mod$predictor
          
          all.pred<-unlist(strsplit(mod$predictor,':',fixed=TRUE))
          all.pred<-unique(all.pred[all.pred!=j])
          
          beta.i<-mod[mod$predictor==j,'beta']
          
          #separate all interactions into component pieces
          if (nrow(mod)>1){
            for(m in mod$predictor){
              bn<-unlist(strsplit(m,':',fixed=TRUE))
              bn<-bn[bn!=j]
              for(o in bn){
                vn<-Variable.Summaries[Variable.Summaries$Species==paste(k,'gen',sep='.')&
                                         Variable.Summaries$`Pretty Names`==o,eval(parse(text=paste(o,'value',sep='.')))] #get min, mean, or max value
                mod[m,paste(o,eval(parse(text=paste(o,'value',sep='.'))),'vn',sep='.')]<-vn
              }
            }
            #multiply interaction beta by value of components
            for(m in mod$predictor){
              mod[m,'multiplier']<-apply(mod[m,!colnames(mod)%in%c('multiplier','predictor')],1,prod,na.rm=T) 
              mod[mod$predictor==j,'multiplier']<-0
            }
            sum.multiplier<-sum(mod$multiplier,na.rm=T)
          } else sum.multiplier=0
          
          HR[paste(k,j,sep='.'),'HR']<-exp(units*(beta.i+sum.multiplier))
        }
      }
    }
    return(HR)
  }
  
  hazard.calc.continuous<-function(units=1,watertable.value='mean',richness.value='mean',Hegyi.het.value='mean',
                                   Hegyi.con.value='mean',N.value='mean',P.value='mean',TEB.value='mean',
                                   species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                                   predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                                   tables=c('table.6'),climate.model=mean.model.lag){
    
    #center in same way as parameterized variables
    centered<-climate.model[-1,]
    defx <- mean(centered[centered$year<2020&centered$year>2011,'Deficit'])
    snowx <- mean(centered[centered$year<2020&centered$year>2011,'snow'])
    centered[4]<-apply(centered[4],2,function(x) x-defx)
    centered[3]<-apply(centered[3],2,function(x) x-snowx)
    
    HR.continuous<-data.frame()
    sum.multiplier.continuous<-data.frame('year'=1951:2099,'sum'=NA)
    years<-c(1951:2099)
    
    for(k in species){
      for(j in predictors){ 
        if (exists(paste(tables,k,j,sep='.'))){
          for (a in years){
            mod.continuous<-eval(parse(text=paste(tables,k,j,sep='.')))
            rownames(mod.continuous)<-mod.continuous$predictor
            
            all.pred.continuous<-unlist(strsplit(mod.continuous$predictor,':',fixed=TRUE))
            all.pred.continuous<-unique(all.pred.continuous[all.pred.continuous!=j])
            
            beta.i.continuous<-mod.continuous[mod.continuous$predictor==j,'beta']
            
            #separate all interactions into component pieces
            if(length(grep('Deficit',all.pred.continuous,value=TRUE,fixed=TRUE)>0)|length(grep('snow',all.pred.continuous,value=TRUE,fixed=TRUE)>0)){
              if (nrow(mod.continuous)>1){
                
                for(m in mod.continuous$predictor){
                  if(m != j){
                    bn.continuous<-unlist(strsplit(m,':',fixed=TRUE))
                    bn.continuous<-bn.continuous[bn.continuous!=j]
                    
                    for(o in bn.continuous){
                      if(o %in% c('Deficit','snow')){
                        vn.continuous<-as.numeric(centered[centered$year==a,o])
                        mod.continuous[m,paste(o,a,'vn',sep='.')]<-vn.continuous
                      } else {
                        vn.continuous<-Variable.Summaries[Variable.Summaries$Species==paste(k,'gen',sep='.')&Variable.Summaries$`Pretty Names`==o,eval(parse(text=paste(o,'value',sep='.')))]
                        mod.continuous[m,paste(o,eval(parse(text=paste(o,'value',sep='.'))),'vn',sep='.')]<-vn.continuous
                        print(paste(a," - ",k,".",o,sep = ''))
                      }
                    }
                    
                    #multiply interaction beta by value of components
                    mod.continuous[m,'multiplier']<-apply(mod.continuous[m,!colnames(mod.continuous)%in%c('multiplier','predictor')],1,prod,na.rm=T) 
                  }
                  
                  mod.continuous[mod.continuous$predictor==j,'multiplier']<-0
                }
                
                sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-sum(mod.continuous$multiplier,na.rm=T)
              } else sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0
              
              if(j == 'Deficit'){
                units = as.numeric(centered[centered$year==a,'Deficit'])
              } else if (j == 'snow'){
                units = as.numeric(centered[centered$year==a,'snow'])
              } else '' 
              
              HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']))
              HR.continuous[paste(k,j,a,sep='.'),'year']<-a
              
            } else {sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0; # 3 new lines here deal with non-climate-interacting predictors
            HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']));
            HR.continuous[paste(k,j,a,sep='.'),'year']<-a}
          }
        }
      }
    }
    return(HR.continuous)
  }
  
  hazard.combos<-function(units=1,possibilities=c('min','mean','max'),
                          species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                          predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                          tables=c('table.6')){
    
    HR<-data.frame('mean.values'=hazard.calc())
    
    for(k in species){
      for(j in predictors){
        args<-list()
        
        if (exists(paste(tables,k,j,sep='.'))){
          mod.combo<-eval(parse(text=paste(tables,k,j,sep='.')))
          rownames(mod.combo)<-mod.combo$predictor
          
          if(nrow(mod.combo)>1){
            pred<-unlist(strsplit(mod.combo$predictor,':',fixed=TRUE))
            pred<-unique(pred[pred!=j])
            names(pred)<-rep(paste(k,j,sep='.'),length(pred))
            
            #run function through all possible combinations of predictors
            if(length(pred)==1){
              for(b in pred[1]){
                for(c in possibilities){
                  args[[paste(b,'.value',sep='')]]<-c
                  args[[paste('species')]]<-k
                  args[[paste('predictors')]]<-j
                  args[[paste('units')]]<-units
                  
                  HR[rownames(HR)==paste(k,j,sep='.'),paste(b,c,sep='.')]<-do.call(hazard.calc,args)$HR
                }
              }
              
            } else if(length(pred)==2){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      if(b != d){
                        print(paste(d,e,sep = '.'))
                        args[[paste(b,'.value',sep='')]]<-c
                        args[[paste(d,'.value',sep='')]]<-e
                        args[[paste('species')]]<-k
                        args[[paste('predictors')]]<-j
                        args[[paste('units')]]<-units
                        
                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==3){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          if(b != d & d != f){
                            print(paste(f,g,sep = '.'))
                            args[[paste(b,'.value',sep='')]]<-c
                            args[[paste(d,'.value',sep='')]]<-e
                            args[[paste(f,'.value',sep='')]]<-g
                            args[[paste('species')]]<-k
                            args[[paste('predictors')]]<-j
                            args[[paste('units')]]<-units
                            
                            HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==4){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              if(b != d & d != f & f != h){
                                print(paste(h,i,sep = '.'))
                                args[[paste(b,'.value',sep='')]]<-c
                                args[[paste(d,'.value',sep='')]]<-e
                                args[[paste(f,'.value',sep='')]]<-g
                                args[[paste(h,'.value',sep='')]]<-i
                                args[[paste('species')]]<-k
                                args[[paste('predictors')]]<-j
                                args[[paste('units')]]<-units
                                
                                HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==5){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  if(b != d & d != f & f != h & h != l){
                                    print(paste(l,m,sep = '.'))
                                    args[[paste(b,'.value',sep='')]]<-c
                                    args[[paste(d,'.value',sep='')]]<-e
                                    args[[paste(f,'.value',sep='')]]<-g
                                    args[[paste(h,'.value',sep='')]]<-i
                                    args[[paste(l,'.value',sep='')]]<-m
                                    args[[paste('species')]]<-k
                                    args[[paste('predictors')]]<-j
                                    args[[paste('units')]]<-units
                                    
                                    HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==6){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  for(n in pred[6]){
                                    for(o in possibilities){
                                      if(b != d & d != f & f != h & h != l & l != n){
                                        print(paste(n,o,sep = '.'))
                                        args[[paste(b,'.value',sep='')]]<-c
                                        args[[paste(d,'.value',sep='')]]<-e
                                        args[[paste(f,'.value',sep='')]]<-g
                                        args[[paste(h,'.value',sep='')]]<-i
                                        args[[paste(l,'.value',sep='')]]<-m
                                        args[[paste(n,'.value',sep='')]]<-o
                                        args[[paste('species')]]<-k
                                        args[[paste('predictors')]]<-j
                                        args[[paste('units')]]<-units
                                        
                                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),paste(n,o,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } 
            } else print(paste('ERROR - number interacting variables > 6'))
          }
        }
      }
    } 
    return(HR)
  }
  
  hazard.combos.timestable<-function(units=1,possibilities=c('min','mean','max'),
                                     species=c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),
                                     predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                                     tables=c('table.6')){
    
    HR<-data.frame('mean.values'=hazard.calc())
    
    for(k in species){
      for(j in predictors){
        args<-list()
        
        if (exists(paste(tables,k,j,sep='.'))){
          mod.combo<-eval(parse(text=paste(tables,k,j,sep='.')))
          rownames(mod.combo)<-mod.combo$predictor
          
          if(nrow(mod.combo)>1){
            pred<-unlist(strsplit(mod.combo$predictor,':',fixed=TRUE))
            pred<-unique(pred[pred!=j])
            names(pred)<-rep(paste(k,j,sep='.'),length(pred))
            
            #run function through all possible combinations of predictors
            if(length(pred)==1){
              for(b in pred[1]){
                for(c in possibilities){
                  args[[paste(b,'.value',sep='')]]<-c
                  args[[paste('species')]]<-k
                  args[[paste('predictors')]]<-j
                  args[[paste('units')]]<-units
                  
                  if(is.null(args$snow.value)==F){
                    args$snow.value<-'min'}
                  
                  if(is.null(args$Deficit.value)==F){
                    args$Deficit.value<-'max'}
                  
                  HR[rownames(HR)==paste(k,j,sep='.'),paste(b,c,sep='.')]<-do.call(hazard.calc,args)$HR
                }
              }
              
            } else if(length(pred)==2){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      if(b != d){
                        print(paste(d,e,sep = '.'))
                        args[[paste(b,'.value',sep='')]]<-c
                        args[[paste(d,'.value',sep='')]]<-e
                        args[[paste('species')]]<-k
                        args[[paste('predictors')]]<-j
                        args[[paste('units')]]<-units
                        
                        if(is.null(args$snow.value)==F){
                          args$snow.value<-'min'}
                        
                        if(is.null(args$Deficit.value)==F){
                          args$Deficit.value<-'max'}
                        
                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==3){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          if(b != d & d != f){
                            print(paste(f,g,sep = '.'))
                            args[[paste(b,'.value',sep='')]]<-c
                            args[[paste(d,'.value',sep='')]]<-e
                            args[[paste(f,'.value',sep='')]]<-g
                            args[[paste('species')]]<-k
                            args[[paste('predictors')]]<-j
                            args[[paste('units')]]<-units
                            
                            if(is.null(args$snow.value)==F){
                              args$snow.value<-'min'}
                            
                            if(is.null(args$Deficit.value)==F){
                              args$Deficit.value<-'max'}
                            
                            HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==4){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              if(b != d & d != f & f != h){
                                print(paste(h,i,sep = '.'))
                                args[[paste(b,'.value',sep='')]]<-c
                                args[[paste(d,'.value',sep='')]]<-e
                                args[[paste(f,'.value',sep='')]]<-g
                                args[[paste(h,'.value',sep='')]]<-i
                                args[[paste('species')]]<-k
                                args[[paste('predictors')]]<-j
                                args[[paste('units')]]<-units
                                
                                if(is.null(args$snow.value)==F){
                                  args$snow.value<-'min'}
                                
                                if(is.null(args$Deficit.value)==F){
                                  args$Deficit.value<-'max'}
                                
                                HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==5){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  if(b != d & d != f & f != h & h != l){
                                    print(paste(l,m,sep = '.'))
                                    args[[paste(b,'.value',sep='')]]<-c
                                    args[[paste(d,'.value',sep='')]]<-e
                                    args[[paste(f,'.value',sep='')]]<-g
                                    args[[paste(h,'.value',sep='')]]<-i
                                    args[[paste(l,'.value',sep='')]]<-m
                                    args[[paste('species')]]<-k
                                    args[[paste('predictors')]]<-j
                                    args[[paste('units')]]<-units
                                    
                                    if(is.null(args$snow.value)==F){
                                      args$snow.value<-'min'}
                                    
                                    if(is.null(args$Deficit.value)==F){
                                      args$Deficit.value<-'max'}
                                    
                                    HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==6){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  for(n in pred[6]){
                                    for(o in possibilities){
                                      if(b != d & d != f & f != h & h != l & l != n){
                                        print(paste(n,o,sep = '.'))
                                        args[[paste(b,'.value',sep='')]]<-c
                                        args[[paste(d,'.value',sep='')]]<-e
                                        args[[paste(f,'.value',sep='')]]<-g
                                        args[[paste(h,'.value',sep='')]]<-i
                                        args[[paste(l,'.value',sep='')]]<-m
                                        args[[paste(n,'.value',sep='')]]<-o
                                        args[[paste('species')]]<-k
                                        args[[paste('predictors')]]<-j
                                        args[[paste('units')]]<-units
                                        
                                        if(is.null(args$snow.value)==F){
                                          args$snow.value<-'min'}
                                        
                                        if(is.null(args$Deficit.value)==F){
                                          args$Deficit.value<-'max'}
                                        
                                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),paste(n,o,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } 
            } else print(paste('ERROR - number interacting variables > 6'))
          }
        }
      }
    } 
    return(HR)
  }
  
  save.image(file=paste('./OUTPUT/Cox/Cox.model.HRfunctions',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
  
} else load('./OUTPUT/Cox/Cox.model.HRfunctions.20200312.Rdata')


##############################################################################################################################################

##############################################################################################################################################-
######################################################### RUN SENSITIVITY SIMULATIONS  #######################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

#### CLIMATE DATA SETUP ####-
{
  ## SENSITIVITY.SUMMARY ANALYSIS ##
  Def.percent.change0 <- 2 # extreme dry used: 2
  snow.percent.change0 <- 0.05 # extreme dry used: 0.05
  
  Def.percent.change1 <- 1.5 # very dry used: 1.5
  snow.percent.change1 <- 0.5 # very dry used: 0.5
  
  Def.percent.change2 <- 1.25 # moderate dry used: 1.25
  snow.percent.change2 <- 0.75 # moderate dry used: 0.75
  
  Def.percent.change <- 1 # observed / modeled used: 1
  snow.percent.change <- 1 # observed / modeled used: 1
  
  Def.percent.change3 <- 0.75 # moderate wet used: 0.75
  snow.percent.change3 <- 1.25 # moderate wet used: 1.25
  
  Def.percent.change4 <- 0.5 # very wet used: 0.5
  snow.percent.change4 <- 1.5 # very wet used: 1.5
  
  Def.percent.change5 <- 0.05 # extreme wet used: 0.05
  snow.percent.change5 <- 2 # extreme wet used: 2
  ##
  mean.model.lag0 <- mean.model.lag
  mean.model.lag1 <- mean.model.lag
  mean.model.lag2 <- mean.model.lag
  mean.model.lag3 <- mean.model.lag
  mean.model.lag4 <- mean.model.lag
  mean.model.lag5 <- mean.model.lag
  
  if(snow.percent.change > 1){
    mean.model.lag[mean.model.lag$snow==0,"snow"] <- 1
  } 
  if(snow.percent.change0 > 1){
    mean.model.lag0[mean.model.lag0$snow==0,"snow"] <- 1
  }
  if(snow.percent.change1 > 1){
    mean.model.lag1[mean.model.lag1$snow==0,"snow"] <- 1
  }
  if(snow.percent.change2 > 1){
    mean.model.lag2[mean.model.lag2$snow==0,"snow"] <- 1
  }
  if(snow.percent.change3 > 1){
    mean.model.lag3[mean.model.lag3$snow==0,"snow"] <- 1
  }
  if(snow.percent.change4 > 1){
    mean.model.lag4[mean.model.lag4$snow==0,"snow"] <- 1
  }
  if(snow.percent.change5 > 1){
    mean.model.lag5[mean.model.lag5$snow==0,"snow"] <- 1
  }
  
  mean.model.lag$Deficit <- mean.model.lag$Deficit*Def.percent.change
  mean.model.lag$snow <- mean.model.lag$snow*snow.percent.change
  
  mean.model.lag0$Deficit <- mean.model.lag0$Deficit*Def.percent.change0
  mean.model.lag0$snow <- mean.model.lag0$snow*snow.percent.change0
  
  mean.model.lag1$Deficit <- mean.model.lag1$Deficit*Def.percent.change1
  mean.model.lag1$snow <- mean.model.lag1$snow*snow.percent.change1
  
  mean.model.lag2$Deficit <- mean.model.lag2$Deficit*Def.percent.change2
  mean.model.lag2$snow <- mean.model.lag2$snow*snow.percent.change2
  
  mean.model.lag3$Deficit <- mean.model.lag3$Deficit*Def.percent.change3
  mean.model.lag3$snow <- mean.model.lag3$snow*snow.percent.change3
  
  mean.model.lag4$Deficit <- mean.model.lag4$Deficit*Def.percent.change4
  mean.model.lag4$snow <- mean.model.lag4$snow*snow.percent.change4
  
  mean.model.lag5$Deficit <- mean.model.lag5$Deficit*Def.percent.change5
  mean.model.lag5$snow <- mean.model.lag5$snow*snow.percent.change5
  
}


#### STABILITY PROJECTIONS ####-
{
  ABAM.Hegyi.con.means<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag)
  ABAM.Hegyi.het.means<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag)
  
  ABAM.Hegyi.con.means6<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag0)
  ABAM.Hegyi.het.means6<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag0)
  
  ABAM.Hegyi.con.means1<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag1)
  ABAM.Hegyi.het.means1<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag1)
  
  ABAM.Hegyi.con.means2<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag2)
  ABAM.Hegyi.het.means2<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag2)
  
  ABAM.Hegyi.con.means3<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag3)
  ABAM.Hegyi.het.means3<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag3)
  
  ABAM.Hegyi.con.means4<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag4)
  ABAM.Hegyi.het.means4<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag4)
  
  ABAM.Hegyi.con.means5<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag5)
  ABAM.Hegyi.het.means5<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag5)
  
  ####
  TSHE.Hegyi.con.means<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag)
  TSHE.Hegyi.het.means<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag)
  
  TSHE.Hegyi.con.means6<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag0)
  TSHE.Hegyi.het.means6<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag0)
  
  TSHE.Hegyi.con.means1<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag1)
  TSHE.Hegyi.het.means1<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag1)
  
  TSHE.Hegyi.con.means2<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag2)
  TSHE.Hegyi.het.means2<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag2)
  
  TSHE.Hegyi.con.means3<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag3)
  TSHE.Hegyi.het.means3<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag3)
  
  TSHE.Hegyi.con.means4<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag4)
  TSHE.Hegyi.het.means4<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag4)
  
  TSHE.Hegyi.con.means5<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag5)
  TSHE.Hegyi.het.means5<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag5)
  
  ####
  PSME.Hegyi.con.means<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag)
  PSME.Hegyi.het.means<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag)
  
  PSME.Hegyi.con.means6<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag0)
  PSME.Hegyi.het.means6<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag0)
  
  PSME.Hegyi.con.means1<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag1)
  PSME.Hegyi.het.means1<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag1)
  
  PSME.Hegyi.con.means2<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag2)
  PSME.Hegyi.het.means2<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag2)
  
  PSME.Hegyi.con.means3<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag3)
  PSME.Hegyi.het.means3<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag3)
  
  PSME.Hegyi.con.means4<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag4)
  PSME.Hegyi.het.means4<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag4)
  
  PSME.Hegyi.con.means5<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag5)
  PSME.Hegyi.het.means5<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag5)
  
  ####
  TABR.Hegyi.con.means<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag)
  TABR.Hegyi.het.means<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag)
  
  TABR.Hegyi.con.means6<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag0)
  TABR.Hegyi.het.means6<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag0)
  
  TABR.Hegyi.con.means1<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag1)
  TABR.Hegyi.het.means1<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag1)
  
  TABR.Hegyi.con.means2<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag2)
  TABR.Hegyi.het.means2<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag2)
  
  TABR.Hegyi.con.means3<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag3)
  TABR.Hegyi.het.means3<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag3)
  
  TABR.Hegyi.con.means4<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag4)
  TABR.Hegyi.het.means4<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag4)
  
  TABR.Hegyi.con.means5<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag5)
  TABR.Hegyi.het.means5<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag5)
  
  ####
  ACCI.Hegyi.con.means<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag)
  ACCI.Hegyi.het.means<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag)
  
  ACCI.Hegyi.con.means6<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag0)
  ACCI.Hegyi.het.means6<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag0)
  
  ACCI.Hegyi.con.means1<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag1)
  ACCI.Hegyi.het.means1<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag1)
  
  ACCI.Hegyi.con.means2<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag2)
  ACCI.Hegyi.het.means2<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag2)
  
  ACCI.Hegyi.con.means3<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag3)
  ACCI.Hegyi.het.means3<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag3)
  
  ACCI.Hegyi.con.means4<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag4)
  ACCI.Hegyi.het.means4<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag4)
  
  ACCI.Hegyi.con.means5<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag5)
  ACCI.Hegyi.het.means5<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag5)
  
 
}

##############################################################################################################################################

##############################################################################################################################################-
##############################################################  COMPARISON PLOT S9  ##########################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

  ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR 
  ABAM.dat1x<-cbind(ABAM.Hegyi.het.means,ABAM.Hegyi.con.means); colnames(ABAM.dat1x) <- c('HRh','yearh','HRc','yearc')   # sensitivity control
  ABAM.dat2x<-cbind(ABAM.Hegyi.het.means1,ABAM.Hegyi.con.means1); colnames(ABAM.dat2x) <- c('HRh','yearh','HRc','yearc') # sensitivity very dry
  ABAM.dat3x<-cbind(ABAM.Hegyi.het.means2,ABAM.Hegyi.con.means2); colnames(ABAM.dat3x) <- c('HRh','yearh','HRc','yearc') # sensitivity mod dry
  ABAM.dat4x<-cbind(ABAM.Hegyi.het.means3,ABAM.Hegyi.con.means3); colnames(ABAM.dat4x) <- c('HRh','yearh','HRc','yearc') # sensitivity mod wet
  ABAM.dat5x<-cbind(ABAM.Hegyi.het.means4,ABAM.Hegyi.con.means4); colnames(ABAM.dat5x) <- c('HRh','yearh','HRc','yearc') # sensitivity very wet
  ABAM.dat6x<-cbind(ABAM.Hegyi.het.means5,ABAM.Hegyi.con.means5); colnames(ABAM.dat6x) <- c('HRh','yearh','HRc','yearc') # sensitivity ext wet
  ABAM.dat7x<-cbind(ABAM.Hegyi.het.means6,ABAM.Hegyi.con.means6); colnames(ABAM.dat7x) <- c('HRh','yearh','HRc','yearc') # sensitivity ext dry
  
  
  ABAM4b<-ggplot(data=ABAM.dat1x, aes(yearc,HRc-HRh)) + theme_prefs + #### for sensitivity.summary
    geom_line(data=ABAM.dat7x, color='red', size=0.4, linetype = 'longdash')+ 
    geom_line(data=ABAM.dat2x, color='red', size=0.4)+ 
    geom_line(data=ABAM.dat3x, color='red', alpha = 0.3, size=0.4)+ 
    geom_line(data=ABAM.dat4x, color='blue', alpha = 0.3, size=0.4)+ 
    geom_line(data=ABAM.dat5x, color='blue', size=0.4)+ 
    geom_line(data=ABAM.dat6x, color='blue', size=0.4, linetype = 'longdash')+ 
    geom_line(data=ABAM.dat1x, color='black', size=0.3)+
    geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
    theme(axis.title = element_blank()) +
    scale_x_continuous(breaks=seq(2020,2100,20)) +
    scale_y_continuous(breaks=seq(-2,2,1))+
    coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
    geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
              linetype='dashed', color="black", alpha=0, size=0.2)
  # scale_y_continuous(breaks=seq(-10,10,2))+ # could also use these dimensions
  #   coord_cartesian(ylim=c(-11,11), xlim=c(2010,2105))+
  #   geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
  #             linetype='dashed', color="black", alpha=0, size=0.2)
  
  
  ##############-
  
  ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
  TSHE.dat1x<-cbind(TSHE.Hegyi.het.means,TSHE.Hegyi.con.means); colnames(TSHE.dat1x) <- c('HRh','yearh','HRc','yearc')
  TSHE.dat2x<-cbind(TSHE.Hegyi.het.means1,TSHE.Hegyi.con.means1); colnames(TSHE.dat2x) <- c('HRh','yearh','HRc','yearc')
  TSHE.dat3x<-cbind(TSHE.Hegyi.het.means2,TSHE.Hegyi.con.means2); colnames(TSHE.dat3x) <- c('HRh','yearh','HRc','yearc')
  TSHE.dat4x<-cbind(TSHE.Hegyi.het.means3,TSHE.Hegyi.con.means3); colnames(TSHE.dat4x) <- c('HRh','yearh','HRc','yearc')
  TSHE.dat5x<-cbind(TSHE.Hegyi.het.means4,TSHE.Hegyi.con.means4); colnames(TSHE.dat5x) <- c('HRh','yearh','HRc','yearc')
  TSHE.dat6x<-cbind(TSHE.Hegyi.het.means5,TSHE.Hegyi.con.means5); colnames(TSHE.dat6x) <- c('HRh','yearh','HRc','yearc')
  TSHE.dat7x<-cbind(TSHE.Hegyi.het.means6,TSHE.Hegyi.con.means6); colnames(TSHE.dat7x) <- c('HRh','yearh','HRc','yearc')
  
  
  TSHE4b<-ggplot(data=TSHE.dat1x, aes(yearc,HRc-HRh)) + theme_prefs + # for sensitivity.summary
    geom_line(data=TSHE.dat7x, color='red', size=0.4, linetype = 'longdash')+ 
    geom_line(data=TSHE.dat2x, color='red', size=0.4)+ 
    geom_line(data=TSHE.dat3x, color='red', alpha = 0.3, size=0.4)+ 
    geom_line(data=TSHE.dat4x, color='blue', alpha = 0.3, size=0.4)+ 
    geom_line(data=TSHE.dat5x, color='blue', size=0.4)+ 
    geom_line(data=TSHE.dat6x, color='blue', size=0.4, linetype = 'longdash')+ 
    geom_line(data=TSHE.dat1x, color='black', size=0.3)+
    geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
    # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
    theme(axis.title = element_blank()) +
    # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
    scale_x_continuous(breaks=seq(2020,2100,20)) +
    scale_y_continuous(breaks=seq(-2,2,1))+
    coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
    geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
              linetype='dashed', color="black", alpha=0, size=0.2)
  # scale_y_continuous(breaks=seq(-10,10,2))+ # could also use these dimensions
  #   coord_cartesian(ylim=c(-11,11), xlim=c(2010,2105))+
  #   geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
  #             linetype='dashed', color="black", alpha=0, size=0.2)
  
  
  ##############-
  
  ### DIFFERENCE BETWEEN CON and HET - if no con, subtract 1 from all HR
  PSME.dat1x<-cbind(PSME.Hegyi.het.means,PSME.Hegyi.con.means); colnames(PSME.dat1x) <- c('HRh','yearh','HRc','yearc')
  PSME.dat2x<-cbind(PSME.Hegyi.het.means1,PSME.Hegyi.con.means1); colnames(PSME.dat2x) <- c('HRh','yearh','HRc','yearc')
  PSME.dat3x<-cbind(PSME.Hegyi.het.means2,PSME.Hegyi.con.means2); colnames(PSME.dat3x) <- c('HRh','yearh','HRc','yearc')
  PSME.dat4x<-cbind(PSME.Hegyi.het.means3,PSME.Hegyi.con.means3); colnames(PSME.dat4x) <- c('HRh','yearh','HRc','yearc')
  PSME.dat5x<-cbind(PSME.Hegyi.het.means4,PSME.Hegyi.con.means4); colnames(PSME.dat5x) <- c('HRh','yearh','HRc','yearc')
  PSME.dat6x<-cbind(PSME.Hegyi.het.means5,PSME.Hegyi.con.means5); colnames(PSME.dat6x) <- c('HRh','yearh','HRc','yearc')
  PSME.dat7x<-cbind(PSME.Hegyi.het.means6,PSME.Hegyi.con.means6); colnames(PSME.dat7x) <- c('HRh','yearh','HRc','yearc')
  
  
  PSME4b<-ggplot(data=PSME.dat1x, aes(yearc,HRc-HRh)) + theme_prefs + # for sensitivity.summary
    geom_line(data=PSME.dat7x, color='red', size=0.4, linetype = 'longdash')+ 
    geom_line(data=PSME.dat2x, color='red', size=0.4)+ 
    geom_line(data=PSME.dat3x, color='red', alpha = 0.3, size=0.4)+ 
    geom_line(data=PSME.dat4x, color='blue', alpha = 0.3, size=0.4)+ 
    geom_line(data=PSME.dat5x, color='blue', size=0.4)+ 
    geom_line(data=PSME.dat6x, color='blue', size=0.4, linetype = 'longdash')+ 
    geom_line(data=PSME.dat1x, color='black', size=0.3)+
    geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
    # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
    theme(axis.title = element_blank()) +
    # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
    scale_x_continuous(breaks=seq(2020,2100,20)) +
    scale_y_continuous(breaks=seq(-2,2,1))+
    coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
    geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
              linetype='dashed', color="black", alpha=0, size=0.2)
  # scale_y_continuous(breaks=seq(-10,10,2))+ # could also use these dimensions
  #   coord_cartesian(ylim=c(-11,11), xlim=c(2010,2105))+
  #   geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
  #             linetype='dashed', color="black", alpha=0, size=0.2)
  
  ##############-
  
  ### DIFFERENCE BETWEEN CON and HET
  TABR.dat1x<-cbind(TABR.Hegyi.het.means,TABR.Hegyi.con.means); colnames(TABR.dat1x) <- c('HRh','yearh','HRc','yearc')
  TABR.dat2x<-cbind(TABR.Hegyi.het.means1,TABR.Hegyi.con.means1); colnames(TABR.dat2x) <- c('HRh','yearh','HRc','yearc')
  TABR.dat3x<-cbind(TABR.Hegyi.het.means2,TABR.Hegyi.con.means2); colnames(TABR.dat3x) <- c('HRh','yearh','HRc','yearc')
  TABR.dat4x<-cbind(TABR.Hegyi.het.means3,TABR.Hegyi.con.means3); colnames(TABR.dat4x) <- c('HRh','yearh','HRc','yearc')
  TABR.dat5x<-cbind(TABR.Hegyi.het.means4,TABR.Hegyi.con.means4); colnames(TABR.dat5x) <- c('HRh','yearh','HRc','yearc')
  TABR.dat6x<-cbind(TABR.Hegyi.het.means5,TABR.Hegyi.con.means5); colnames(TABR.dat6x) <- c('HRh','yearh','HRc','yearc')
  TABR.dat7x<-cbind(TABR.Hegyi.het.means6,TABR.Hegyi.con.means6); colnames(TABR.dat7x) <- c('HRh','yearh','HRc','yearc')
  
  TABR4b<-ggplot(data=TABR.dat1x, aes(yearc,HRc-HRh)) + theme_prefs + # for sensitivity.summary
    geom_line(data=TABR.dat7x, color='red', size=0.4, linetype = 'longdash')+ 
    geom_line(data=TABR.dat2x, color='red', size=0.4)+ 
    geom_line(data=TABR.dat3x, color='red', alpha = 0.3, size=0.4)+ 
    geom_line(data=TABR.dat4x, color='blue', alpha = 0.3, size=0.4)+ 
    geom_line(data=TABR.dat5x, color='blue', size=0.4)+ 
    geom_line(data=TABR.dat6x, color='blue', size=0.4, linetype = 'longdash')+ 
    geom_line(data=TABR.dat1x, color='black', size=0.3)+
    geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
    # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
    theme(axis.title = element_blank()) +
    # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
    scale_x_continuous(breaks=seq(2020,2100,20)) +
    scale_y_continuous(breaks=seq(-2,2,1))+
    coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
    geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
              linetype='dashed', color="black", alpha=0, size=0.2)
  # scale_y_continuous(breaks=seq(-10,10,2))+ # could also use these dimensions
  #   coord_cartesian(ylim=c(-11,11), xlim=c(2010,2105))+
  #   geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
  #             linetype='dashed', color="black", alpha=0, size=0.2)
  
  
  ##############-
  
  ### DIFFERENCE BETWEEN CON and HET - since no con, subtract 1 from all HR
  ACCI.Hegyi.het.means <- ACCI.Hegyi.con.means
  ACCI.Hegyi.het.means[,'HR'] <- 1
  
  ACCI.dat1x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means); colnames(ACCI.dat1x) <- c('HRh','yearh','HRc','yearc')
  ACCI.dat2x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means1); colnames(ACCI.dat2x) <- c('HRh','yearh','HRc','yearc')
  ACCI.dat3x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means2); colnames(ACCI.dat3x) <- c('HRh','yearh','HRc','yearc')
  ACCI.dat4x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means3); colnames(ACCI.dat4x) <- c('HRh','yearh','HRc','yearc')
  ACCI.dat5x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means4); colnames(ACCI.dat5x) <- c('HRh','yearh','HRc','yearc')
  ACCI.dat6x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means5); colnames(ACCI.dat6x) <- c('HRh','yearh','HRc','yearc')
  ACCI.dat7x<-cbind(ACCI.Hegyi.het.means,ACCI.Hegyi.con.means6); colnames(ACCI.dat7x) <- c('HRh','yearh','HRc','yearc')
  
  
  ACCI4b<-ggplot(data=ACCI.dat1x, aes(yearc,HRc-HRh)) + theme_prefs + # for sensitivity.summary
    geom_line(data=ACCI.dat7x, color='red', size=0.4, linetype = 'longdash')+ 
    geom_line(data=ACCI.dat2x, color='red', size=0.4)+ 
    geom_line(data=ACCI.dat3x, color='red', alpha = 0.3, size=0.4)+ 
    geom_line(data=ACCI.dat4x, color='blue', alpha = 0.3, size=0.4)+ 
    geom_line(data=ACCI.dat5x, color='blue', size=0.4)+ 
    geom_line(data=ACCI.dat6x, color='blue', size=0.4, linetype = 'longdash')+ 
    geom_line(data=ACCI.dat1x, color='black', size=0.3)+
    geom_hline(yintercept = 0,color='black', size = 0.2,linetype='dashed')+
    # xlab("year")+ylab("Conspecific Hazard Ratio - Heterospecific Hazard Ratio")+
    theme(axis.title = element_blank()) +
    # ggtitle(expression(bolditalic("Tsuga heterophylla"))) +
    scale_x_continuous(breaks=seq(2020,2100,20)) +
    scale_y_continuous(breaks=seq(-2,2,1))+
    coord_cartesian(ylim=c(-2.5,2.5), xlim=c(2010,2105))+
    geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-2), ymax=2),
              linetype='dashed', color="black", alpha=0, size=0.2)
  # scale_y_continuous(breaks=seq(-10,10,2))+ # could also use these dimensions
  #   coord_cartesian(ylim=c(-11,11), xlim=c(2010,2105))+
  #   geom_rect(mapping=aes(xmin=2010, xmax=2020,ymin=(-10), ymax=10),
  #             linetype='dashed', color="black", alpha=0, size=0.2)
  
  
  ##############-
  
  plot<-plot_grid(ABAM4b, PSME4b, TABR4b, TSHE4b, ACCI4b, nrow=2, ncol=3, align='v')
  
  y.grob<-textGrob("Stability Strength", gp=gpar(col="black", fontsize=10), rot=90)
  x.grob<-textGrob("Year", gp=gpar(col="black", fontsize=10))
  
  gridExtra::grid.arrange(arrangeGrob(plot, left = y.grob, bottom = x.grob))
  
  dev.print(file=paste('./Papers/FigS10_with2019_noMECH_noshrub','.tif',sep=''),tiff,width=7.0,height=6.5,res=600,units='in',compression='lzw')
  
  
##############################################################################################################################################

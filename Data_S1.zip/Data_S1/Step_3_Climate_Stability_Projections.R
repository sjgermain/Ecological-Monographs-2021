## WFDP Climate Projections for Models ##
## Sara Germain ##
## March 2020 ##

setwd("WFDP_Demography_20200303")

LOAD.CLIMATE=T
RUN.PRISM.SUMMARY=F
RUN.GROWTH=F
RUN.BETAS=F
RUN.VAR.SUMMARY=F
RUN.FUNC.CALC=F
RUN.HR.FUNCS=F
RUN.COMBO.SUMMARIES=F
RUN.PERMUTATIONS=F

###############################################################################################################################################################-
######################################################################### LIBRARIES AND FUNCTIONS #############################################################-
#-------------------------------------------------------------------------------------------------------------------------------------------------------------

library('nlme')
library('grid')
library('ggplot2')
library('gridExtra')
library('cowplot')

right <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

left <- function(x, n){
  substr(x, 1, n)
}

theme_prefs<-theme_classic() + theme(axis.title.x = element_text(size=8),
                                     axis.title.y = element_text(size=8),
                                     axis.text.x = element_text(size=8, colour='black'),
                                     axis.text.y = element_text(size=8, colour='black'),
                                     axis.ticks = element_line(colour='black'),
                                     legend.text = element_text(size=8),
                                     legend.title = element_text(size=8),
                                     plot.title=element_text(size=10,hjust=0.5, vjust=-3))

###############################################################################################################################################################

###############################################################################################################################################################-
########################################################################### CLIMATE PROJECTIONS ###############################################################'
#--------------------------------------------------------------------------------------------------------------------------------------------------------------

if(LOAD.CLIMATE==T){
  if (RUN.PRISM.SUMMARY==T){
    
    ## DATA ## 
    {
      historical<-datt<-read.csv("./DATA/Climate/NEX PRISM 800-m/prism_historical_195001-201912.csv",na.strings='NULL')
      datt<-read.csv("./DATA/Climate/NEX PRISM 800-m/HadGEM2-ES_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt1<-read.csv("./DATA/Climate/NEX PRISM 800-m/HadGEM2-CC_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt2<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-CM3_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt3<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-ESM2G_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt4<-read.csv("./DATA/Climate/NEX PRISM 800-m/GFDL-ESM2M_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      datt5<-read.csv("./DATA/Climate/NEX PRISM 800-m/CCSM4_rcp85_r1i1p1_195001-209912.csv",na.strings='NULL')
      
      historical$year<-as.character(historical$year)
      datt$year<-as.character(datt$year)
      datt1$year<-as.character(datt1$year)
      datt2$year<-as.character(datt2$year)
      datt3$year<-as.character(datt3$year)
      datt4$year<-as.character(datt4$year)
      datt5$year<-as.character(datt5$year)
      
      historical$year<-as.numeric(right(historical$year,4))
      datt$year<-as.numeric(right(datt$year,4))
      datt1$year<-as.numeric(right(datt1$year,4))
      datt2$year<-as.numeric(right(datt2$year,4))
      datt3$year<-as.numeric(right(datt3$year,4))
      datt4$year<-as.numeric(right(datt4$year,4))
      datt5$year<-as.numeric(right(datt5$year,4))
      
      mean.time<-seq(1950,2099,1)
      mean.model.all<- datt1
      mean.model.all[1:nrow(mean.model.all),3:ncol(mean.model.all)]<-NA
      for(i in mean.time){
        for(k in 1:12){
          for(j in colnames(mean.model.all)[3:ncol(mean.model.all)]){
            mean.model.all[mean.model.all$year==i&mean.model.all$month==k,j] <- mean(c(datt[datt$year==i&datt$month==k,colnames(datt)==j],
                                                                                       datt1[datt1$year==i&datt1$month==k,colnames(datt1)==j],
                                                                                       datt2[datt2$year==i&datt2$month==k,colnames(datt2)==j],
                                                                                       datt3[datt3$year==i&datt3$month==k,colnames(datt3)==j],
                                                                                       datt4[datt4$year==i&datt4$month==k,colnames(datt4)==j],
                                                                                       datt5[datt5$year==i&datt5$month==k,colnames(datt5)==j]))
          }
        }
      }
      
    }
    
    ##########################################################################################################################################################################'
    ################################################################## GET DEFICIT and SNOWPACK PROJECTIONS ##################################################################'
    #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    WFDP_yearly_deficit0<-data.frame("year"=c(1950:2019),"deficit"=NA)
    for(i in 1950:2019){WFDP_yearly_deficit0[WFDP_yearly_deficit0$year==i,2]<-sum(historical[historical$year==i,'deficit'])}
    WFDP_yearly_snowppack0<-data.frame("year"=c(1950:2019),"snowppack"=NA)
    for(i in 1950:2019){WFDP_yearly_snowppack0[WFDP_yearly_snowppack0$year==i,2]<-max(historical[(historical$year==i&historical$month<=7)|(historical$year==(i-1)&historical$month>7),'snow'])}
    hist.defsnow<-merge(WFDP_yearly_deficit0,WFDP_yearly_snowppack0,by='year')
    save(hist.defsnow,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_HISTORICAL_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit[WFDP_yearly_deficit$year==i,2]<-sum(datt[datt$year==i,'deficit'])}
    WFDP_yearly_snowppack<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack[WFDP_yearly_snowppack$year==i,2]<-max(datt[(datt$year==i&datt$month<=7)|(datt$year==(i-1)&datt$month>7),'snow'])}
    hadgem2.es<-merge(WFDP_yearly_deficit,WFDP_yearly_snowppack,by='year')
    hadgem2.es<-hadgem2.es[hadgem2.es$year>2019,]
    save(hadgem2.es,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-ES_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit1<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit1[WFDP_yearly_deficit1$year==i,2]<-sum(datt1[datt1$year==i,'deficit'])}
    WFDP_yearly_snowppack1<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack1[WFDP_yearly_snowppack1$year==i,2]<-max(datt1[(datt1$year==i&datt1$month<=7)|(datt1$year==(i-1)&datt1$month>7),'snow'])}
    hadgem2.cc<-merge(WFDP_yearly_deficit1,WFDP_yearly_snowppack1,by='year')
    hadgem2.cc<-hadgem2.cc[hadgem2.cc$year>2019,]
    save(hadgem2.cc,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-CC_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit2<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit2[WFDP_yearly_deficit2$year==i,2]<-sum(datt2[datt2$year==i,'deficit'])}
    WFDP_yearly_snowppack2<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack2[WFDP_yearly_snowppack2$year==i,2]<-max(datt2[(datt2$year==i&datt2$month<=7)|(datt2$year==(i-1)&datt2$month>7),'snow'])}
    gfdl.cm3<-merge(WFDP_yearly_deficit2,WFDP_yearly_snowppack2,by='year')
    gfdl.cm3<-gfdl.cm3[gfdl.cm3$year>2019,]
    save(gfdl.cm3,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-CM3_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit3<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit3[WFDP_yearly_deficit3$year==i,2]<-sum(datt3[datt3$year==i,'deficit'])}
    WFDP_yearly_snowppack3<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack3[WFDP_yearly_snowppack3$year==i,2]<-max(datt3[(datt3$year==i&datt3$month<=7)|(datt3$year==(i-1)&datt3$month>7),'snow'])}
    gfdl.esm2g<-merge(WFDP_yearly_deficit3,WFDP_yearly_snowppack3,by='year')
    gfdl.esm2g<-gfdl.esm2g[gfdl.esm2g$year>2019,]
    save(gfdl.esm2g,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2G_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit4<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit4[WFDP_yearly_deficit4$year==i,2]<-sum(datt4[datt4$year==i,'deficit'])}
    WFDP_yearly_snowppack4<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack4[WFDP_yearly_snowppack4$year==i,2]<-max(datt4[(datt4$year==i&datt4$month<=7)|(datt4$year==(i-1)&datt4$month>7),'snow'])}
    gfdl.esm2m<-merge(WFDP_yearly_deficit4,WFDP_yearly_snowppack4,by='year')
    gfdl.esm2m<-gfdl.esm2m[gfdl.esm2m$year>2019,]
    save(gfdl.esm2m,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2M_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    WFDP_yearly_deficit5<-data.frame("year"=c(2019:2099),"deficit"=NA)
    for(i in 2019:2099){WFDP_yearly_deficit5[WFDP_yearly_deficit5$year==i,2]<-sum(datt5[datt5$year==i,'deficit'])}
    WFDP_yearly_snowppack5<-data.frame("year"=c(2019:2099),"snowppack"=NA)
    for(i in 2019:2099){WFDP_yearly_snowppack5[WFDP_yearly_snowppack5$year==i,2]<-max(datt5[(datt5$year==i&datt5$month<=7)|(datt5$year==(i-1)&datt5$month>7),'snow'])}
    ccsm4<-merge(WFDP_yearly_deficit5,WFDP_yearly_snowppack5,by='year')
    ccsm4<-ccsm4[ccsm4$year>2019,]
    save(ccsm4,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_CCSM4_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    mean.time<-seq(2020,2099,1)
    mean.model<- data.frame('year'=seq(2020,2099,1),'deficit'=NA,'snowppack'=NA)
    for(i in mean.time){
      mean.model[mean.model$year==i,'deficit'] <- mean(c(hadgem2.cc[hadgem2.cc$year==i,'deficit'],
                                                         hadgem2.es[hadgem2.es$year==i,'deficit'],
                                                         gfdl.cm3[gfdl.cm3$year==i,'deficit'],
                                                         gfdl.esm2g[gfdl.esm2g$year==i,'deficit'],
                                                         gfdl.esm2m[gfdl.esm2m$year==i,'deficit'],
                                                         ccsm4[ccsm4$year==i,'deficit']))
      mean.model[mean.model$year==i,'snowppack'] <- mean(c(hadgem2.cc[hadgem2.cc$year==i,'snowppack'],
                                                           hadgem2.es[hadgem2.es$year==i,'snowppack'],
                                                           gfdl.cm3[gfdl.cm3$year==i,'snowppack'],
                                                           gfdl.esm2g[gfdl.esm2g$year==i,'snowppack'],
                                                           gfdl.esm2m[gfdl.esm2m$year==i,'snowppack'],
                                                           ccsm4[ccsm4$year==i,'snowppack']))
    }
    
    save(mean.model,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_MEANMODEL_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    
    mean.full.model <- rbind(hist.defsnow,mean.model)
    save(mean.full.model,file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    #create lagged deficit -------------------------------------------------------------#
    models<-c('ccsm4','gfdl.cm3','gfdl.esm2g','gfdl.esm2m','hadgem2.cc','hadgem2.es','mean.model')
    
    for (i in models){
      model<-eval(parse(text=i))
      combined<-rbind(hist.defsnow,model)
      for (j in 2:nrow(combined)){
        combined[j,'deflag1'] <- combined[j-1,'deficit']
        assign(paste(i,'lag',sep='.'),combined)
      }
    }
    
    colnames(mean.model.lag)[3]<-'snow'
    colnames(mean.model.lag)[4]<-'Deficit'
    colnames(ccsm4.lag)[3]<-'snow'
    colnames(ccsm4.lag)[4]<-'Deficit'
    colnames(gfdl.cm3.lag)[3]<-'snow'
    colnames(gfdl.cm3.lag)[4]<-'Deficit'
    colnames(gfdl.esm2g.lag)[3]<-'snow'
    colnames(gfdl.esm2g.lag)[4]<-'Deficit'
    colnames(gfdl.esm2m.lag)[3]<-'snow'
    colnames(gfdl.esm2m.lag)[4]<-'Deficit'
    colnames(hadgem2.cc.lag)[3]<-'snow'
    colnames(hadgem2.cc.lag)[4]<-'Deficit'
    colnames(hadgem2.es.lag)[3]<-'snow'
    colnames(hadgem2.es.lag)[4]<-'Deficit'
    
    save(mean.model.lag,ccsm4.lag,gfdl.cm3.lag,gfdl.esm2g.lag,gfdl.esm2m.lag,hadgem2.cc.lag,hadgem2.es.lag,
         file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_lagged.def_PRISM_method_",format(Sys.time(),'%Y%m%d'),sep=''))
    
    ## summarize deficit and snowpack
    future.def<-summary(mean.model[mean.model$year>2060&mean.model$year<2070,'deficit'])
    future.snow<-summary(mean.model[mean.model$year>2060&mean.model$year<2070,'snowppack'])
    past.def<-summary(hist.defsnow[hist.defsnow$year>2010&hist.defsnow$year<2020,'deficit'])
    past.snow<-summary(hist.defsnow[hist.defsnow$year>2010&hist.defsnow$year<2020,'snowppack'])
    
    #####################################################################################################################################################################
    
  } else c(load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_CCSM4_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-CM3_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2G_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_GFDL-ESM2M_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-CC_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_FUTURE_PRISM_method_HadGEM2-ES_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_HISTORICAL_PRISM_method_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_MEANMODEL_PRISM_method_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_PRISM_method_20200310'),
           load('./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_ALLYEARS_lagged.def_PRISM_method_20200310'))
}

## for Appendix S2
# write.csv(hist.defsnow,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_historical_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)
# write.csv(mean.model,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_meanmodel_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)
# write.csv(ccsm4,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_ccsm4_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)
# write.csv(gfdl.cm3,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_gfdl.cm3_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)
# write.csv(gfdl.esm2g,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_gfdl.esm2g_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)
# write.csv(gfdl.esm2m,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_gfdl.esm2m_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)
# write.csv(hadgem2.cc,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_hadgem2.cc_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)
# write.csv(hadgem2.es,
#           file=paste("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Table_6_hadgem2.es_",format(Sys.time(),'%Y%m%d'),'.csv',sep=''), row.names = F)


##############################################################################################################################################################

###############################################################################################################################################################-
#################################################################### 6 STEPS - PROJECT HAZARD FORWARD ########################################################'
#--------------------------------------------------------------------------------------------------------------------------------------------------------------

#STEP 1 - GET ALL SIGNIFICANT BETAS
if (RUN.BETAS==T){

  load('./OUTPUT/Cox/HetCon.table.BETAS_w2019_w02011_scaledHegyis_noMECH.20200311.Rdata')
  load('./OUTPUT/Cox/HetCon.table.HR_w2019_w02011_scaledHegyis_noMECH.20200311.Rdata')


# tables=c('table.6','table.2','table.4')
tables = c('table.6')
species=c('ABAM','PSME','TABR','TSHE','ACCI')
speciesb=c('ABAMb','PSMEb','TABRb','TSHEb','ACCIb')
predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con')

for(i in tables){
  #make data
  hr<-eval(parse(text=i))
  beta<-eval(parse(text=paste(i,'b',sep='')))
  colnames(beta)[1:length(beta)]<-paste(colnames(beta),'b',sep='')
  merged<-cbind(hr,beta)
  
  for(j in 1:nrow(merged)){
      for (k in colnames(hr)){  
        #get all significant betas
        sig.hr<-grep(pattern="*", merged[,k], value=TRUE, fixed=TRUE) 
        sig.betas<-as.numeric(merged[merged[,k]%in%sig.hr,paste(k,'b',sep='')]) 
        name<-merged[merged[,k]%in%sig.hr,ncol(merged)]
        fin<-data.frame('predictor' = name, 'beta' = sig.betas, 'hr' = sig.hr)
      
      for(m in predictors){
        #get significant betas per predictor of interest
        pred<-grep(pattern=parse(text=m), fin$predictor, value=TRUE) 
        pred.beta<-as.numeric(fin[fin$predictor%in%pred,'beta']) 
        finale<-data.frame('predictor' = pred, 'beta' = pred.beta)
        finale$predictor<-as.character(finale$predictor)
        
        #get non-significant betas for lower-order interaction terms of significant higher-order interactions
        add.cum<-c()
        for(p in finale$predictor){
          pieces <- unlist(strsplit(p,':',fixed=TRUE)) #all components of interaction
          
          if (length(pieces) >= 3) {
            bivar<-as.vector(outer(pieces, pieces, paste, sep=":")) #all possible combos of components
            trivar<-as.vector(outer(bivar, pieces, paste, sep=":"))
            add<-c(bivar, trivar) 
            add.cum<-c(add.cum,add)
          }
          
          addition<-grep(pattern=parse(text=m), add.cum, value=TRUE)
          addition<-c(addition,m)
          newname<-beta[(!beta$`Pretty Names`%in%finale$predictor)&beta$`Pretty Names`%in%addition,ncol(beta)]
          newbeta<-beta[(!beta$`Pretty Names`%in%finale$predictor)&beta$`Pretty Names`%in%addition,paste(k,'b',sep='')]
          newfin<-data.frame('predictor' = newname, 'beta' = newbeta)
          
          total.finale<-rbind(finale,newfin)
          assign(paste(i,k,m,sep='.'),total.finale)
          print(paste(i,k,m))
          
        }
      }
    }
  }
}

rm(beta)
rm(fin)
rm(finale)
rm(hr)
rm(merged)
rm(newfin)
rm(total.finale)

save.image(file=paste('./OUTPUT/Cox/Project.HR.model.BetaTables_w2019_wo2011_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))



} else {load('./OUTPUT/Cox/Project.HR.model.BetaTables_w2019_wo2011_scaledHegyis_noMECH.20200312.Rdata')}

#STEP 2 - DEFINE MIN and MAX for PREDICTORS
if (RUN.VAR.SUMMARY==T){

  
  load('./OUTPUT/Cox/Species_dataframes_agentGeneric_noMECH_20200311.Rdata')
  load("./DATA/Climate/NEX PRISM 800-m/OUTPUT/Deficit_snowpack_8yr_PRISM_method_20200310")
  colnames(def.snow)[1]<-'CENSUS'
  def.snow$deflag1<-def.snow[c(nrow(def.snow),1:(nrow(def.snow)-1)),'deficit']
  def.snow<-def.snow[def.snow$CENSUS>2011,]
  def.snow[2:4]<-apply(def.snow[2:4],2,FUN= function(x){x-mean(x)}) #center variables
  
  variables<-c('elev.diff','zscore.Hegyi.con','zscore.Hegyi.het')
  Variable.Summaries<-c()
  species=c('ABAM','PSME','TABR','TSHE','ACCI')
  
  for (i in paste(species,'gen',sep='.')){
    for (j in variables){
      model<-eval(parse(text=i))
      datt<-data.frame('Species'=paste(i),'Variable'=paste(j),'min'= ifelse(min(model[,j])<=(mean(model[,j])-(2*sd(model[,j]))),(mean(model[,j])-(2*sd(model[,j]))),min(model[,j])),
                       'mean'=mean(model[,j]),'max'=ifelse(max(model[,j])>=(mean(model[,j])+(2*sd(model[,j]))),(mean(model[,j])+(2*sd(model[,j]))),min(model[,j])))
      Variable.Summaries<-rbind(Variable.Summaries,datt)
    }
  }
  for (i in paste(species,'gen',sep='.')){
    blat<-data.frame('Species'=paste(i),'Variable'=c('snowppack','deflag1'),'min'=c(min(def.snow$snowppack),min(def.snow$deflag1)),
                     'mean'=c(0,0),'max'=c(max(def.snow$snowppack),max(def.snow$deflag1)))
    Variable.Summaries<-rbind(Variable.Summaries,blat)
  }
  Variable.Summaries<-Variable.Summaries[order(Variable.Summaries$Species,Variable.Summaries$Variable),]
  
Variable.Summaries$`Pretty Names`<-gsub(pattern='deflag1',replacement='Deficit',Variable.Summaries$Variable)
Variable.Summaries$`Pretty Names`<-gsub(pattern='snowppack',replacement='snow',Variable.Summaries$`Pretty Names`)
Variable.Summaries$`Pretty Names`<-gsub(pattern='elev.diff',replacement='watertable',Variable.Summaries$`Pretty Names`)
Variable.Summaries$`Pretty Names`<-gsub(pattern='zscore.Hegyi',replacement='Hegyi',Variable.Summaries$`Pretty Names`)
Variable.Summaries$`Pretty Names`<-gsub(pattern='BIOMASS_DBH',replacement='DBH',Variable.Summaries$`Pretty Names`)

save(Variable.Summaries,file=paste('./OUTPUT/Cox/Project.HR.model.VariableSummaries_scaledHegyis_noMECH',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))

} else {load('./OUTPUT/Cox/Project.HR.model.VariableSummaries_scaledHegyis_noMECH.20200312.Rdata')}

#STEP 3 - CREATE HAZARD RATIO FUNCTIONS
if (RUN.FUNC.CALC==T){
  
  hazard.calc<-function(units=1,snow.value='mean',watertable.value='mean',richness.value='mean',Deficit.value='mean',Hegyi.het.value='mean',
                        Hegyi.con.value='mean',N.value='mean',P.value='mean',TEB.value='mean',
                        species=c('ABAM','PSME','TABR','TSHE','ACCI'),
                        predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                        tables=c('table.6')){
    HR<-data.frame()
    
    for(k in species){
      for(j in predictors){ 
        if (exists(paste(tables,k,j,sep='.'))){
          mod<-eval(parse(text=paste(tables,k,j,sep='.')))
          rownames(mod)<-mod$predictor
          
          all.pred<-unlist(strsplit(mod$predictor,':',fixed=TRUE))
          all.pred<-unique(all.pred[all.pred!=j])
          
          beta.i<-mod[mod$predictor==j,'beta']
          
          #separate all interactions into component pieces
          if (nrow(mod)>1){
            for(m in mod$predictor){
              bn<-unlist(strsplit(m,':',fixed=TRUE))
              bn<-bn[bn!=j]
              for(o in bn){
                vn<-Variable.Summaries[Variable.Summaries$Species==paste(k,'gen',sep='.')&
                                         Variable.Summaries$`Pretty Names`==o,eval(parse(text=paste(o,'value',sep='.')))] #get min, mean, or max value
                mod[m,paste(o,eval(parse(text=paste(o,'value',sep='.'))),'vn',sep='.')]<-vn
              }
            }
            #multiply interaction beta by value of components
            for(m in mod$predictor){
              mod[m,'multiplier']<-apply(mod[m,!colnames(mod)%in%c('multiplier','predictor')],1,prod,na.rm=T) 
              mod[mod$predictor==j,'multiplier']<-0
            }
            sum.multiplier<-sum(mod$multiplier,na.rm=T)
          } else sum.multiplier=0
          
          HR[paste(k,j,sep='.'),'HR']<-exp(units*(beta.i+sum.multiplier))
        }
      }
    }
    return(HR)
  }
  
  hazard.calc.continuous<-function(units=1,watertable.value='mean',richness.value='mean',Hegyi.het.value='mean',
                                   Hegyi.con.value='mean',N.value='mean',P.value='mean',TEB.value='mean',
                                   species=c('ABAM','PSME','TABR','TSHE','ACCI'),
                                   predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                                   tables=c('table.6'),climate.model=mean.model.lag){
    
    #center in same way as parameterized variables
    centered<-climate.model[-1,]
    defx <- mean(centered[centered$year<2020&centered$year>2011,'Deficit'])
    snowx <- mean(centered[centered$year<2020&centered$year>2011,'snow'])
    centered[4]<-apply(centered[4],2,function(x) x-defx)
    centered[3]<-apply(centered[3],2,function(x) x-snowx)
    
    HR.continuous<-data.frame()
    sum.multiplier.continuous<-data.frame('year'=1951:2099,'sum'=NA)
    years<-c(1951:2099)
    
    for(k in species){
      for(j in predictors){ 
        if (exists(paste(tables,k,j,sep='.'))){
          for (a in years){
            mod.continuous<-eval(parse(text=paste(tables,k,j,sep='.')))
            rownames(mod.continuous)<-mod.continuous$predictor
            
            all.pred.continuous<-unlist(strsplit(mod.continuous$predictor,':',fixed=TRUE))
            all.pred.continuous<-unique(all.pred.continuous[all.pred.continuous!=j])
            
            beta.i.continuous<-mod.continuous[mod.continuous$predictor==j,'beta']
            
            #separate all interactions into component pieces
            if(length(grep('Deficit',all.pred.continuous,value=TRUE,fixed=TRUE)>0)|length(grep('snow',all.pred.continuous,value=TRUE,fixed=TRUE)>0)){
              if (nrow(mod.continuous)>1){
                
                for(m in mod.continuous$predictor){
                  if(m != j){
                    bn.continuous<-unlist(strsplit(m,':',fixed=TRUE))
                    bn.continuous<-bn.continuous[bn.continuous!=j]
                    
                    for(o in bn.continuous){
                      if(o %in% c('Deficit','snow')){
                        vn.continuous<-as.numeric(centered[centered$year==a,o])
                        mod.continuous[m,paste(o,a,'vn',sep='.')]<-vn.continuous
                      } else {
                        vn.continuous<-Variable.Summaries[Variable.Summaries$Species==paste(k,'gen',sep='.')&Variable.Summaries$`Pretty Names`==o,eval(parse(text=paste(o,'value',sep='.')))]
                        mod.continuous[m,paste(o,eval(parse(text=paste(o,'value',sep='.'))),'vn',sep='.')]<-vn.continuous
                        print(paste(a," - ",k,".",o,sep = ''))
                      }
                    }
                    
                    #multiply interaction beta by value of components
                    mod.continuous[m,'multiplier']<-apply(mod.continuous[m,!colnames(mod.continuous)%in%c('multiplier','predictor')],1,prod,na.rm=T) 
                  }
                  
                  mod.continuous[mod.continuous$predictor==j,'multiplier']<-0
                }
                
                sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-sum(mod.continuous$multiplier,na.rm=T)
              } else sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0
              
              if(j == 'Deficit'){
                units = as.numeric(centered[centered$year==a,'Deficit'])
              } else if (j == 'snow'){
                units = as.numeric(centered[centered$year==a,'snow'])
              } else '' 
              
              HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']))
              HR.continuous[paste(k,j,a,sep='.'),'year']<-a
              
            } else {sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']<-0; # 3 new lines here deal with non-climate-interacting predictors
            HR.continuous[paste(k,j,a,sep='.'),'HR']<-exp(units*(beta.i.continuous+sum.multiplier.continuous[sum.multiplier.continuous$year==a,'sum']));
            HR.continuous[paste(k,j,a,sep='.'),'year']<-a}
          }
        }
      }
    }
    return(HR.continuous)
  }
  
  hazard.combos<-function(units=1,possibilities=c('min','mean','max'),
                          species=c('ABAM','PSME','TABR','TSHE','ACCI'),
                          predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                          tables=c('table.6')){
    
    HR<-data.frame('mean.values'=hazard.calc())
    
    for(k in species){
      for(j in predictors){
        args<-list()
        
        if (exists(paste(tables,k,j,sep='.'))){
          mod.combo<-eval(parse(text=paste(tables,k,j,sep='.')))
          rownames(mod.combo)<-mod.combo$predictor
          
          if(nrow(mod.combo)>1){
            pred<-unlist(strsplit(mod.combo$predictor,':',fixed=TRUE))
            pred<-unique(pred[pred!=j])
            names(pred)<-rep(paste(k,j,sep='.'),length(pred))
            
            #run function through all possible combinations of predictors
            if(length(pred)==1){
              for(b in pred[1]){
                for(c in possibilities){
                  args[[paste(b,'.value',sep='')]]<-c
                  args[[paste('species')]]<-k
                  args[[paste('predictors')]]<-j
                  args[[paste('units')]]<-units
                  
                  HR[rownames(HR)==paste(k,j,sep='.'),paste(b,c,sep='.')]<-do.call(hazard.calc,args)$HR
                }
              }
              
            } else if(length(pred)==2){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      if(b != d){
                        print(paste(d,e,sep = '.'))
                        args[[paste(b,'.value',sep='')]]<-c
                        args[[paste(d,'.value',sep='')]]<-e
                        args[[paste('species')]]<-k
                        args[[paste('predictors')]]<-j
                        args[[paste('units')]]<-units
                        
                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==3){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          if(b != d & d != f){
                            print(paste(f,g,sep = '.'))
                            args[[paste(b,'.value',sep='')]]<-c
                            args[[paste(d,'.value',sep='')]]<-e
                            args[[paste(f,'.value',sep='')]]<-g
                            args[[paste('species')]]<-k
                            args[[paste('predictors')]]<-j
                            args[[paste('units')]]<-units
                            
                            HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==4){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              if(b != d & d != f & f != h){
                                print(paste(h,i,sep = '.'))
                                args[[paste(b,'.value',sep='')]]<-c
                                args[[paste(d,'.value',sep='')]]<-e
                                args[[paste(f,'.value',sep='')]]<-g
                                args[[paste(h,'.value',sep='')]]<-i
                                args[[paste('species')]]<-k
                                args[[paste('predictors')]]<-j
                                args[[paste('units')]]<-units
                                
                                HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==5){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  if(b != d & d != f & f != h & h != l){
                                    print(paste(l,m,sep = '.'))
                                    args[[paste(b,'.value',sep='')]]<-c
                                    args[[paste(d,'.value',sep='')]]<-e
                                    args[[paste(f,'.value',sep='')]]<-g
                                    args[[paste(h,'.value',sep='')]]<-i
                                    args[[paste(l,'.value',sep='')]]<-m
                                    args[[paste('species')]]<-k
                                    args[[paste('predictors')]]<-j
                                    args[[paste('units')]]<-units
                                    
                                    HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==6){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  for(n in pred[6]){
                                    for(o in possibilities){
                                      if(b != d & d != f & f != h & h != l & l != n){
                                        print(paste(n,o,sep = '.'))
                                        args[[paste(b,'.value',sep='')]]<-c
                                        args[[paste(d,'.value',sep='')]]<-e
                                        args[[paste(f,'.value',sep='')]]<-g
                                        args[[paste(h,'.value',sep='')]]<-i
                                        args[[paste(l,'.value',sep='')]]<-m
                                        args[[paste(n,'.value',sep='')]]<-o
                                        args[[paste('species')]]<-k
                                        args[[paste('predictors')]]<-j
                                        args[[paste('units')]]<-units
                                        
                                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),paste(n,o,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } 
            } else print(paste('ERROR - number interacting variables > 6'))
          }
        }
      }
    } 
    return(HR)
  }
  
  hazard.combos.timestable<-function(units=1,possibilities=c('min','mean','max'),
                                     species=c('ABAM','PSME','TABR','TSHE','ACCI'),
                                     predictors=c('watertable','richness','Deficit','snow','Hegyi.het', 'Hegyi.con'),
                                     tables=c('table.6')){
    
    HR<-data.frame('mean.values'=hazard.calc())
    
    for(k in species){
      for(j in predictors){
        args<-list()
        
        if (exists(paste(tables,k,j,sep='.'))){
          mod.combo<-eval(parse(text=paste(tables,k,j,sep='.')))
          rownames(mod.combo)<-mod.combo$predictor
          
          if(nrow(mod.combo)>1){
            pred<-unlist(strsplit(mod.combo$predictor,':',fixed=TRUE))
            pred<-unique(pred[pred!=j])
            names(pred)<-rep(paste(k,j,sep='.'),length(pred))
            
            #run function through all possible combinations of predictors
            if(length(pred)==1){
              for(b in pred[1]){
                for(c in possibilities){
                  args[[paste(b,'.value',sep='')]]<-c
                  args[[paste('species')]]<-k
                  args[[paste('predictors')]]<-j
                  args[[paste('units')]]<-units
                  
                  if(is.null(args$snow.value)==F){
                    args$snow.value<-'min'}
                  
                  if(is.null(args$Deficit.value)==F){
                    args$Deficit.value<-'max'}
                  
                  HR[rownames(HR)==paste(k,j,sep='.'),paste(b,c,sep='.')]<-do.call(hazard.calc,args)$HR
                }
              }
              
            } else if(length(pred)==2){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      if(b != d){
                        print(paste(d,e,sep = '.'))
                        args[[paste(b,'.value',sep='')]]<-c
                        args[[paste(d,'.value',sep='')]]<-e
                        args[[paste('species')]]<-k
                        args[[paste('predictors')]]<-j
                        args[[paste('units')]]<-units
                        
                        if(is.null(args$snow.value)==F){
                          args$snow.value<-'min'}
                        
                        if(is.null(args$Deficit.value)==F){
                          args$Deficit.value<-'max'}
                        
                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==3){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          if(b != d & d != f){
                            print(paste(f,g,sep = '.'))
                            args[[paste(b,'.value',sep='')]]<-c
                            args[[paste(d,'.value',sep='')]]<-e
                            args[[paste(f,'.value',sep='')]]<-g
                            args[[paste('species')]]<-k
                            args[[paste('predictors')]]<-j
                            args[[paste('units')]]<-units
                            
                            if(is.null(args$snow.value)==F){
                              args$snow.value<-'min'}
                            
                            if(is.null(args$Deficit.value)==F){
                              args$Deficit.value<-'max'}
                            
                            HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==4){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              if(b != d & d != f & f != h){
                                print(paste(h,i,sep = '.'))
                                args[[paste(b,'.value',sep='')]]<-c
                                args[[paste(d,'.value',sep='')]]<-e
                                args[[paste(f,'.value',sep='')]]<-g
                                args[[paste(h,'.value',sep='')]]<-i
                                args[[paste('species')]]<-k
                                args[[paste('predictors')]]<-j
                                args[[paste('units')]]<-units
                                
                                if(is.null(args$snow.value)==F){
                                  args$snow.value<-'min'}
                                
                                if(is.null(args$Deficit.value)==F){
                                  args$Deficit.value<-'max'}
                                
                                HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==5){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  if(b != d & d != f & f != h & h != l){
                                    print(paste(l,m,sep = '.'))
                                    args[[paste(b,'.value',sep='')]]<-c
                                    args[[paste(d,'.value',sep='')]]<-e
                                    args[[paste(f,'.value',sep='')]]<-g
                                    args[[paste(h,'.value',sep='')]]<-i
                                    args[[paste(l,'.value',sep='')]]<-m
                                    args[[paste('species')]]<-k
                                    args[[paste('predictors')]]<-j
                                    args[[paste('units')]]<-units
                                    
                                    if(is.null(args$snow.value)==F){
                                      args$snow.value<-'min'}
                                    
                                    if(is.null(args$Deficit.value)==F){
                                      args$Deficit.value<-'max'}
                                    
                                    HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              
            } else if(length(pred)==6){
              for(b in pred[1]){
                for(c in possibilities){
                  for(d in pred[2]){
                    for(e in possibilities){
                      for(f in pred[3]){
                        for(g in possibilities){
                          for(h in pred[4]){
                            for(i in possibilities){
                              for(l in pred[5]){
                                for(m in possibilities){
                                  for(n in pred[6]){
                                    for(o in possibilities){
                                      if(b != d & d != f & f != h & h != l & l != n){
                                        print(paste(n,o,sep = '.'))
                                        args[[paste(b,'.value',sep='')]]<-c
                                        args[[paste(d,'.value',sep='')]]<-e
                                        args[[paste(f,'.value',sep='')]]<-g
                                        args[[paste(h,'.value',sep='')]]<-i
                                        args[[paste(l,'.value',sep='')]]<-m
                                        args[[paste(n,'.value',sep='')]]<-o
                                        args[[paste('species')]]<-k
                                        args[[paste('predictors')]]<-j
                                        args[[paste('units')]]<-units
                                        
                                        if(is.null(args$snow.value)==F){
                                          args$snow.value<-'min'}
                                        
                                        if(is.null(args$Deficit.value)==F){
                                          args$Deficit.value<-'max'}
                                        
                                        HR[rownames(HR)==paste(k,j,sep='.'),paste(paste(b,c,sep='.'),paste(d,e,sep='.'),paste(f,g,sep='.'),paste(h,i,sep='.'),paste(l,m,sep='.'),paste(n,o,sep='.'),sep=' : ')]<-do.call(hazard.calc,args)$HR
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } 
            } else print(paste('ERROR - number interacting variables > 6'))
          }
        }
      }
    } 
    return(HR)
  }
  
  save.image(file=paste('./OUTPUT/Cox/Cox.model.HRfunctions',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))
  
} else load('./OUTPUT/Cox/Cox.model.HRfunctions.20200312.Rdata')

#STEP 4 - RUN HAZARD RATIO FUNCTIONS
if (RUN.HR.FUNCS==T){

#means
HR.means<-hazard.calc() 
HR.means$interpedHR<-paste(round((HR.means$HR-1)*100,3),'%')
save(HR.means,file='./OUTPUT/Cox/HR.means.20200312.Rdata')
write.csv(HR.means,file='./OUTPUT/Cox/HR.means.20200312.csv')

#over time
HR.continuous<-hazard.calc.continuous()
save(HR.continuous,file=paste('./OUTPUT/Cox/HR.continuous',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))

#summarize combos per species and determine range of HR values
HR.combos<-hazard.combos()
HR.combos.TS<-hazard.combos.timestable()
save(HR.combos,HR.combos.TS,file=paste('./OUTPUT/Cox/HR.combos',format(Sys.time(),'%Y%m%d'),"Rdata",sep='.'))

} else {load('./OUTPUT/Cox/HR.means.20200312.Rdata');
  load('./OUTPUT/Cox/HR.combos.20200312.Rdata');
  load('./OUTPUT/Cox/HR.continuous.20200312.Rdata')}

#STEP 5 - GET SUMMARIES OF BEST / WORST MICROSITES
if(RUN.COMBO.SUMMARIES==T){
  
species=c('ABAM','PSME','TABR','TSHE','ACCI')
predictors=c('watertable','Deficit','snow','Hegyi.het', 'Hegyi.con')

for(k in species){
  for(j in predictors){
    ttempp<-HR.combos[grep(k,rownames(HR.combos),fixed=TRUE,value=TRUE),]
    temp<-ttempp[grep(paste('.',j,sep = ''),rownames(ttempp),fixed=TRUE,value=TRUE),]
    temp<-temp[,is.na(temp)==F]
    
    if(length(temp)>1){
      if(nrow(temp)>0){
        
        HR.summary<-data.frame('null.value'=temp$HR,'min.value'=min(temp[,-1]),'max.value'=max(temp[,-1]),
                               'min.combo'=colnames(temp[,-1])[which.min(temp[,-1])],'max.combo'=colnames(temp[,-1])[which.max(temp[,-1])])
        
        assign(paste(k,j,sep = '.'),temp)
        assign(paste(k,j,'summary',sep = '.'),HR.summary)
      }
    }
  }
}


for(k in species){
  for(j in predictors){
    ttempp<-HR.combos.TS[grep(k,rownames(HR.combos.TS),fixed=TRUE,value=TRUE),]
    temp<-ttempp[grep(paste('.',j,sep = ''),rownames(ttempp),fixed=TRUE,value=TRUE),]
    temp<-temp[,is.na(temp)==F]
    
    if(length(temp)>1){
      if(nrow(temp)>0){
        
        HR.summary<-data.frame('null.value'=temp$HR,'min.value'=min(temp[,-1]),'max.value'=max(temp[,-1]),
                               'min.combo'=colnames(temp[,-1])[which.min(temp[,-1])],'max.combo'=colnames(temp[,-1])[which.max(temp[,-1])])
        
        assign(paste(k,j,'TS',sep = '.'),temp)
        assign(paste(k,j,'TS.summary',sep = '.'),HR.summary)
      }
    }
  }
}

rm(temp)
rm(ttempp)
rm(tttemppp)
rm(HR.combos)
rm(HR.combos.agt)
rm(HR.combos.rec)
rm(HR.combos.TS)
rm(HR.combos.agt.TS)
rm(HR.combos.rec.TS)
rm(HR.continuous)
rm(HR.continuous.agt)
rm(HR.summary)
rm(RUN.ALL)
rm(RUN.BETAS)
rm(RUN.FUNC.CALC)
rm(RUN.PRISM.SUMMARY)
rm(RUN.VAR.SUMMARY)
rm(LOAD.CLIMATE)
rm(h)
rm(j)
rm(k)
rm(right)
rm(theme_prefs)
rm(HR.agt.means)
rm(HR.continuous.rec)
rm(HR.means)
rm(HR.rec.means)
rm(log.combos)
rm(log.means)

save.image('./OUTPUT/Cox/Hazard.Combos.and.Projection.Summaries.20200312.Rdata')


} else {load('./OUTPUT/Cox/Hazard.Combos.and.Projection.Summaries.20200312.Rdata')}

#STEP 6 - PLUG IN MIN/MEAN/MAX RATIOS TO CLIMATE PROJECTIONS
if(RUN.PERMUTATIONS==T){
  
  ###### MORTALITY ########-
  {
    
    # #USING MEANS
    {
      ## DiRECT CLiMATE EFFECTS ##
      {   
        #######-
        ABAM.Deficit.mean<-hazard.calc.continuous(species = 'ABAM',predictors = 'Deficit',climate.model = mean.model.lag)
        ABAM.Deficit.mean1<-hazard.calc.continuous(species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        ABAM.Deficit.mean2<-hazard.calc.continuous(species = 'ABAM',predictors = 'Deficit',climate.model = ccsm4.lag)
        ABAM.Deficit.mean3<-hazard.calc.continuous(species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        ABAM.Deficit.mean4<-hazard.calc.continuous(species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        ABAM.Deficit.mean5<-hazard.calc.continuous(species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        ABAM.Deficit.mean6<-hazard.calc.continuous(species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        #######-
        PSME.Deficit.mean<-hazard.calc.continuous(species = 'PSME',predictors = 'Deficit',climate.model = mean.model.lag)
        PSME.Deficit.mean1<-hazard.calc.continuous(species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        PSME.Deficit.mean2<-hazard.calc.continuous(species = 'PSME',predictors = 'Deficit',climate.model = ccsm4.lag)
        PSME.Deficit.mean3<-hazard.calc.continuous(species = 'PSME',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        PSME.Deficit.mean4<-hazard.calc.continuous(species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        PSME.Deficit.mean5<-hazard.calc.continuous(species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        PSME.Deficit.mean6<-hazard.calc.continuous(species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        #######-
        TABR.Deficit.mean<-hazard.calc.continuous(species = 'TABR',predictors = 'Deficit',climate.model = mean.model.lag)
        TABR.Deficit.mean1<-hazard.calc.continuous(species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        TABR.Deficit.mean2<-hazard.calc.continuous(species = 'TABR',predictors = 'Deficit',climate.model = ccsm4.lag)
        TABR.Deficit.mean3<-hazard.calc.continuous(species = 'TABR',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        TABR.Deficit.mean4<-hazard.calc.continuous(species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        TABR.Deficit.mean5<-hazard.calc.continuous(species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        TABR.Deficit.mean6<-hazard.calc.continuous(species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        #######-
        TSHE.Deficit.mean<-hazard.calc.continuous(species = 'TSHE',predictors = 'Deficit',climate.model = mean.model.lag)
        TSHE.Deficit.mean1<-hazard.calc.continuous(species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        TSHE.Deficit.mean2<-hazard.calc.continuous(species = 'TSHE',predictors = 'Deficit',climate.model = ccsm4.lag)
        TSHE.Deficit.mean3<-hazard.calc.continuous(species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        TSHE.Deficit.mean4<-hazard.calc.continuous(species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        TSHE.Deficit.mean5<-hazard.calc.continuous(species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        TSHE.Deficit.mean6<-hazard.calc.continuous(species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        #######-
        ACCI.Deficit.mean<-hazard.calc.continuous(species = 'ACCI',predictors = 'Deficit',climate.model = mean.model.lag)
        ACCI.Deficit.mean1<-hazard.calc.continuous(species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        ACCI.Deficit.mean2<-hazard.calc.continuous(species = 'ACCI',predictors = 'Deficit',climate.model = ccsm4.lag)
        ACCI.Deficit.mean3<-hazard.calc.continuous(species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        ACCI.Deficit.mean4<-hazard.calc.continuous(species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        ACCI.Deficit.mean5<-hazard.calc.continuous(species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        ACCI.Deficit.mean6<-hazard.calc.continuous(species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
      }
      
      ## AGENT GENERIC
      {
        ABAM.Hegyi.con.means<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ABAM.Hegyi.het.means<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ABAM.Hegyi.con.means1<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ABAM.Hegyi.het.means1<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ABAM.Hegyi.con.means2<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.het.means2<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ABAM.Hegyi.con.means3<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.het.means3<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ABAM.Hegyi.con.means4<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.het.means4<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ABAM.Hegyi.con.means5<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.het.means5<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ABAM.Hegyi.con.means6<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.het.means6<-hazard.calc.continuous(species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        TSHE.Hegyi.con.means<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TSHE.Hegyi.het.means<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TSHE.Hegyi.con.means1<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TSHE.Hegyi.het.means1<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TSHE.Hegyi.con.means2<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.het.means2<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TSHE.Hegyi.con.means3<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.het.means3<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TSHE.Hegyi.con.means4<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.het.means4<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TSHE.Hegyi.con.means5<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.het.means5<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TSHE.Hegyi.con.means6<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.het.means6<-hazard.calc.continuous(species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        PSME.Hegyi.con.means<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        PSME.Hegyi.het.means<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        PSME.Hegyi.con.means1<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        PSME.Hegyi.het.means1<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        PSME.Hegyi.con.means2<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.het.means2<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        PSME.Hegyi.con.means3<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.het.means3<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        PSME.Hegyi.con.means4<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.het.means4<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        PSME.Hegyi.con.means5<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.het.means5<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        PSME.Hegyi.con.means6<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        PSME.Hegyi.het.means6<-hazard.calc.continuous(species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        TABR.Hegyi.con.means<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TABR.Hegyi.het.means<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TABR.Hegyi.con.means1<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TABR.Hegyi.het.means1<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TABR.Hegyi.con.means2<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.het.means2<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TABR.Hegyi.con.means3<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.het.means3<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TABR.Hegyi.con.means4<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.het.means4<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TABR.Hegyi.con.means5<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.het.means5<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TABR.Hegyi.con.means6<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TABR.Hegyi.het.means6<-hazard.calc.continuous(species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        ACCI.Hegyi.con.means<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ACCI.Hegyi.het.means<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ACCI.Hegyi.con.means1<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ACCI.Hegyi.het.means1<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ACCI.Hegyi.con.means2<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.het.means2<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ACCI.Hegyi.con.means3<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.het.means3<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ACCI.Hegyi.con.means4<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.het.means4<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ACCI.Hegyi.con.means5<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.het.means5<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ACCI.Hegyi.con.means6<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.het.means6<-hazard.calc.continuous(species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
      }
      
    }
    
    #USING MIN AND MAX
    {
      ## DiRECT CLiMATE EFFECTS ##
      {   
        ABAM.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = mean.model.lag)
        ABAM.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = mean.model.lag)
        
        ABAM.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = ccsm4.lag)
        ABAM.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        ABAM.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        ABAM.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        ABAM.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        ABAM.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        ABAM.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        ABAM.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        ABAM.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        ABAM.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        ABAM.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        ABAM.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        ####
        
        TABR.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = mean.model.lag)
        TABR.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = mean.model.lag)
        
        TABR.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = ccsm4.lag)
        TABR.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        TABR.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        TABR.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        TABR.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        TABR.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        TABR.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        TABR.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        TABR.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        TABR.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        TABR.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        TABR.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        ########-
        TSHE.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = mean.model.lag)
        TSHE.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = mean.model.lag)
        
        TSHE.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = ccsm4.lag)
        TSHE.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        TSHE.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        TSHE.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        TSHE.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        TSHE.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        TSHE.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        TSHE.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        TSHE.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        TSHE.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        TSHE.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        TSHE.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        ########-
        
        PSME.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = mean.model.lag)
        PSME.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = mean.model.lag)
        
        PSME.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = ccsm4.lag)
        PSME.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        PSME.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        PSME.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        PSME.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        PSME.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        PSME.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        PSME.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        PSME.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        PSME.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        PSME.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        PSME.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
        
        #######-
        
        ACCI.Deficit.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = mean.model.lag)
        ACCI.Deficit.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = mean.model.lag)
        
        ACCI.Deficit.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = ccsm4.lag)
        ACCI.Deficit.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = ccsm4.lag)
        
        ACCI.Deficit.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        ACCI.Deficit.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.cm3.lag)
        
        ACCI.Deficit.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        ACCI.Deficit.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2g.lag)
        
        ACCI.Deficit.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        ACCI.Deficit.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = gfdl.esm2m.lag)
        
        ACCI.Deficit.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        ACCI.Deficit.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.cc.lag)
        
        ACCI.Deficit.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        ACCI.Deficit.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Deficit',climate.model = hadgem2.es.lag)
        
      }
      
      ## AGENT GENERIC ##
      {
        # possible<-c('mean.model.lag','ccsm4.lag','gfdl.cm3.lag','gfdl.esm2g.lag','gfdl.esm2m.lag','hadgem2.cc.lag','hadgem2.es.lag')
        ABAM.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ABAM.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ABAM.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        ABAM.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ABAM.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ABAM.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ABAM.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        ABAM.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ABAM.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        ABAM.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ABAM.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        ABAM.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ABAM.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        ABAM.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ABAM.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        ABAM.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ABAM.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        ABAM.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ABAM',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ####
        
        TABR.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TABR.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TABR.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        TABR.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TABR.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TABR.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TABR.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        TABR.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TABR.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        TABR.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TABR.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        TABR.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TABR.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        TABR.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TABR.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min', species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        TABR.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TABR.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TABR.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TABR',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TABR.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        TABR.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max', species = 'TABR',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ########-
        TSHE.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TSHE.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        TSHE.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        TSHE.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        TSHE.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TSHE.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        TSHE.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        TSHE.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        TSHE.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        TSHE.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        TSHE.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        TSHE.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        TSHE.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        TSHE.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        TSHE.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        TSHE.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        TSHE.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        TSHE.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'TSHE',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        ########-
        
        PSME.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        PSME.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        PSME.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        PSME.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        PSME.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        PSME.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        PSME.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        PSME.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        PSME.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        PSME.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        PSME.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        PSME.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        PSME.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        PSME.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        PSME.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        PSME.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        PSME.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        PSME.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        PSME.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        PSME.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'PSME',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
        
        #######-
        
        ACCI.Hegyi.con.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ACCI.Hegyi.con.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = mean.model.lag)
        ACCI.Hegyi.het.max<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        ACCI.Hegyi.het.min<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = mean.model.lag)
        
        ACCI.Hegyi.con.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ACCI.Hegyi.con.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = ccsm4.lag)
        ACCI.Hegyi.het.max1<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        ACCI.Hegyi.het.min1<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = ccsm4.lag)
        
        ACCI.Hegyi.con.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.con.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.het.max2<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        ACCI.Hegyi.het.min2<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.cm3.lag)
        
        ACCI.Hegyi.con.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.con.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.het.max3<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        ACCI.Hegyi.het.min3<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2g.lag)
        
        ACCI.Hegyi.con.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.con.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.het.max4<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        ACCI.Hegyi.het.min4<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = gfdl.esm2m.lag)
        
        ACCI.Hegyi.con.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.con.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.het.max5<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        ACCI.Hegyi.het.min5<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.cc.lag)
        
        ACCI.Hegyi.con.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.con.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.con',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.het.max6<-hazard.calc.continuous(watertable.value = 'max',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        ACCI.Hegyi.het.min6<-hazard.calc.continuous(watertable.value = 'min',species = 'ACCI',predictors = 'Hegyi.het',climate.model = hadgem2.es.lag)
        
      }
      
    }
    
  }
  
  save.image(file='./OUTPUT/Cox/Min.max.permutations.mort.20200312.Rdata') #workspace image with climate and all 6 steps

} else load('./OUTPUT/Cox/Min.max.permutations.mort.20200312.Rdata')


###############################################################################################################################################################

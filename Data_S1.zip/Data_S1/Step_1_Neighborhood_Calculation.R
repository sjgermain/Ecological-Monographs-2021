## Wind River Stability - Survival Analysis ##
## Sara Germain ##
## March 2021 ##


## note: this is computationally intensive and on the clunky side. Please see Germain/Ecology-2021 code for more refined methods to calculate neighborhoods ##

setwd("WFDP_Demography_20200303")


##############################################################################################################################################-
##############################################              LIBRARIES AND FUNCTIONS              #############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

distance = function(focal.x,focal.y,other.x,other.y){
  return(sqrt((focal.x-other.x)^2+(focal.y-other.y)^2))
}
BA.function = function(tree.DBH){
  return(0.0001*(pi*((0.5*tree.DBH)^2)))
}
mround<-function(x,base){
  base*round((x-(base/2-0.1))/base)
}

#calculate neighborhood influence values for each stem
hegyi <- function(focal.DBH, neighbor.DBH, distance){
  return(neighbor.DBH/(focal.DBH*(1+distance)))
}

#standardizing function for species-specific influences
stand = function(focal.influence,mean.influence,sd.influence){
  (focal.influence-mean.influence)/sd.influence
}

#centering function
center = function(focal.influence,mean.influence){
  focal.influence-mean.influence
}

##############################################################################################################################################

##############################################################################################################################################-
################################################              CREATE BASELINE DATA            ################################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

tree<-read.csv("./DATA/WFDP_Tree_20200305.csv", na.strings='NULL') #SQL code = SELECT STEM_TAG, TREE_TAG, CENSUS, DATE, DBH_DATE, IN_YR, QUADRAT, SPECIES, DBH, GROWTH_DBH, BIOMASS_DBH, STATUS, MORT_DATE, VIGOR, DA, SC, SNAG_HEIGHT, SNAG_TD, PLOT_X, PLOT_Y, UTM_X, UTM_Y, RELATIVE_PLOT_X, RELATIVE_PLOT_Y, COMMENT, NURSE_LOG, ES, MT, LEANER_ANGLE FROM `Tree` WHERE QUADRAT not like 'Q%'
tree[tree$CENSUS>17,"BIOMASS_DBH"] <- tree[tree$CENSUS>17,"DBH"]
tree<-tree[is.na(tree$BIOMASS_DBH)==F&is.na(tree$SPECIES)==F&is.na(tree$PLOT_X)==F&is.na(tree$PLOT_Y)==F,]

tree<-tree[tree$CENSUS>=17,]

n.tree<-nrow(tree)

dist.threshold.fixed<-10


### Mirror trees near edge of plot to correct for edge effects
tree.mirror<-tree[tree$PLOT_X<(0+dist.threshold.fixed),]
tree.mirror$PLOT_X<-tree.mirror$PLOT_X*-1
tree<-rbind(tree,tree.mirror)

tree.mirror<-tree[tree$PLOT_Y<(0+dist.threshold.fixed),]
tree.mirror$PLOT_Y<-tree.mirror$PLOT_Y*-1
tree<-rbind(tree,tree.mirror)

tree.mirror<-tree[tree$PLOT_X>(800-dist.threshold.fixed),]
tree.mirror$PLOT_X<-(800-tree.mirror$PLOT_X)+800
tree<-rbind(tree,tree.mirror)

tree.mirror<-tree[tree$PLOT_Y>(320-dist.threshold.fixed),]
tree.mirror$PLOT_Y<-(320-tree.mirror$PLOT_Y)+320
tree<-rbind(tree,tree.mirror)

plot(tree[tree$PLOT_X<=(0+dist.threshold.fixed)|tree$PLOT_X>(800-dist.threshold.fixed)|
            tree$PLOT_Y<=(0+dist.threshold.fixed)|tree$PLOT_Y>(320-dist.threshold.fixed),c('PLOT_X','PLOT_Y')])
plot(tree$PLOT_X,tree$PLOT_Y)

plot(x=0,y=0,type='n',xlim=c(-20,820),ylim=c(-20,340),ann=F)


##############################################################################################################################################

##############################################################################################################################################-
############################################                    FIND NEIGHBORS                 ###############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------


#### FIND NEIGHBORS FOR EACH TREE ####-
{
  start.row<-1
  for(h in c((1:(n.tree/200))*200,n.tree)){
    end.row<-h
    print(paste("start =",start.row))
    print(paste("end =",end.row))
    
    neighbors<-data.frame('FOCAL.STEM'=NA,'NEIGHBOR.STEM'=NA,'BIOMASS_DBH'=NA,'SPECIES'=NA,'STATUS'=NA,'MORT_DATE'=NA,'PITH.DISTANCE'=NA,'FACE.DISTANCE'=NA)
    neighbors<-neighbors[is.na(neighbors$FOCAL.STEM)==F,]
    neighbors$SPECIES<-factor(neighbors$SPECIES,levels=levels(tree$SPECIES))
    neighbors[,'FOCAL.STEM']<-factor(neighbors[,'FOCAL.STEM'],levels=levels(tree$STEM_TAG))
    neighbors[,'NEIGHBOR.STEM']<-factor(neighbors[,'NEIGHBOR.STEM'],levels=levels(tree$STEM_TAG))
    
    for(i in start.row:end.row){
      start<-Sys.time()
      #SUBSET TREE LIST TO SELECT TREES WITHIN DISTANCE OF +- dist.threshold OF FOCAL TREE PLOT_X AND PLOT_Y
      zone<-c(tree[i,c('PLOT_X','PLOT_Y')]+dist.threshold.fixed,tree[i,c('PLOT_X','PLOT_Y')]-dist.threshold.fixed)
      zone.trees<-tree[tree$PLOT_X<zone[1]&tree$PLOT_X>zone[3]&tree$PLOT_Y<zone[2]&tree$PLOT_Y>zone[4],]
      #CALCULATE EUCLIDIAN DISTANCE BETWEEN FOCAL TREE AND NEIGHBORS
      #GENERATE TREE LIST OF TREES WITHIN RADIUS OF dist.threshold AROUND FOCAL TREE
      focal.neighbors<-data.frame()
      
      neighbor.distances<-distance(tree[i,'PLOT_X'],tree[i,'PLOT_Y'],zone.trees[,'PLOT_X'],zone.trees[,'PLOT_Y'])
      
      focal.neighbors<-data.frame(zone.trees[,c('STEM_TAG','BIOMASS_DBH','SPECIES','STATUS','MORT_DATE')],"PITH.DISTANCE"=neighbor.distances,
                                  "FACE.DISTANCE"=neighbor.distances-tree[i,'BIOMASS_DBH']/200-zone.trees[,'BIOMASS_DBH']/200)
      
      focal.neighbors<-focal.neighbors[focal.neighbors$FACE.DISTANCE>0&focal.neighbors$PITH.DISTANCE<=dist.threshold.fixed&
                                         focal.neighbors$STEM_TAG!=tree[i,'STEM_TAG'],]
      
      #INSERT THIS TREE LIST INTO A MASTER NEIGHBOR DATA FRAME THAT WILL INCLUDE ALL NEIGHBORS FOR ALL TREES
      first.row<-nrow(neighbors)+1
      last.row<-first.row+nrow(focal.neighbors)-1
      neighbors[first.row:last.row,'FOCAL.STEM']<-tree[i,'STEM_TAG']
      neighbors[first.row:last.row,2:(ncol(focal.neighbors)+1)]<-focal.neighbors
      focal.dbh<-tree[tree$STEM_TAG==neighbors[first.row,'FOCAL.STEM'],'BIOMASS_DBH'][1]
      neighbors[first.row:last.row,'HEGYI']<-hegyi(focal.dbh,focal.neighbors$BIOMASS_DBH,focal.neighbors$FACE.DISTANCE)
      
      #PRINT STEM_TAG BEING PROCESSED AND REMAINING TIME
      elapse<-as.numeric(Sys.time()-start)
      print(paste('Calculating distances for ',tree[i,'STEM_TAG'],sep=''))
      print(paste("Time remaining: ",round(elapse*(n.tree-h),0)," minutes. Nice work!",sep=''))
      if(nrow(neighbors)>100000) stop("error: nrow neighbors is over 100000")
    }
    
    #---------------------------------------------------------------------#
    write.csv(x=neighbors,file=paste('./OUTPUT/Neighborhood/neighbors_',h,'_',format(Sys.time(),'%Y%m%d'),'.csv',sep=''))
    #---------------------------------------------------------------------#
    
    points(tree[start.row:end.row,c('PLOT_X','PLOT_Y')],pch=19)
    # Clear RAM:
    rm(neighbors)
    gc()
    memory.size()
    start.row<-h+1
  }
}

#### CREATE FULL NEIGHBORHOODS FOR EACH TREE ####-
{
  neighbors<-data.frame()
  first<-1
  for(j in c(seq(50,length(dir('./OUTPUT/Neighborhood/')),25),length(dir('./OUTPUT/Neighborhood/')))){
    last<-j
    for (i in dir('./OUTPUT/Neighborhood/')[first:last]){
      temp<-read.csv(paste('./OUTPUT/Neighborhood/',i,sep=''))
      if(nrow(temp[as.character(temp$FOCAL.STEM)%in%as.character(neighbors$FOCAL.STEM)==T,])>=1) stop('error: repeated stem tags')
      temp$FOCAL.STEM<-as.character(temp$FOCAL.STEM)
      temp$NEIGHBOR.STEM<-as.character(temp$NEIGHBOR.STEM)
      neighbors<-rbind(neighbors,temp)
      print(i)
    }
    gc()
    memory.size()
    first<-j+1
  }
  head(neighbors)
  
  #---------------------------------------------------------------------#
  write.csv(x=neighbors,file=paste('./OUTPUT/Neighborhood/neighbors_full_',format(Sys.time(),'%Y%m%d'),'.csv',sep=''))
  #---------------------------------------------------------------------#
}


##############################################################################################################################################

##############################################################################################################################################-
############################################                CALCULATE NEIGHBORHOODS             ##############################################-
#---------------------------------------------------------------------------------------------------------------------------------------------

tree<-read.csv("./DATA/WFDP_Tree_20200303.csv", na.strings='NULL') #SQL code = SELECT STEM_TAG, TREE_TAG, CENSUS, DATE, DBH_DATE, IN_YR, QUADRAT, SPECIES, DBH, GROWTH_DBH, BIOMASS_DBH, STATUS, MORT_DATE, VIGOR, DA, SC, SNAG_HEIGHT, SNAG_TD, PLOT_X, PLOT_Y, UTM_X, UTM_Y, RELATIVE_PLOT_X, RELATIVE_PLOT_Y, COMMENT, NURSE_LOG, ES, MT, LEANER_ANGLE FROM `Tree` WHERE QUADRAT not like 'Q%'
tree[tree$CENSUS>17,"BIOMASS_DBH"] <- tree[tree$CENSUS>17,"DBH"]
tree<-tree[is.na(tree$BIOMASS_DBH)==F&is.na(tree$SPECIES)==F&is.na(tree$PLOT_X)==F&is.na(tree$PLOT_Y)==F,]
tree<-tree[tree$CENSUS>=17,]
tree$BA<- BA.function(tree$BIOMASS_DBH)
tree[duplicated(tree$STEM_TAG),] # this needs to be ZERO!!!!! if not, figure it out (usually a multiple census issue - this code calculates neighbors for 1 census)


plot(x=0,y=0,type='n',xlim=c(-20,820),ylim=c(-20,340),ann=F)
colors<-colorRampPalette(c('darkgreen','green','yellow','orange','red','darkred'))(340)


#### CREATE VARIABLES FOR CROWDING 
for(i in 1:nrow(tree)){  
  focal.tree.mort.date<-ifelse(is.na(tree[i,'MORT_DATE'])==T,2018,tree[i,'MORT_DATE'])
  if(tree[i,'MORT_DATE']==0&is.na(tree[i,'MORT_DATE'])==F) focal.tree.mort.date<-2011
  live.neighborhood<-neighbors[neighbors$FOCAL.STEM==as.character(tree[i,'STEM_TAG'])&(neighbors$MORT_DATE>=focal.tree.mort.date|is.na(neighbors$MORT_DATE)==T),2:ncol(neighbors)]
  snag.neighborhood<-neighbors[neighbors$FOCAL.STEM==as.character(tree[i,'STEM_TAG'])&neighbors$MORT_DATE<focal.tree.mort.date&is.na(neighbors$MORT_DATE)==F,2:ncol(neighbors)]
  
  tree[i,'Neighbors.richness']<-length(unique(live.neighborhood$SPECIES))
  tree[i,'Conspecific_ratio']<-(nrow(live.neighborhood[live.neighborhood$SPECIES==tree[i,'SPECIES'],])/(nrow(live.neighborhood[live.neighborhood$SPECIES!=tree[i,'SPECIES'],])))
  tree[i,'N.conspecific.neighbors']<-nrow(live.neighborhood[live.neighborhood$SPECIES==tree[i,'SPECIES'],])
  tree[i,'N.hetspecific.neighbors']<-nrow(live.neighborhood[live.neighborhood$SPECIES!=tree[i,'SPECIES'],])
  
  tree[i,'Nearest.live.neighbor']<-round(min(live.neighborhood$PITH.DISTANCE),2)
  tree[i,'Nearest.snag.neighbor']<-round(min(snag.neighborhood$PITH.DISTANCE),2)
  
  tree[i,'N.snag.neighbors']<-nrow(snag.neighborhood)
  tree[i,'N.snag.neighbors.within.1m']<-nrow(snag.neighborhood[snag.neighborhood$PITH.DISTANCE<1,])
  tree[i,'N.snag.neighbors.within.3m']<-nrow(snag.neighborhood[snag.neighborhood$PITH.DISTANCE<3,])
  
  tree[i,'N.neighbors']<-nrow(live.neighborhood)
  tree[i,'N.neighbors.10m']<-nrow(live.neighborhood[live.neighborhood$PITH.DISTANCE<10,])
  tree[i,'N.neighbors.5m']<-nrow(live.neighborhood[live.neighborhood$PITH.DISTANCE<5,])
  tree[i,'N.neighbors.1m']<-nrow(live.neighborhood[live.neighborhood$PITH.DISTANCE<1,])
  tree[i,'N.neighbors.50cm']<-nrow(live.neighborhood[live.neighborhood$PITH.DISTANCE<0.5,])
  
  tree[i,'BA.50cm.neighbors']<-sum(live.neighborhood[live.neighborhood$FACE.DISTANCE<=0.5,'BA'])
  tree[i,'BA.1.neighbors']<-sum(live.neighborhood[live.neighborhood$FACE.DISTANCE<=1,'BA'])
  tree[i,'BA.5.neighbors']<-sum(live.neighborhood[live.neighborhood$FACE.DISTANCE<=5,'BA'])
  tree[i,'BA.10.neighbors']<-sum(live.neighborhood[live.neighborhood$FACE.DISTANCE<=10,'BA'])

  tree[i,'live.HEGYI']<-sum(live.neighborhood$HEGYI)
  tree[i,'all.HEGYI']<-sum(neighbors$HEGYI)
  tree[i,'HEGYI.con']<-sum(live.neighborhood[live.neighborhood$SPECIES==tree[i,'SPECIES'],'HEGYI'])
  tree[i,'HEGYI.het']<-sum(live.neighborhood[live.neighborhood$SPECIES!=tree[i,'SPECIES'],'HEGYI'])
  tree[i,'HEGYI.ratio']<-sum(live.neighborhood[live.neighborhood$SPECIES==tree[i,'SPECIES'],'HEGYI'])/sum(live.neighborhood[live.neighborhood$SPECIES!=tree[i,'SPECIES'],'HEGYI'])
  
  tree[i,'N.neighbors.1.to.5.cm.dbh']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=1&live.neighborhood$BIOMASS_DBH<5,])
  tree[i,'N.neighbors.5.to.10.cm.dbh']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=5&live.neighborhood$BIOMASS_DBH<10,])
  tree[i,'N.neighbors.10.to.20.cm.dbh']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=10&live.neighborhood$BIOMASS_DBH<20,])
  tree[i,'N.neighbors.20.to.40.cm.dbh']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=20&live.neighborhood$BIOMASS_DBH<40,])
  tree[i,'N.neighbors.40.to.60.cm.dbh']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=40&live.neighborhood$BIOMASS_DBH<60,])
  tree[i,'N.neighbors.gt.60.cm.dbh']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=60,])
  tree[i,'N.neighbors.gt.100.cm.dbh']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=100,])
  
  tree[i,'N.neighbors.1.to.5.cm.dbh.within.5m']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=1&live.neighborhood$BIOMASS_DBH<5&live.neighborhood$PITH.DISTANCE<5,])
  tree[i,'N.neighbors.5.to.10.cm.dbh.within.5m']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=5&live.neighborhood$BIOMASS_DBH<10&live.neighborhood$PITH.DISTANCE<5,])
  tree[i,'N.neighbors.10.to.20.cm.dbh.within.5m']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=10&live.neighborhood$BIOMASS_DBH<20&live.neighborhood$PITH.DISTANCE<5,])
  tree[i,'N.neighbors.20.to.40.cm.dbh.within.5m']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=20&live.neighborhood$BIOMASS_DBH<40&live.neighborhood$PITH.DISTANCE<5,])
  tree[i,'N.neighbors.40.to.60.cm.dbh.within.5m']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=40&live.neighborhood$BIOMASS_DBH<60&live.neighborhood$PITH.DISTANCE<5,])
  tree[i,'N.neighbors.gt.60.cm.dbh.within.5m']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=60&live.neighborhood$PITH.DISTANCE<5,])
  tree[i,'N.neighbors.gt.100.cm.dbh.within.5m']<-nrow(live.neighborhood[live.neighborhood$BIOMASS_DBH>=100&live.neighborhood$PITH.DISTANCE<5,])
  
  print(as.character(tree[i,'STEM_TAG']))
  
  if(i %in% seq(0,40000,1000)) points(tree[1:i,c('PLOT_X','PLOT_Y')],pch=19,col=colors[tree[1:i,'N.neighbors']])
}


#### CREATE VARIABLES FOR CROWDING that are STANDARDIZED and CENTERED by SPECIES AND DIAMETER

# diameter bins
tree$DBH_BIN<-mround(tree$BIOMASS_DBH,2)
tree[tree$BIOMASS_DBH>=10,'DBH_BIN']<-mround(tree[tree$BIOMASS_DBH>=10,'DBH_BIN'],10)
tree[tree$BIOMASS_DBH>=40,'DBH_BIN']<-mround(tree[tree$BIOMASS_DBH>=40,'DBH_BIN'],20)
tree[tree$BIOMASS_DBH>=100,'DBH_BIN']<-100

tree[is.na(tree$live.HEGYI)==T,'live.HEGYI']<-0
tree[is.na(tree$HEGYI.con)==T,'HEGYI.con']<-0
tree[is.na(tree$HEGYI.het)==T,'HEGYI.het']<-0
tree[is.na(tree$HEGYI.ratio)==T,'HEGYI.ratio']<-0


# get hegyi mean / sd for standardizing hegyi by spp / size class
tree.gr.summary1<-aggregate(tree$live.HEGYI,by=list(tree$SPECIES,tree$DBH_BIN),FUN=sd)
tree.gr.summary1$count<-aggregate(tree$live.HEGYI,by=list(tree$SPECIES,tree$DBH_BIN),FUN=NROW)$x
tree.gr.summary2<-aggregate(tree$live.HEGYI,by=list(tree$SPECIES,tree$DBH_BIN),FUN=mean)
tree.gr.summary<-merge(tree.gr.summary1,tree.gr.summary2, by=c('Group.1','Group.2'))

for(j in 1:nrow(tree)){
  tree[j,'sd.Hegyi'] <- tree.gr.summary[tree.gr.summary$Group.1==tree[j,'SPECIES']&tree.gr.summary$Group.2==tree[j,'DBH_BIN'],'x.x']
  tree[j,'mean.Hegyi'] <- tree.gr.summary[tree.gr.summary$Group.1==tree[j,'SPECIES']&tree.gr.summary$Group.2==tree[j,'DBH_BIN'],'x.y']
  tree[j,'zscore.Hegyi'] <-  stand(tree[j,'live.HEGYI'],tree[j,'mean.Hegyi'],tree[j,'sd.Hegyi'])
}


# get hegyi.con mean / sd for standardizing hegyi by spp / size class???
tree.gr.summary1<-aggregate(tree$HEGYI.con,by=list(tree$SPECIES,tree$DBH_BIN),FUN=sd)
tree.gr.summary1$count<-aggregate(tree$HEGYI.con,by=list(tree$SPECIES,tree$DBH_BIN),FUN=NROW)$x
tree.gr.summary2<-aggregate(tree$HEGYI.con,by=list(tree$SPECIES,tree$DBH_BIN),FUN=mean)
tree.gr.summary<-merge(tree.gr.summary1,tree.gr.summary2, by=c('Group.1','Group.2')) 

for(j in 1:nrow(tree)){  
  tree[j,'sd.Hegyi.con'] <- tree.gr.summary[tree.gr.summary$Group.1==tree[j,'SPECIES']&tree.gr.summary$Group.2==tree[j,'DBH_BIN'],'x.x']
  tree[j,'mean.Hegyi.con'] <- tree.gr.summary[tree.gr.summary$Group.1==tree[j,'SPECIES']&tree.gr.summary$Group.2==tree[j,'DBH_BIN'],'x.y']
  # tree[j,'zscore.Hegyi.con'] <-  stand(tree[j,'HEGYI.con'],tree[j,'mean.Hegyi.con'],tree[j,'sd.Hegyi.con'])
  tree[j,'zscore.Hegyi.con'] <-  stand(tree[j,'HEGYI.con'],tree[j,'mean.Hegyi.con'],tree[j,'sd.Hegyi'])
  tree[j,'center.Hegyi.con'] <-  center(tree[j,'HEGYI.con'],tree[j,'mean.Hegyi.con'])
  
}  


# get hegyi.het mean / sd for standardizing hegyi by spp / size class???
tree.gr.summary1<-aggregate(tree$HEGYI.het,by=list(tree$SPECIES,tree$DBH_BIN),FUN=sd)
tree.gr.summary1$count<-aggregate(tree$HEGYI.het,by=list(tree$SPECIES,tree$DBH_BIN),FUN=NROW)$x
tree.gr.summary2<-aggregate(tree$HEGYI.het,by=list(tree$SPECIES,tree$DBH_BIN),FUN=mean)
tree.gr.summary<-merge(tree.gr.summary1,tree.gr.summary2, by=c('Group.1','Group.2')) 

for(j in 1:nrow(tree)){  
  tree[j,'sd.Hegyi.het'] <- tree.gr.summary[tree.gr.summary$Group.1==tree[j,'SPECIES']&tree.gr.summary$Group.2==tree[j,'DBH_BIN'],'x.x']
  tree[j,'mean.Hegyi.het'] <- tree.gr.summary[tree.gr.summary$Group.1==tree[j,'SPECIES']&tree.gr.summary$Group.2==tree[j,'DBH_BIN'],'x.y']
  # tree[j,'zscore.Hegyi.het'] <-  stand(tree[j,'HEGYI.het'],tree[j,'mean.Hegyi.het'],tree[j,'sd.Hegyi.het'])
  tree[j,'zscore.Hegyi.het'] <-  stand(tree[j,'HEGYI.het'],tree[j,'mean.Hegyi.het'],tree[j,'sd.Hegyi'])
  tree[j,'center.Hegyi.het'] <-  center(tree[j,'HEGYI.het'],tree[j,'mean.Hegyi.het'])
  
}  


tree[is.na(tree$zscore.Hegyi)==T,'zscore.Hegyi']<-0
tree[is.na(tree$zscore.Hegyi.con)==T,'zscore.Hegyi.con']<-0
tree[is.na(tree$zscore.Hegyi.het)==T,'zscore.Hegyi.het']<-0
tree[is.na(tree$center.Hegyi.con)==T,'center.Hegyi.con']<-0
tree[is.na(tree$center.Hegyi.het)==T,'center.Hegyi.het']<-0

tree$scaled.Hegyi.con <- tree$center.Hegyi.con / sd(tree$live.HEGYI)
tree$scaled.Hegyi.het <- tree$center.Hegyi.het / sd(tree$live.HEGYI)

tree[is.na(tree$scaled.Hegyi.con)==T,'scaled.Hegyi.con']<-0
tree[is.na(tree$scaled.Hegyi.het)==T,'scaled.Hegyi.het']<-0

trees<-merge(tree,tree.backup[,c('STEM_TAG','elev.diff')], by=as.character('STEM_TAG'))


## make sure things look normal. are there weird artifacts of the standardizing?
# summary(trees[trees$BIOMASS_DBH<5 & trees$SPECIES=='ABAM', 'scaled.Hegyi.con'])
# 
# plot(y=trees[trees$SPECIES%in% c('ABAM','TABR','TSHE','ACCI','COCOC','VAPA'),'zscore.Hegyi.con'],
#      x=trees[trees$SPECIES%in% c('ABAM','TABR','TSHE','ACCI','COCOC','VAPA'),'BIOMASS_DBH'])
# plot(trees[trees$BIOMASS_DBH>10 & trees$SPECIES=='ABAM','zscore.Hegyi.con'],
#      trees[trees$BIOMASS_DBH>10 & trees$SPECIES=='ABAM','BIOMASS_DBH'])
# plot(trees$scaled.Hegyi.con,trees$scaled.Hegyi.het)
# plot(trees$center.Hegyi.con,trees$center.Hegyi.het)
# plot(trees$zscore.Hegyi.con,trees$zscore.Hegyi.het)
# plot(trees[trees$SPECIES %in% c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),'SPECIES'],
#      trees[trees$SPECIES %in% c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),'zscore.Hegyi.con'])
# plot(x=trees[trees$SPECIES %in% c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),'BIOMASS_DBH'],
#      y=trees[trees$SPECIES %in% c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),'scaled.Hegyi.con'])
# 
# library(ggplot2)
# ggplot(neighbors.gr.summary1, aes(Group.2,x)) +
#   geom_line() + facet_wrap(~Group.1, ncol=3) + theme_classic()


# make summary table of population-specific SD
trees.gr.summary1<-setNames(aggregate(trees$sd.Hegyi,by=list(trees$SPECIES,trees$DBH_BIN),FUN=NROW),c('Species', 'Diameter', 'N'))
trees.gr.summary1$Tot.Hegyi.SD<-aggregate(trees$sd.Hegyi,by=list(trees$SPECIES,trees$DBH_BIN),FUN=mean)$x
trees.gr.summary1$Con.Hegyi.Mean<-aggregate(trees$mean.Hegyi.con,by=list(trees$SPECIES,trees$DBH_BIN),FUN=mean)$x
trees.gr.summary1$Het.Hegyi.Mean<-aggregate(trees$mean.Hegyi.het,by=list(trees$SPECIES,trees$DBH_BIN),FUN=mean)$x
trees.gr.summary1 <- trees.gr.summary1[trees.gr.summary1$Species %in% c('ABAM','PSME','TABR','TSHE','ACCI','COCOC','VAPA'),]
trees.gr.summary1 <- trees.gr.summary1[order(trees.gr.summary1$Species),]

for(i in 1:nrow(trees.gr.summary1)){
  trees.gr.summary1[i,'Size_Class'] <- if(trees.gr.summary1[i,'Diameter']<10){
    paste(trees.gr.summary1[i,'Diameter'],"-",2+trees.gr.summary1[i,'Diameter'], sep='')} else if(trees.gr.summary1[i,'Diameter']>=10 & trees.gr.summary1[i,'Diameter'] <40){
      paste(trees.gr.summary1[i,'Diameter'],"-",10+trees.gr.summary1[i,'Diameter'], sep='')} else if(trees.gr.summary1[i,'Diameter']>=40 & trees.gr.summary1[i,'Diameter'] <100){
        paste(trees.gr.summary1[i,'Diameter'],"-",20+trees.gr.summary1[i,'Diameter'], sep='')} else if(trees.gr.summary1[i,'Diameter']>=100){
          paste('100+')}
}  
trees.gr.summary1$Diameter <- trees.gr.summary1$Size_Class
trees.gr.summary1 <- trees.gr.summary1[,-ncol(trees.gr.summary1)] 
trees.gr.summary1[is.na(trees.gr.summary1$Tot.Hegyi.SD)==T,'Tot.Hegyi.SD']<-0


#---------------------------------------------------------------------#
write.csv(x=trees.gr.summary1,file=paste('./OUTPUT/Neighborhood/WFDP_Population_Hegyi_Summary_',format(Sys.time(),'%Y%m%d'),'.csv',sep=''),row.names=F)
write.csv(x=trees,file=paste('./OUTPUT/Neighborhood/WFDP_Tree_with_neighbors_',format(Sys.time(),'%Y%m%d'),'.csv',sep=''),row.names=F)
#---------------------------------------------------------------------#


##############################################################################################################################################